spool D:\DBASS2\solution1Output.lst
--
set echo on
set feedback on
set linesize 100
set pagesize 200
set serveroutput on
/* =============================================================== 
 * Name: Jeslyn Ho Ka Yan
 * Student number: 1024 1485
 * Date: 3 May 2024
 * Module: CSCI 235 (DataBase System)
 * File: solution1.sql (Assingment2 Task 1)
 * =============================================================*/
--
--
--
--
--i) Projection queries (select without where clause).-------------------------------
explain plan for 
select o_clerk, o_orderstatus 
from orders;
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--ii) selection queries (select with where claluse).--------------------------------
explain plan for  
select * 
from lineitem where l_orderkey =1;
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--iii) Join queries (join of two or more relational tables). ----------------------
explain plan for 
select * 
from lineitem join orders 
On l_orderkey = o_orderkey
where l_orderkey=1;	
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--iv) Queries processed by accessing only an index. ------------------------------
explain plan for 
select COUNT(*) 
from orders
where o_orderstatus = 'o' and o_clerk = 'Clerk#000000880';
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--v) Group by query (select with GROUP BY clause and aggregation function). -------
explain plan for 
select o_clerk, COUNT(*) 
from orders 
where o_orderstatus = 'O' 
GROUP BY o_clerk;
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--vi) Antijoin query (select with NOT IN, NOT EXISTS). ------------------------------
explain plan for 
select * 
from orders 
where O_ORDERKEY NOT IN (select l_orderkey from lineitem);
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--vii) Simple aggregation queries (select with MAX, MIN, SUM, … functions). -----------
explain plan for 
select min(l_orderkey) as min_lorderkey, max(l_orderkey) as max_lorderkey
from lineitem;
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--viii) Update statement. ------------------------------------------------------------
explain plan for 
UPDATE orders set o_orderstatus = 'F'
where o_clerk = 'Clerk#000000880' and o_orderstatus ='O';  
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--ix) Delete statement. --------------------------------------------------------------
explain plan for 
Delete from orders
where o_clerk='Clerk#000000659'
and o_orderstatus = 'o';
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--x) Query with sorting (select with ORDER BY clause). ---------------------------------
explain plan for 
select * from orders
where o_orderstatus = 'o' 
ORDER BY o_clerk, o_orderstatus;
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--
-- Spool off to stop the spooling
spool off;
