spool D:\DBASS2\solution2Output.lst
--
set echo on
set feedback on
set linesize 100
set pagesize 200
set serveroutput on
--
/* =============================================================== 
 * Name: Jeslyn Ho Ka Yan
 * Student number: 1024 1485
 * Date: 3 May 2024
 * Module: CSCI 235 (DataBase System)
 * File: solution2.sql (Assigment2 Task 2)
 * =============================================================*/
--
--
CREATE OR REPLACE PROCEDURE PROJECTGROUPS IS
  CURSOR c_ProjectGrps IS
    SELECT p.P#, p.PTitle, LISTAGG(e.Name, ',') WITHIN GROUP (ORDER BY e.Name) AS emp_list
    FROM PROJECT p
    JOIN WorksOn w ON w.P# = p.P#
    JOIN Employee e ON w.E# = e.E#
    GROUP BY p.P#, p.PTitle  
    ORDER BY p.P#;
  new c_ProjectGrps%ROWTYPE;
--
BEGIN
  -- Open the cursor
  OPEN c_ProjectGrps;
  --
  LOOP
    -- Fetch project data
    FETCH c_ProjectGrps INTO new;
    EXIT WHEN c_ProjectGrps%NOTFOUND;
    
    -- Display project details
    DBMS_OUTPUT.PUT_LINE(new.P# || ' '||new.PTitle ||': ' || new.emp_list);
  END LOOP;
  -- Close the cursor
  CLOSE c_ProjectGrps;
END;
/
--
-- Execute the procedure
BEGIN
  PROJECTGROUPS;
END;
/
--
-- Terminate spooling
SPOOL OFF;
