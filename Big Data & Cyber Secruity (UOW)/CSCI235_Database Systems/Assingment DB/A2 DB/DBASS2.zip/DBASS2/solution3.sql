spool D:\DBASS2\solution3Output.lst
--
set echo on
set feedback on
set linesize 100
set pagesize 200
set serveroutput on
/* =============================================================== 
 * Name: Jeslyn Ho Ka Yan
 * Student number: 1024 1485
 * Date: 3 May 2024
 * Module: CSCI 235 (DataBase System)
 * File: solution3.sql (Assigment2 Task 3)
 * =============================================================*/
--
CREATE OR REPLACE FUNCTION FINDDEPENDENTS(EID IN Employee.E#%TYPE)
RETURN VARCHAR2 IS
  ENum Employee.E#%TYPE;
  EName Employee.Name%TYPE;
  dependents VARCHAR2(2000) := '';  -- Initialize dependents string
BEGIN
  -- Select employee details for the given ID
  SELECT e.E#, e.Name
  INTO ENum, EName
  FROM Employee e
  WHERE e.E# = EID;
--
  -- Concatenate dependent names using LISTAGG
  SELECT LISTAGG(d.DName, ', ') WITHIN GROUP (ORDER BY d.DName)
  INTO dependents
  FROM Dependent d
  WHERE d.E# = EID;

  -- Return employee details and dependent list (if any)
  RETURN ENum || ' ' || EName || ': ' || dependents;
END FINDDEPENDENTS;
/
--
--
DECLARE
  EInfo VARCHAR2(2000);  -- Adjust size if needed
BEGIN
  -- Loop through different employee IDs ordered by employee name
  FOR emp_rec IN (
    SELECT e.E#, e.Name
    FROM Employee e
    ORDER BY e.Name
  ) LOOP
    -- Call the function for each employee ID
    EInfo := FINDDEPENDENTS(emp_rec.E#);

    -- Display the retrieved information
    DBMS_OUTPUT.PUT_LINE(EInfo);
  END LOOP;
END;
/
--
-- Terminate spooling
spool off;
