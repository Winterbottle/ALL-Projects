spool D:\DBASS2\solution4Output.lst
--
set echo on
set feedback on
set linesize 100
set pagesize 200
set serveroutput on
--
/* =============================================================== 
 * Name: Jeslyn Ho Ka Yan
 * Student number: 1024 1485
 * Date: 3 May 2024
 * Module: CSCI 235 (DataBase System)
 * File: solution4.sql (Assigment2 Task 4)
 * =============================================================*/
--
--

ALTER TABLE Employee
DROP COLUMN insertionDate;

ALTER TABLE Employee
ADD insertionDate DATE;

CREATE OR REPLACE TRIGGER insert_EM_Per_Day
BEFORE INSERT ON Employee
FOR EACH ROW
DECLARE
    existing_user_count INT := 0;
BEGIN
    -- Debug output
    DBMS_OUTPUT.PUT_LINE('Trigger fired for E#: ' || :NEW.E#);
    DBMS_OUTPUT.PUT_LINE('Current date: ' || TO_CHAR(TRUNC(SYSDATE), 'YYYY-MM-DD'));

    -- Check for existing records for the same employee on the current day
    SELECT COUNT(*) INTO existing_user_count
    FROM Employee
    WHERE E# = :NEW.E#
    AND TRUNC(insertionDate) = TRUNC(SYSDATE);

    -- Debug output
    DBMS_OUTPUT.PUT_LINE('Existing user count: ' || existing_user_count);

    -- If there are existing records, raise an error
    IF existing_user_count > 0 THEN
        RAISE_APPLICATION_ERROR (-20001, 'You have already inserted a record today, try again tomorrow');
    END IF;
END;
/
-- Test case 1: Insertion accepted
BEGIN
    INSERT INTO Employee (E#, Name, insertionDate)
    VALUES (1032, 'Employee Name', SYSDATE);
    COMMIT;
END;
/

-- Test case 2: Insertion rejected
BEGIN
    INSERT INTO Employee (E#, Name, insertionDate)
    VALUES (1032, 'Another Employee Name', SYSDATE);
    COMMIT;
END;
/
SPOOL OFF;
