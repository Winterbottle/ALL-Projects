DROP TABLE WorksOn PURGE;
DROP TABLE Dependent PURGE;
DROP TABLE DeptLocation PURGE;
DROP TABLE Project PURGE;
DROP TABLE Department cascade constraints PURGE;
DROP TABLE Employee cascade constraints PURGE;
