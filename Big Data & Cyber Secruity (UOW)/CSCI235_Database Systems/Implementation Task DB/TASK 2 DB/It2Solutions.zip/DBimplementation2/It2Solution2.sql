spool D:\DBimplementation2\It2Solution2Output.lst
--
set echo on
set feedback on
set linesize 100
set pagesize 200
set serveroutput on
/* =============================================================== 
 * Name: Jeslyn Ho Ka Yan
 * Student number: 1024 1485
 * Date: 3 May 2024
 * Module: CSCI 235 (DataBase System)
 * File: It2Solution2 (Implementation1 Task 2)
 * =============================================================*/
--
--
/*================================================================================
    A) First select STATEMENT, 
    traverse the index vertically, 
    without accessing into the relational table
==================================================================================*/
explain plan for
select o_clerk
from orders
where o_orderdate = TO_DATE('1996-12-01','YYYY-MM-DD');
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--
/*================================================================================
    B) Second select STATEMENT, 
    first traverse the index vertically followed by horizontal scan at the leaf level,
    without accessing into the relational table
=================================================================================*/
explain plan for
select o_totalprice
from orders
where o_clerk = 'Clerk#000000880' 
and o_orderdate >= TO_DATE('1998-01-01', 'YYYY-MM-DD')
and o_orderdate <= TO_DATE('1998-12-31', 'YYYY-MM-DD');
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--
/*================================================================================
    C) First select STATEMENT, 
    traverse the leaf level of the index horizontally, 
    without accessing into the relational table
==================================================================================*/
explain plan for
select o_orderdate, o_clerk, o_totalprice
from orders
where o_clerk = 'Clerk#000000880';
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--
/*================================================================================
    D) First select STATEMENT, 
    traverse the index vertically,
    must access into the relational table
==================================================================================*/
explain plan for
select *
from orders
where o_orderdate = TO_DATE('1996-12-01','YYYY-MM-DD');
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--
/*================================================================================
    E) First select STATEMENT, 
    first traverse the index vertically followed by horizontal scan at the leaf level, 
    must access into the relational table
==================================================================================*/
explain plan for
select *
from orders
where o_clerk = 'Clerk#000000880' 
and o_totalprice > 1000;
--
-- Show the execution plan 
select * from table(dbms_xplan.display);
--
--
-- Spool off to stop the spooling
spool off;

