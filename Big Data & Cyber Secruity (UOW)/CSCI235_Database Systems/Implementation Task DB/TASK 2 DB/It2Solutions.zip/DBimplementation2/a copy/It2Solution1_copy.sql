--spool /media/DBimplementation2/It2Solution1Output.lst
spool D:\DBimplementation2\It2Solution1Output.lst
--
set echo on
set feedback on
set linesize 100
set pagesize 200
set serveroutput on
/* =============================================================== 
 * Name: Jeslyn Ho Ka Yan
 * Student number: 1024 1485
 * Date: 3 May 2024
 * Module: CSCI 235 (DataBase System)
 * File: It2Solution1Output (Implementation1 Task 1)
 * =============================================================*/
--
/*========================================================================================================
    Find all the discount (l_discount) of all the items that are shipped (l_shipdate) most recently. 
    Hint. Most recently mean the latest shipment date. 
==========================================================================================================*/-- 
--
-- Generate an execution strategy for the given query.
explain plan for
select l_discount
from lineitem 
where l_shipdate = ( select MAX(l_shipdate) from lineitem );
--
--
-- Display the execution plan
select * from table(dbms_xplan.display);
--
/*
The execution plan for the query exposed an inefficiency. To determine the maximum l_shipdate 
value, the initial scan sorts the entire table. Every record is then compared to this maximum 
value in the second scan. 
--
An index will be made on the l_shipdate and l_discount characteristics in order to maximise 
this. Because both necessary properties are contained inside the index itself l_shipdate in the 
WHERE clause and l_discount in the SELECT clause this composite index will enable a 
quick and effective full index scan. This will cut down on how long it takes to complete the 
query.
*/
--
CREATE INDEX idx_latestShipDate on lineitem(l_shipdate desc);
--
--
--Create an execution plan for the given query following the index creation (idx_latestShipDate).
explain plan for
select l_discount
from lineitem 
where l_shipdate = ( select MAX(l_shipdate) from lineitem );
--
-- Display the execution plan
select * from table(dbms_xplan.display);
--
/*
According to the execution plan, the system now sorts the l_shipdate to find the highest 
(maximum) l_shipdate by performing a full index scan. After that, the outer query runs an 
index range scan to first traverse the index vertically to find the first key that begins with 
(prefixed) with the l_shipdate, and then it runs a horizontal scan at the leaf node to process 
the remaining keys until the end of the index.
*/
--
--
--
/*========================================================================================================
    Find the total number of items shipped by air (l_shipmode) in 1998 (l_shipdate).    
==========================================================================================================*/-- 
--
-- Generate an execution strategy for the given query.
explain plan for
select COUNT(*) as total_air_items 
from lineitem 
where l_shipmode = 'AIR' 
and extract(YEAR FROM l_shipdate) = 1998;
--
--
-- Display the execution plan
select * from table(dbms_xplan.display);
--
/*
To improve performance, we can create a composite index on the LINEITEM table that includes
l_shipmode, which enables efficient filtering based on the shipping method.
YEAR(l_shipdate), which allows the database to utilize the year extracted from the shipment 
date for further filtering within the identified rows based on l_shipmode.
*/
--
CREATE INDEX idx_air_ship_date on LINEITEM(l_shipmode, extract(YEAR FROM l_shipdate));
--
-- Generate an execution strategy for the given query.
explain plan for
select COUNT(*) as total_air_items 
from lineitem 
where l_shipmode = 'AIR' 
and extract(YEAR FROM l_shipdate) = 1998;
--
--
-- Display the execution plan
select * from table(dbms_xplan.display);
--
/*
It is inefficient to first scan the full table. To facilitate faster filtering based on both shipping 
method and year, we built a composite index on l_shipmode and YEAR(l_shipdate). 
*/
--
--
/*========================================================================================================
    Find the order number (l_orderkey) and item number (l_linenumber) that have the highest discount (l_discount). 
==========================================================================================================*/-- 
--
-- Generate an execution strategy for the given query.
explain plan for
select l_orderkey, l_linenumber
from lineitem 
where l_discount = ( select MAX(l_discount) from lineitem );
--
--
-- Display the execution plan
select * from table(dbms_xplan.display);
--
--
/*
The execution plan for the query exposed an inefficiency. To determine the maximum l_discount
value, the initial scan sorts the entire table. Every record is then compared to this maximum 
value in the second scan. 
--
An index will be created to enables the query to efficiently locate the highest discounted item using 
an index scan, avoiding a full table scan and significantly improving performance.
*/
--
CREATE INDEX idx_highest_discount on lineitem(l_discount desc);
--
-- Generate an execution strategy for the given query.
explain plan for
select l_orderkey, l_linenumber
from lineitem 
where l_discount = ( select MAX(l_discount) from lineitem );
--
--
-- Display the execution plan
select * from table(dbms_xplan.display);
--
/*
According to the execution plan, the system now sorts the l_discount to find the highest 
(maximum) l_discount by performing a full index scan. After that, the outer query runs an 
index range scan to first traverse the index vertically to find the first key that begins with 
(prefixed) with the l_discount, and then it runs a horizontal scan at the leaf node to process 
the remaining keys until the end of the index.
*/
--
--
/*========================================================================================================
    Find the total number of item per line status (l_linestatus). List the line status and the total 
    items per line status.  
==========================================================================================================*/-- 
--
-- Generate an execution strategy for the given query.
explain plan for
select l_linestatus, COUNT(*) as total_items_per_line_status
from lineitem
group by l_linestatus;
--
--
-- Display the execution plan
select * from table(dbms_xplan.display);
--
--
/*
Even though there may already be an index in place, the query may still be performing a whole table scan. 
This implies that the grouping column, l_linestatus, is not included in the index, if one exists.
--
The query can be processed without accessing the relational table by using the index, which allows the 
system to do an index range scan. The database can quickly find rows with particular l_linestatus values
using this index, which is necessary for the query's grouping and counting. This significantly improves 
performance compared to a full table scan.
*/
--
CREATE INDEX idx_lineStatus on lineitem(l_linestatus);
--
-- Generate an execution strategy for the given query.
explain plan for
select l_linestatus, COUNT(*) as total_items_per_line_status
from lineitem
group by l_linestatus;
--
--
-- Display the execution plan
select * from table(dbms_xplan.display);
--
/*
By enabling an effective index scan for grouping and aggregation, an index on l_linestatus (idx_lineStatus) 
considerably improves query performance by avoiding a full table scan.
*/
--
--
/*========================================================================================================
    Find the order key (l_orderkey), line item number (l_linenumber), line status (l_linestatus), 
    shipment date (l_shipdate) and shipment mode (l_shipmode) of all orders with the order number 
    (l_orderkey) 1795718, 1799046, and 1794626. 
==========================================================================================================*/-- 
--
-- Generate an execution strategy for the given query.
explain plan for
select l_orderkey, l_linenumber, l_linestatus, l_shipdate, l_shipmode
from lineitem
where l_orderkey in (1795718, 1799046, 1794626);

--
--
-- Display the execution plan
select * from table(dbms_xplan.display);
--
--
/*
The initial query filters data based on a set of l_orderkey values and retrieves it from the LINEITEM table. 
The database might have to search the entire table for matching entries if l_orderkey didn't have an index.  
This can be ineffective, particularly with big tables.
--
An index on l_orderkey (idx_orderKey) allows for an effective lookup utilising the index, which prevents 
the need for a full table scan and greatly enhances query performance.
*/
--
CREATE INDEX idx_orderKey  on lineitem(l_orderkey);
--
-- Generate an execution strategy for the given query.
explain plan for
select l_orderkey, l_linenumber, l_linestatus, l_shipdate, l_shipmode
from lineitem
where l_orderkey in (1795718, 1799046, 1794626);
--
--
-- Display the execution plan
select * from table(dbms_xplan.display);
--
/*
The database query efficiency can be greatly enhanced by building suitable indexes on pertinent columns. 
We may minimise the need for full table scans and improve data retrieval by using indexes for filtering, 
grouping, and joining operations. 
*/
--
--
-- Drop the index after the processing
DROP INDEX idx_latestShipDate ;
DROP INDEX idx_air_ship_date ;
DROP INDEX idx_highest_discount ;
DROP INDEX idx_lineStatus ;
DROP INDEX idx_orderKey  ;
--
-- Spool off to stop the spooling
spool off;