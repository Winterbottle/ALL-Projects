// CleanerHomePage.java
package wipeout.app.Boundary;

import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.*;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import java.io.IOException;

import wipeout.app.session.Session;

/**
 * Boundary for Cleaner Dashboard; handles navigation
 * to all Cleaner functions including profile views, shortlist,
 * confirmed matches, and service management.
 */
public class CleanerPage {

    @FXML
    public void handleCreateService(ActionEvent e) {
        changeScene(e, "/fxml/CreateCleaningServicePage.fxml", "Create Cleaning Service");
    }

    @FXML
    public void handleViewServices(ActionEvent e) {
        changeScene(e, "/fxml/ViewCleanerServicePage.fxml", "My Services");
    }

    @FXML
    public void handleUpdateService(ActionEvent e) {
        Stage currentStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        UpdateCleaningServicePage.displayUpdateCleaningServicePage(currentStage);
    }

    @FXML
    public void handleDeleteService(ActionEvent e) {
        Stage currentStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        DeleteCleaningServicePage.displayDeleteCleaningServicePage(currentStage);
    }

    @FXML
    public void handleSearchServices(ActionEvent e) {
        changeScene(e, "/fxml/SearchCleanerServicesPage.fxml", "Search Services");
    }

    @FXML
    public void handleViewProfileViews(ActionEvent e) {
        changeScene(e, "/fxml/ViewCleanerProfileViewsPage.fxml", "Profile Visibility");
    }

    @FXML
    public void handleViewShortlistCount(ActionEvent e) {
        changeScene(e, "/fxml/ViewCleanerShortlistPage.fxml", "Shortlist Count");
    }

    @FXML
    public void handleViewMatchHistory(ActionEvent e) {
        changeScene(e, "/fxml/ViewCleanerMatchPage.fxml", "Confirmed Match History");
    }

    @FXML
    public void handleSearchMatchHistory(ActionEvent e) {
        changeScene(e, "/fxml/SearchCleanerConfirmedHistoryPage.fxml", "Search Match History");
    }

    @FXML
    private void handleLogout(ActionEvent e) {
        Session.clear();
        Stage currentStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        LoginPage loginPage = new LoginPage();
        loginPage.start(currentStage);
    }

    /** Universal scene switcher for cleaner functions */
    private void changeScene(ActionEvent e, String fxmlPath, String title) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
            Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
