package wipeout.app.Boundary;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import wipeout.app.Controller.CreateCleaningServiceController;
import wipeout.app.Entity.ServiceCategory;
import wipeout.app.session.Session;

import java.io.IOException;
import java.util.*;

public class CreateCleaningServicePage {

    @FXML
    private TextField serviceTitleField;

    @FXML
    private TextArea serviceDescriptionArea;

    @FXML
    private TextField priceField;

    @FXML
    private ListView<ServiceCategory> categoryListView;

    @FXML
    private Button createServiceButton;

    @FXML
    private Label statusLabel;

    private final CreateCleaningServiceController controller = new CreateCleaningServiceController();

    private final int currentCleanerId = Session.getUserId();

    private final Set<ServiceCategory> selectedCategories = new HashSet<>();

    @FXML
    public void initialize() {
        List<ServiceCategory> categories = ServiceCategory.getAllCategories();
        ObservableList<ServiceCategory> items = FXCollections.observableArrayList(categories);
        categoryListView.setItems(items);

        // ✅ Track checkbox states with a stable map
        Map<ServiceCategory, SimpleBooleanProperty> checkboxMap = new HashMap<>();
        for (ServiceCategory cat : categories) {
            checkboxMap.put(cat, new SimpleBooleanProperty(false));
        }

        // ✅ Custom cell factory with formatted display and checkbox binding
        categoryListView.setCellFactory(lv -> new CheckBoxListCell<>(cat -> {
            SimpleBooleanProperty prop = checkboxMap.get(cat);
            prop.addListener((obs, wasSelected, isNowSelected) -> {
                if (isNowSelected) selectedCategories.add(cat);
                else selectedCategories.remove(cat);
            });
            return prop;
        }) {
            @Override
            public void updateItem(ServiceCategory cat, boolean empty) {
                super.updateItem(cat, empty);
                if (cat != null && !empty) {
                    setText("[" + cat.getCategoryId() + "] " + cat.getCategoryName() + " - " + cat.getCategoryDescription());
                } else {
                    setText(null);
                }
            }
        });
    }

    @FXML
    private void handleCreateService(MouseEvent event) {
        String title = serviceTitleField.getText();
        String description = serviceDescriptionArea.getText();
        double price;

        try {
            price = Double.parseDouble(priceField.getText());
        } catch (NumberFormatException e) {
            showError("Invalid price.");
            return;
        }

        List<Integer> categoryIds = selectedCategories.stream()
                .map(ServiceCategory::getCategoryId)
                .toList();

        int result = controller.createCleaningService(currentCleanerId, title, description, price, categoryIds);

        switch (result) {
            case 0 -> {
                showSuccess("Service created successfully.");
                clearForm();
            }
            case 1 -> showError("Database error occurred.");
            case 2 -> showError("Title too long (max 20 chars).");
            case 3 -> showError("Price must be > 0.");
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/CleanerPage.fxml")); // Replace with actual back target
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showError("Failed to load previous page.");
        }
    }

    private void showError(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: red;");
    }

    private void showSuccess(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: green;");
    }

    private void clearForm() {
        serviceTitleField.clear();
        serviceDescriptionArea.clear();
        priceField.clear();
        selectedCategories.clear();
        categoryListView.getSelectionModel().clearSelection();
        categoryListView.refresh();
    }
}
