package wipeout.app.Boundary;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import wipeout.app.Controller.CreateServiceCategoryController;

public class CreateServiceCategoryPage {

    @FXML private TextField categoryNameField;
    @FXML private TextArea categoryDescriptionArea;
    @FXML private Label statusLabel;

    private final CreateServiceCategoryController controller = new CreateServiceCategoryController();

    @FXML
    private void handleCreateCategory(ActionEvent event) {
        String name = categoryNameField.getText();
        String description = categoryDescriptionArea.getText();

        if (name.isEmpty()) {
            showError("Category name cannot be empty.");
            return;
        }

        if (description.isEmpty()) {
            showError("Category description cannot be empty.");
            return;
        }

        int result = controller.createCategory(name, description);

        switch (result) {
            case 0:
                showSuccess("Category created successfully!");
                clearFields();
                break;
            case 1:
                showError("Category name already exists.");
                break;
            case 2:
                showError("Category name too long (max 50 characters).");
                break;
            case 3:
                showError("Database error occurred.");
                break;
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/PlatformManagerPage.fxml")); // Replace with actual back target
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showError("Failed to load previous page.");
        }
    }

    private void clearFields() {
        categoryNameField.clear();
        categoryDescriptionArea.clear();
    }

    private void showError(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: red;");
    }

    private void showSuccess(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: green;");
    }
}
