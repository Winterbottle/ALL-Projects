package wipeout.app.Boundary;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import wipeout.app.Controller.CreateUserAccountController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;
import java.io.IOException;

public class CreateUserAccountPage {

    @FXML private TextField profileIdField;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private TextField fullnameField;
    @FXML private ChoiceBox<String> accountStatusChoice;
    @FXML private Label statusLabel;

    private final CreateUserAccountController controller = new CreateUserAccountController();

    @FXML
    public void initialize() {
        accountStatusChoice.getItems().addAll("Active", "Suspended");
        accountStatusChoice.setValue("Active");
    }

    @FXML
    private void handleCreateAccount(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();
        String fullName = fullnameField.getText();
        String accountStatus = accountStatusChoice.getValue();
        String profileIdText = profileIdField.getText();

        if (username.isEmpty()) {
            showError("Username cannot be empty.");
            return;
        }
        if (password.isEmpty()) {
            showError("Password cannot be empty.");
            return;
        }
        if (fullName.isEmpty()) {
            showError("Full name cannot be empty.");
            return;
        }
        if (profileIdText.isEmpty()) {
            showError("Profile ID cannot be empty.");
            return;
        }

        int profileID;
        try {
            profileID = Integer.parseInt(profileIdText);
        } catch (NumberFormatException e) {
            showError("Profile ID must be a valid number.");
            return;
        }

        int result = controller.createUserAccount(username, password, fullName, accountStatus, profileID);

        switch (result) {
            case 0:
                showSuccess("Account created successfully!");
                clearFields();
                break;
            case 1:
                showError("Username already exists.");
                break;
            case 2:
                showError("Username too long (max 20 characters).");
                break;
            case 4:
                showError("Database error occurred.");
                break;
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/UserAdministratorPage.fxml")); //  change to your target page
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showError("Failed to go back.");
        }
    }


    private void clearFields() {
        usernameField.clear();
        passwordField.clear();
        fullnameField.clear();
        profileIdField.clear();
        accountStatusChoice.setValue("Active"); // or default choice
    }


    private void showError(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: red;");
    }

    private void showSuccess(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: green;");
    }
}
