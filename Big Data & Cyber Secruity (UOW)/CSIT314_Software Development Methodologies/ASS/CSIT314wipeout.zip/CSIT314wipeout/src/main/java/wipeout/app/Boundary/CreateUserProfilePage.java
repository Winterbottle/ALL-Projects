package wipeout.app.Boundary;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;
import java.io.IOException;
import wipeout.app.Controller.CreateUserProfileController;

public class CreateUserProfilePage {

    @FXML private TextField profileNameField;
    @FXML private TextArea profileDescriptionArea;
    @FXML private ChoiceBox<String> profileStatusChoice;
    @FXML private Label statusLabel;

    private final CreateUserProfileController controller = new CreateUserProfileController();

    @FXML
    public void initialize() {
        profileStatusChoice.getItems().addAll("Active", "Suspended");
        profileStatusChoice.setValue("Active");
    }

    @FXML
    private void handleCreateProfile(ActionEvent event) {
        String profileName = profileNameField.getText();
        String profileDescription = profileDescriptionArea.getText();
        String profileStatus = profileStatusChoice.getValue();

        if (profileName.isEmpty()) {
            showError("Profile name cannot be empty.");
            return;
        }

        if (profileDescription.isEmpty()) {
            showError("Profile description cannot be empty.");
            return;
        }

        if (profileStatus == null || profileStatus.isEmpty()) {
            showError("Please select a profile status.");
            return;
        }

        int result = controller.createUserProfile(profileName, profileDescription, profileStatus);

        switch (result) {
            case 0:
                showSuccess("Profile created successfully!");
                break;
            case 1:
                showError("Profile name already exists.");
                break;
            case 4:
                showError("Database error occurred.");
                break;
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/UserAdministratorPage.fxml")); // change to your target FXML
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showError("Failed to load the previous page.");
        }
    }

    private void showError(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: red;");
    }

    private void showSuccess(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: green;");
    }
}
