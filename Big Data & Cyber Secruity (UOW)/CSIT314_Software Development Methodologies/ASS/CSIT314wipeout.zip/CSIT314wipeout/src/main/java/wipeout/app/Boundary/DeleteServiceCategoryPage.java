package wipeout.app.Boundary;

import wipeout.app.Controller.DeleteServiceCategoryController;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class DeleteServiceCategoryPage {
    private VBox layout = new VBox(15);
    private ComboBox<String> categoryDropdown = new ComboBox<>();
    private Label nameLabel = new Label();
    private Label descriptionLabel = new Label();
    private Label feedbackLabel = new Label();

    public static void displayDeleteServiceCategoryPage(Stage primaryStage) {
        ScrollPane scrollPane = new ScrollPane(new DeleteServiceCategoryPage(primaryStage).getView());
        scrollPane.setFitToWidth(true);
        scrollPane.setPadding(new Insets(10));
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);

        Scene scene = new Scene(scrollPane, 600, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Delete Service Category");
        primaryStage.show();
    }

    public DeleteServiceCategoryPage(Stage primaryStage) {
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.TOP_LEFT);

        Label title = new Label("Delete Service Category");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        categoryDropdown.getItems().setAll(DeleteServiceCategoryController.getAllCategoryLabels());

        categoryDropdown.setOnAction(e -> {
            String selected = categoryDropdown.getValue();
            if (selected != null && selected.contains(" - ")) {
                int id = Integer.parseInt(selected.split(" - ")[0].trim());
                String[] category = DeleteServiceCategoryController.getCategoryById(id);
                if (category != null) {
                    nameLabel.setText("Name: " + category[1]);
                    descriptionLabel.setText("Category Description: " + category[2]);
                    feedbackLabel.setText("");
                } else {
                    displayErrorMsg("Category not found.");
                }
            }
        });

        Button deleteBtn = new Button("Delete Category");
        deleteBtn.setOnAction(e -> {
            String selected = categoryDropdown.getValue();
            if (selected == null || !selected.contains(" - ")) {
                displayErrorMsg("Please select a valid category.");
                return;
            }

            int id = Integer.parseInt(selected.split(" - ")[0].trim());
            boolean success = DeleteServiceCategoryController.deleteCategory(id);
            if (success) {
                feedbackLabel.setStyle("-fx-text-fill: red;");
                feedbackLabel.setText("Category deleted successfully.");
                categoryDropdown.getItems().setAll(DeleteServiceCategoryController.getAllCategoryLabels());
                nameLabel.setText("");
                descriptionLabel.setText("");
            } else {
                displayErrorMsg("Failed to delete category.");
            }
        });

        Button backBtn = new Button("Back");
        backBtn.setOnAction(this::handleBack);
        layout.getChildren().addAll(
                title,
                new Label("Select Category:"), categoryDropdown,
                nameLabel,
                descriptionLabel,
                deleteBtn,
                feedbackLabel,
                backBtn
        );
    }

    private void displayErrorMsg(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Validation Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public VBox getView() {
        return layout;
    }

    public void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/PlatformManagerPage.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Platform Manager Dashboard");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
