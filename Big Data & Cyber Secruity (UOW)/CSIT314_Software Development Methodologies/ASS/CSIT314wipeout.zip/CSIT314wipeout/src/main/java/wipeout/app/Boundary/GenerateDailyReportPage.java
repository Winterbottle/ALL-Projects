package wipeout.app.Boundary;
//PM-08 As a Platform Manager, I want to generate daily reports so that I can monitor short-term activity.
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import wipeout.app.Controller.GenerateDailyReportController;
import wipeout.app.Entity.AdminReport;
import wipeout.app.session.Session;
import java.net.URL;
import java.sql.Date;
import java.util.List;
import java.util.ResourceBundle;

public class GenerateDailyReportPage implements Initializable {

    @FXML private DatePicker datePicker;
    @FXML private TableView<AdminReport> reportTable;
    @FXML private TableColumn<AdminReport, Integer> reportIDCol;
    @FXML private TableColumn<AdminReport, Date> startDateCol;
    @FXML private TableColumn<AdminReport, Date> endDateCol;
    @FXML private TableColumn<AdminReport, Integer> totalBookingsCol;
    @FXML private TableColumn<AdminReport, Float> estimatedRevenueCol;
    @FXML private TableColumn<AdminReport, Date> generatedDateCol;
    @FXML private TableColumn<AdminReport, Integer> generatedByCol;

    private GenerateDailyReportController controller = new GenerateDailyReportController();
    private int loggedInManagerId = Session.getUserId();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        reportIDCol.setCellValueFactory(new PropertyValueFactory<>("reportId"));
        startDateCol.setCellValueFactory(new PropertyValueFactory<>("reportPeriodStartDate"));
        endDateCol.setCellValueFactory(new PropertyValueFactory<>("reportPeriodEndDate"));
        totalBookingsCol.setCellValueFactory(new PropertyValueFactory<>("totalBookings"));
        estimatedRevenueCol.setCellValueFactory(new PropertyValueFactory<>("estimatedRevenue"));
        generatedDateCol.setCellValueFactory(new PropertyValueFactory<>("generatedDate"));
        generatedByCol.setCellValueFactory(new PropertyValueFactory<>("generatedBy"));
        reportTable.setColumnResizePolicy((param) -> true);
        for (TableColumn<?, ?> column : reportTable.getColumns()) {
            column.setMinWidth(100);
        }
    }

    @FXML
    private void handleGenerate() {
        // fetch based on selected date
        Date selectedDate = Date.valueOf(datePicker.getValue());
        List<AdminReport> reports = controller.fetchDailyReport(selectedDate, loggedInManagerId);
        ObservableList<AdminReport> data = FXCollections.observableArrayList(reports);
        reportTable.setItems(data);
        displayReports(reports);
    }

    public void displayReports(List<AdminReport> reports) {
        reportTable.setItems(FXCollections.observableArrayList(reports));
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/PlatformManagerPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Platfrom Manager Dashboard");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
