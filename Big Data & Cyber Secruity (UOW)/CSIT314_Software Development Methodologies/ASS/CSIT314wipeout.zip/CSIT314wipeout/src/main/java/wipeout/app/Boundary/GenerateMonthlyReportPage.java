package wipeout.app.Boundary;
//PM-10 As a Platform Manager, I want to generate monthly reports so that I can analyze long-term performance.
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import wipeout.app.Controller.GenerateMonthlyReportController;
import wipeout.app.Entity.AdminReport;
import wipeout.app.session.Session;

import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class GenerateMonthlyReportPage implements Initializable {

    @FXML private DatePicker datePicker;
    @FXML private TableView<AdminReport> reportTable;
    @FXML private TableColumn<AdminReport, Integer> reportIDCol;
    @FXML private TableColumn<AdminReport, Date> startDateCol;
    @FXML private TableColumn<AdminReport, Date> endDateCol;
    @FXML private TableColumn<AdminReport, Integer> totalBookingsCol;
    @FXML private TableColumn<AdminReport, Float> estimatedRevenueCol;
    @FXML private TableColumn<AdminReport, Date> generatedDateCol;
    @FXML private TableColumn<AdminReport, Integer> generatedByCol;

    private final GenerateMonthlyReportController controller = new GenerateMonthlyReportController();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        reportIDCol.setCellValueFactory(new PropertyValueFactory<>("reportId"));
        startDateCol.setCellValueFactory(new PropertyValueFactory<>("reportPeriodStartDate"));
        endDateCol.setCellValueFactory(new PropertyValueFactory<>("reportPeriodEndDate"));
        totalBookingsCol.setCellValueFactory(new PropertyValueFactory<>("totalBookings"));
        estimatedRevenueCol.setCellValueFactory(new PropertyValueFactory<>("estimatedRevenue"));
        generatedDateCol.setCellValueFactory(new PropertyValueFactory<>("generatedDate"));
        generatedByCol.setCellValueFactory(new PropertyValueFactory<>("generatedBy"));
    }

    @FXML
    private void handleGenerate(ActionEvent event) {
        LocalDate selectedDate = datePicker.getValue();
        if (selectedDate == null) return;

        int managerId = Session.getUserId();
        List<AdminReport> reports = controller.fetchMonthlyReport(Date.valueOf(selectedDate), managerId);
        displayReports(reports);
    }

    public void displayReports(List<AdminReport> reports) {
        reportTable.setItems(FXCollections.observableArrayList(reports));
    }

    @FXML
    private void handleBack(ActionEvent event) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/PlatformManagerPage.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}
