
package wipeout.app.Boundary;
//PM-09 As a Platform Manager, I want to generate weekly reports so that I can track performance over the week.
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import wipeout.app.Controller.GenerateWeeklyReportController;
import wipeout.app.Entity.AdminReport;
import wipeout.app.session.Session;

import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class GenerateWeeklyReportPage implements Initializable {
    @FXML private DatePicker datePicker;
    @FXML private TableView<AdminReport> reportTable;
    @FXML private TableColumn<AdminReport, Integer> reportIDCol;
    @FXML private TableColumn<AdminReport, Date> startDateCol;
    @FXML private TableColumn<AdminReport, Date> endDateCol;
    @FXML private TableColumn<AdminReport, Integer> totalBookingsCol;
    @FXML private TableColumn<AdminReport, Float> estimatedRevenueCol;
    @FXML private TableColumn<AdminReport, Date> generatedDateCol;
    @FXML private TableColumn<AdminReport, Integer> generatedByCol;

    private final GenerateWeeklyReportController controller = new GenerateWeeklyReportController();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        reportIDCol.setCellValueFactory(new PropertyValueFactory<>("reportId"));
        startDateCol.setCellValueFactory(new PropertyValueFactory<>("reportPeriodStartDate"));
        endDateCol.setCellValueFactory(new PropertyValueFactory<>("reportPeriodEndDate"));
        totalBookingsCol.setCellValueFactory(new PropertyValueFactory<>("totalBookings"));
        estimatedRevenueCol.setCellValueFactory(new PropertyValueFactory<>("estimatedRevenue"));
        generatedDateCol.setCellValueFactory(new PropertyValueFactory<>("generatedDate"));
        generatedByCol.setCellValueFactory(new PropertyValueFactory<>("generatedBy"));
    }

    @FXML
    private void handleGenerate(ActionEvent event) {
        LocalDate selectedDate = datePicker.getValue();
        if (selectedDate == null) return;

        int managerId = Session.getUserId();
        List<AdminReport> reports = controller.fetchWeeklyReport(Date.valueOf(selectedDate), managerId);
        displayReports(reports);
    }

    public void displayReports(List<AdminReport> reports) {
        reportTable.setItems(FXCollections.observableArrayList(reports));
    }

    @FXML
    private void handleBack(ActionEvent event) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/PlatformManagerPage.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
    }
}