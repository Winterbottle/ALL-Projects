// HomeOwnerHomePage.java
package wipeout.app.Boundary;

import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.stage.Stage;
import wipeout.app.session.Session;

import java.io.IOException;

/**
 * Boundary for Admin Dashboard; loads via FXML and handles navigation directly.
 */
public class HomeOwnerPage {
    public void show(Stage stage) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/HomeOwnerPage.fxml"));
            stage.setTitle("Home Owner Dashboard");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleViewAvailableCleaningServices(ActionEvent e) {
        changeScene(e, "/fxml/ViewCleaningServicePage.fxml", "Available Cleaning Services");
    }

    @FXML
    public void handleSearchCleaningServices(ActionEvent e) {
        changeScene(e, "/fxml/SearchCleaningServicePage.fxml", "Search Cleaning Services");
    }

    @FXML
    public void handleViewFavouriteList(ActionEvent e) {
        changeScene(e, "/fxml/ViewShortlistPage.fxml", "Favourite List");
    }

    @FXML
    public void handleSearchFavouriteList(ActionEvent e) {
        changeScene(e, "/fxml/SearchShortlistPage.fxml", "Search Favourite List");
    }

    @FXML
    public void handleViewFullServiceHistory(ActionEvent e) {
        changeScene(e, "/fxml/ViewServiceHistoryPage.fxml", "Service History");
    }

    @FXML
    public void handleSearchServiceHistory(ActionEvent e) {
        changeScene(e, "/fxml/SearchBookingHistoryPage.fxml", "Search Service History");
    }

    @FXML
    private void handleLogout(ActionEvent e) {
        Session.clear();
        Stage currentStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        LoginPage loginPage = new LoginPage();
        loginPage.start(currentStage);
    }

    private void changeScene(ActionEvent e, String fxmlPath, String title) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
            Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
