package wipeout.app.Boundary;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.io.IOException;
import wipeout.app.Controller.LoginController;
import wipeout.app.Entity.UserAccount;

// For User Stories: UA-01, HO-01, CL-01, PM-01
public class LoginPage extends Application {

    // === Class Fields ===
    // Error message labels for user profile, username, and password validation
    private Label userprofileErrorMsg;
    private Label usernameErrorMsg;
    private Label passwordErrorMsg;

    // Input components for user profile selection, username, and password
    private ComboBox<String> userprofileComboBox;
    private TextField usernameField;
    private PasswordField passwordField;

    @Override
    public void start(Stage primaryStage) {

        // === User Profile ComboBox Section ===
        Label userprofileLabel = new Label("Login As:");
        userprofileLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        // Dropdown list for user profile selection
        userprofileComboBox = new ComboBox<>();
        userprofileComboBox.getItems().addAll("", "Home Owner", "Cleaner", "Platform Manager", "User Administrator");
        userprofileComboBox.setPrefSize(320, 40);
        userprofileComboBox.setStyle("-fx-font-size: 20px;");

        // Error message label for profile selection
        userprofileErrorMsg = new Label();
        userprofileErrorMsg.setTextFill(Color.RED);
        userprofileErrorMsg.setStyle("-fx-font-size: 15px;");

        VBox userprofileBox = new VBox(5, userprofileLabel, userprofileComboBox, userprofileErrorMsg);

        // === Username Field Section===
        Label usernameLabel = new Label("Username:");
        usernameLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        usernameField = new TextField();
        usernameField.setPromptText("Enter username");
        usernameField.setPrefWidth(320);
        usernameField.setStyle("-fx-font-size: 20px;");
        usernameField.setDisable(true); // Initially disabled until a profile is selected

        usernameErrorMsg = new Label();
        usernameErrorMsg.setTextFill(Color.RED);
        usernameErrorMsg.setStyle("-fx-font-size: 15px;");

        VBox usernameBox = new VBox(5, usernameLabel, usernameField, usernameErrorMsg);

        // === Password Field Section===
        Label passwordLabel = new Label("Password:");
        passwordLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        passwordField = new PasswordField();
        passwordField.setPromptText("Enter password");
        passwordField.setPrefWidth(320);
        passwordField.setStyle("-fx-font-size: 20px;");
        passwordField.setDisable(true);

        passwordErrorMsg = new Label();
        passwordErrorMsg.setTextFill(Color.RED);
        passwordErrorMsg.setStyle("-fx-font-size: 15px;");

        VBox passwordBox = new VBox(5, passwordLabel, passwordField, passwordErrorMsg);

        // === Login Button ===
        Button loginButton = new Button("Login");
        loginButton.setPrefSize(200, 60);
        loginButton.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

        // === Main VBox Layout===
        VBox mainBox = new VBox(20, userprofileBox, usernameBox, passwordBox, loginButton);
        mainBox.setAlignment(Pos.CENTER);
        mainBox.setPadding(new Insets(20));

        // === BorderPane for Centering ===
        BorderPane root = new BorderPane();
        root.setCenter(mainBox);
        root.setPadding(new Insets(50));

        // === Event Listeners ===
        // Enable username and password fields when a valid profile is selected
        userprofileComboBox.setOnAction(e -> updateFieldState());

        // Handle login button click: validate and process login
        loginButton.setOnAction(e -> displayErrorMsg());

        // === Setup Scene and Stage ===
        Scene scene = new Scene(root, 900, 600);
        primaryStage.setTitle("Cleaning Services Platform");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Helper: Enable fields based on user profile selection
    private void updateFieldState() {
        boolean isProfileSelected = userprofileComboBox.getSelectionModel().getSelectedIndex() != 0;
        usernameField.setDisable(!isProfileSelected);
        passwordField.setDisable(!isProfileSelected);
    }

    // Event Handler: Validate Fields and Login
    private void displayErrorMsg() {
        boolean valid = true;

        // Validate user profile selection
        if (userprofileComboBox.getSelectionModel().getSelectedIndex() == 0) {
            userprofileErrorMsg.setText("*Please select your user profile");
            valid = false;
        } else {
            userprofileErrorMsg.setText("");
        }

        // Validate username field
        if (usernameField.getText().isEmpty()) {
            usernameErrorMsg.setText("*Please enter your username");
            valid = false;
        } else {
            usernameErrorMsg.setText("");
        }

        // Validate password field
        if (passwordField.getText().isEmpty()) {
            passwordErrorMsg.setText("*Please enter your password");
            valid = false;
        } else {
            passwordErrorMsg.setText("");
        }

        if (!valid) {
            return;
        }

        // === Boundary interacts with Controller
        LoginController loginController = new LoginController();
        int userID = loginController.login(
                usernameField.getText(),
                passwordField.getText(),
                userprofileComboBox.getValue()
        );

        // Handle login response codes
        if (userID == -1) {
            showAlert("Your account has been suspended! Please contact support.");
        } else if (userID == -2) {
            showAlert("Invalid login credentials! Please try again.");
        } else {
            displayRespectivePage(userID); // Navigate to dashboard
        }
    }

    // Navigate to the respective page/dashboard based on user profile
    private void displayRespectivePage(int userID) {
        String selectedUserProfile = userprofileComboBox.getValue();
        UserAccount ua = new UserAccount();
        String fullname = ua.getFullname(userID);

        // Instantiate the correct dashboard based on profile
        switch (selectedUserProfile) {
            case "Home Owner":
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/HomeOwnerPage.fxml"));
                    Parent root = loader.load();
                    Stage stage = new Stage();
                    stage.setTitle("Home Owner Dashboard");
                    stage.setScene(new Scene(root));
                    stage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                    showAlert("Failed to load Home Owner Dashboard.");
                }
                break;
            case "Cleaner":
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/CleanerPage.fxml"));
                    Parent root = loader.load();
                    Stage stage = new Stage();
                    stage.setTitle("Cleaner Dashboard");
                    stage.setScene(new Scene(root));
                    stage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                    showAlert("Failed to load Cleaner Dashboard.");
                }
                break;
            case "Platform Manager":
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/PlatformManagerPage.fxml"));
                    Parent root = loader.load();
                    Stage stage = new Stage();
                    stage.setTitle("Platform Manager Dashboard");
                    stage.setScene(new Scene(root));
                    stage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                    showAlert("Failed to load Platform Manager Dashboard.");
                }
                break;
            case "User Administrator":
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/UserAdministratorPage.fxml"));
                    Parent root = loader.load();
                    Stage stage = new Stage();
                    stage.setTitle("Admin Dashboard");
                    stage.setScene(new Scene(root));
                    stage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                    showAlert("Failed to load Admin Dashboard.");
                }
                break;

        }
        // Close the login window after successful login
        ((Stage) usernameField.getScene().getWindow()).close();
    }

    // Display Error Message Dialog
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Login Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Main Method
    public static void main(String[] args) {
        launch(args);
    }
}