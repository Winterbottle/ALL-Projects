package wipeout.app.Boundary;

import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.*;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import wipeout.app.session.Session;

import java.io.IOException;

/**
 * Boundary for Platform Manager Dashboard; handles navigation
 * to all Platform Manager functions.
 */
public class PlatformManagerPage {

    @FXML
    public void handleCreateCategory(ActionEvent e) {
        changeScene(e, "/fxml/CreateServiceCategoryPage.fxml", "Create Service Category");
    }

    @FXML
    public void handleViewCategories(ActionEvent e) {
        changeScene(e, "/fxml/ViewServiceCategoryPage.fxml", "View Service Categories");
    }

    @FXML
    public void handleUpdateCategory(ActionEvent e) {
        Stage currentStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        UpdateServiceCategoryPage.displayUpdateServiceCategoryPage(currentStage);
    }

    @FXML
    public void handleDeleteCategory(ActionEvent e) {
        Stage currentStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        DeleteServiceCategoryPage.displayDeleteServiceCategoryPage(currentStage);
    }

    @FXML
    public void handleSearchCategory(ActionEvent e) {
        changeScene(e, "/fxml/SearchServiceCategoryPage.fxml", "Search Service Category");
    }

    @FXML
    public void handleDailyReport(ActionEvent e) {
        changeScene(e, "/fxml/GenerateDailyReportPage.fxml", "Generate Daily Report");
    }

    @FXML
    public void handleWeeklyReport(ActionEvent e) {
        changeScene(e, "/fxml/GenerateWeeklyReportPage.fxml", "Generate Weekly Report");
    }

    @FXML
    public void handleMonthlyReport(ActionEvent e) {
        changeScene(e, "/fxml/GenerateMonthlyReportPage.fxml", "Generate Monthly Report");
    }

    @FXML
    private void handleLogout(ActionEvent e) {
        Session.clear();
        Stage currentStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        LoginPage loginPage = new LoginPage();
        loginPage.start(currentStage);
    }

    /** Universal scene switcher for platform manager functions */
    private void changeScene(ActionEvent e, String fxmlPath, String title) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
            Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
