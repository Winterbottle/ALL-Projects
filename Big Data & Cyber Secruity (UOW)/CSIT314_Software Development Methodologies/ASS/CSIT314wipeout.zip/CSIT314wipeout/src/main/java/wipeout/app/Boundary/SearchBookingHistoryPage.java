package wipeout.app.Boundary;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import wipeout.app.Controller.SearchBookingHistoryController;
import wipeout.app.Entity.BookingHistory;
import wipeout.app.session.Session;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

public class SearchBookingHistoryPage {

    @FXML
    private ComboBox<String> serviceTitleComboBox;

    @FXML
    private DatePicker fromDatePicker;

    @FXML
    private DatePicker toDatePicker;

    @FXML
    private TableView<BookingHistory> bookingHistoryTable;

    @FXML
    private TableColumn<BookingHistory, Integer> bookingIdColumn;

    @FXML
    private TableColumn<BookingHistory, String> serviceTitleColumn;

    @FXML
    private TableColumn<BookingHistory, String> clientUsernameColumn;

    @FXML
    private TableColumn<BookingHistory, LocalDate> serviceDateColumn;

    @FXML
    private TableColumn<BookingHistory, Double> priceColumn;

    @FXML
    private TableColumn<BookingHistory, String> statusColumn;

    private final SearchBookingHistoryController controller = new SearchBookingHistoryController();

    @FXML
    public void initialize() {
        int homeownerId = Session.getUserId();

        List<String> serviceTitles = controller.getServiceTitles(homeownerId);
        serviceTitleComboBox.getItems().add("All Services");
        serviceTitleComboBox.getItems().addAll(serviceTitles);
        serviceTitleComboBox.getSelectionModel().selectFirst();

        bookingIdColumn.setCellValueFactory(new PropertyValueFactory<>("bookingId"));
        serviceTitleColumn.setCellValueFactory(new PropertyValueFactory<>("serviceTitle"));
        clientUsernameColumn.setCellValueFactory(new PropertyValueFactory<>("clientUsername"));
        serviceDateColumn.setCellValueFactory(new PropertyValueFactory<>("serviceDate"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        List<BookingHistory> bookingList = controller.search(homeownerId, null, null, null);
        ObservableList<BookingHistory> data = FXCollections.observableArrayList(bookingList);
        bookingHistoryTable.setItems(data);
    }

    @FXML
    public void handleSearch() {
        int homeownerId = Session.getUserId();
        String selectedTitle = serviceTitleComboBox.getValue();
        if ("All Services".equals(selectedTitle)) {
            selectedTitle = null;
        }

        LocalDate fromDate = fromDatePicker.getValue();  // Can be null
        LocalDate toDate = toDatePicker.getValue();      // Can be null

        List<BookingHistory> filteredList = controller.search(homeownerId, selectedTitle, fromDate, toDate);
        ObservableList<BookingHistory> data = FXCollections.observableArrayList(filteredList);
        bookingHistoryTable.setItems(data);
    }
    public void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/HomeOwnerPage.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Home Owner Dashboard");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

