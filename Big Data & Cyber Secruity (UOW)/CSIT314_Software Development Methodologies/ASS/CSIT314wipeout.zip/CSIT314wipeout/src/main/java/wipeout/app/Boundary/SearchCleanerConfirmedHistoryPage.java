package wipeout.app.Boundary;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import wipeout.app.Controller.SearchCleanerConfirmedHistoryController;
import wipeout.app.Entity.BookingHistory;
import wipeout.app.session.Session;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class SearchCleanerConfirmedHistoryPage implements Initializable {

    @FXML private TableView<BookingHistory> bookingTable;
    @FXML private TableColumn<BookingHistory, Integer> bookingIdColumn;
    @FXML private TableColumn<BookingHistory, String> serviceTitleColumn;
    @FXML private TableColumn<BookingHistory, String> clientUsernameColumn;
    @FXML private TableColumn<BookingHistory, LocalDate> dateColumn;
    @FXML private TableColumn<BookingHistory, Double> priceColumn;
    @FXML private TableColumn<BookingHistory, String> statusColumn;

    @FXML private ComboBox<String> serviceTitleComboBox;
    @FXML private DatePicker startDatePicker;
    @FXML private DatePicker endDatePicker;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Set up table columns
        bookingIdColumn.setCellValueFactory(new PropertyValueFactory<>("bookingId"));
        serviceTitleColumn.setCellValueFactory(new PropertyValueFactory<>("serviceTitle"));
        clientUsernameColumn.setCellValueFactory(new PropertyValueFactory<>("clientUsername"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("serviceDate"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        try {
            int cleanerId = Session.getUserId();
            List<String> serviceTitles = SearchCleanerConfirmedHistoryController.getCompletedServiceTitles(cleanerId);
            serviceTitles.add(0, "All Services");

            serviceTitleComboBox.setItems(FXCollections.observableArrayList(serviceTitles));
            serviceTitleComboBox.setValue("All Services");

            loadTableData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleSearch() {
        loadTableData();
    }

    private void loadTableData() {
        try {
            int cleanerId = Session.getUserId();
            String selectedTitle = serviceTitleComboBox.getValue();
            LocalDate from = startDatePicker.getValue();
            LocalDate to = endDatePicker.getValue();

            List<BookingHistory> results = SearchCleanerConfirmedHistoryController.getMatchHistory(cleanerId, selectedTitle, from, to);
            bookingTable.setItems(FXCollections.observableArrayList(results));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/CleanerPage.fxml")); //  change to your target page
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


