package wipeout.app.Boundary;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import wipeout.app.Controller.SearchCleanerServicesController;
import wipeout.app.Entity.CleaningService;
import wipeout.app.session.Session;

import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class SearchCleanerServicesPage implements Initializable {

    @FXML private TableView<CleaningService> serviceTable;
    @FXML private TableColumn<CleaningService, Integer> idCol;
    @FXML private TableColumn<CleaningService, String> titleCol;
    @FXML private TableColumn<CleaningService, String> descCol;
    @FXML private TableColumn<CleaningService, Double> priceCol;
    @FXML private TableColumn<CleaningService, LocalDate> dateCol;
    @FXML private TextField searchField;

    private final SearchCleanerServicesController controller = new SearchCleanerServicesController();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        idCol.setCellValueFactory(new PropertyValueFactory<>("serviceId"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("serviceTitle"));
        descCol.setCellValueFactory(new PropertyValueFactory<>("serviceDescription"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        dateCol.setCellValueFactory(new PropertyValueFactory<>("dateCreated"));

        loadAllServices();
    }

    private void loadAllServices() {
        int cleanerId = Session.getUserId();
        try {
            List<CleaningService> list = controller.getAllServicesByCleaner(cleanerId);
            ObservableList<CleaningService> observableList = FXCollections.observableArrayList(list);
            serviceTable.setItems(observableList);
        } catch (SQLException e) {
            e.printStackTrace();
            // Optional: showError("Failed to load services");
        }
    }

    @FXML
    private void handleSearch() {
        String keyword = searchField.getText().trim();
        int cleanerId = Session.getUserId();
        List<CleaningService> results;

        try {
            if (keyword.isEmpty()) {
                results = controller.getAllServicesByCleaner(cleanerId);
            } else {
                results = controller.searchCleanerServicesByKeyword(cleanerId, keyword);
            }
            serviceTable.setItems(FXCollections.observableArrayList(results));
        } catch (SQLException e) {
            e.printStackTrace();
            // Optional: showError("Search failed");
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/CleanerPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
