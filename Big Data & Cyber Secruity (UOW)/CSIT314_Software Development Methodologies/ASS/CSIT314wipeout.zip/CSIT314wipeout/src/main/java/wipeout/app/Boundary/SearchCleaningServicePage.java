package wipeout.app.Boundary;

// HO-04 As a Home Owner, I want to search for cleaning services so that I can find services that meet my needs.
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import wipeout.app.Controller.SearchCleaningServiceController;
import wipeout.app.Entity.CleaningService;

import java.io.IOException;
import java.util.List;

public class SearchCleaningServicePage {

    @FXML private TextField searchField;
    @FXML private Button searchButton;
    @FXML private TableView<CleaningService> serviceTable;
    @FXML private TableColumn<CleaningService, Integer> serviceIdColumn;
    @FXML private TableColumn<CleaningService, String> serviceTitleColumn;
    @FXML private TableColumn<CleaningService, String> serviceDescColumn;
    @FXML private TableColumn<CleaningService, Double> servicePriceColumn;
    @FXML private TextField statusLabel;

    private final SearchCleaningServiceController ctrl = new SearchCleaningServiceController();

    @FXML
    public void initialize() {
        serviceIdColumn.setCellValueFactory(new PropertyValueFactory<>("serviceId"));
        serviceTitleColumn.setCellValueFactory(new PropertyValueFactory<>("serviceTitle"));
        serviceDescColumn.setCellValueFactory(new PropertyValueFactory<>("serviceDescription"));
        servicePriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        searchButton.setOnAction(e -> onSearch());
    }

    @FXML
    private void onSearch() {
        String keyword = searchField.getText();
        List<CleaningService> results = ctrl.searchServices(keyword);
        serviceTable.setItems(FXCollections.observableArrayList(results));
        if (results.isEmpty()) {
            statusLabel.setText("No services found.");
            statusLabel.setStyle("-fx-text-fill: red;");
        } else {
            statusLabel.setText(results.size() + " service(s) found.");
            statusLabel.setStyle("-fx-text-fill: green;");
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/HomeOwnerPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
            statusLabel.setText("Failed to go back.");
            statusLabel.setStyle("-fx-text-fill: red;");
        }
    }
}
