package wipeout.app.Boundary;
//PM-07 As a Platform Manager, I want to search cleaning services categories so that I can find specific categories quickly.
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import wipeout.app.Controller.SearchServiceCategoryController;
import wipeout.app.Entity.ServiceCategory;

import java.io.IOException;
import java.util.List;

public class SearchServiceCategoryPage {
    @FXML private TextField searchField;
    @FXML private Button searchButton;
    @FXML private TableView<ServiceCategory> categoryTable;
    @FXML private TableColumn<ServiceCategory, Integer> idCol;
    @FXML private TableColumn<ServiceCategory, String> nameCol;
    @FXML private TableColumn<ServiceCategory, String> descCol;
    @FXML private TextField statusLabel;

    private final SearchServiceCategoryController ctrl = new SearchServiceCategoryController();

    @FXML
    public void initialize() {
        // Initialize table columns with PropertyValueFactory
        idCol.setCellValueFactory(new PropertyValueFactory<>("categoryId"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("categoryName"));
        descCol.setCellValueFactory(new PropertyValueFactory<>("categoryDescription"));

        // Wire search button
        searchButton.setOnAction(e -> onSearch());
    }

    private void onSearch() {
        String kw = searchField.getText();
        List<ServiceCategory> results = ctrl.searchCategories(kw);
        displayCategories(results);
    }
    public void displayCategories(List<ServiceCategory> categories) {
        categoryTable.setItems(FXCollections.observableArrayList(categories));
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/PlatformManagerPage.fxml")); //  change to your target page
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showError("Failed to go back.");
        }
    }

    private void showError(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: red;");
    }

    private void showSuccess(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: green;");
    }
}
