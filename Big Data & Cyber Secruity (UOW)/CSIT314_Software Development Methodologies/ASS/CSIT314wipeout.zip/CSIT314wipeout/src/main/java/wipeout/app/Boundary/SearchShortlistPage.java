package wipeout.app.Boundary;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import wipeout.app.Controller.SearchShortlistController;
import wipeout.app.Entity.Shortlist;
import wipeout.app.session.Session;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class SearchShortlistPage {

    @FXML private TextField searchField;
    @FXML private TableView<Shortlist> tableView;
    @FXML private TableColumn<Shortlist, String> serviceTitleCol;
    @FXML private TableColumn<Shortlist, String> cleanerUsernameCol;

    private final SearchShortlistController controller = new SearchShortlistController();

    @FXML
    public void initialize() {
        serviceTitleCol.setCellValueFactory(cellData -> cellData.getValue().serviceTitleProperty());
        cleanerUsernameCol.setCellValueFactory(cellData -> cellData.getValue().cleanerUsernameProperty());

        // Show all by default
        int homeownerId = Session.getUserId();
        tableView.setItems(FXCollections.observableArrayList(
                controller.searchShortlist("", homeownerId)
        ));
    }


    @FXML
    public void handleSearch() {
        String keyword = searchField.getText();
        int homeownerId = Session.getUserId();
        tableView.setItems(FXCollections.observableArrayList(
                controller.searchShortlist(keyword, homeownerId)
        ));
    }

    @FXML
    public void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/HomeOwnerPage.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Home Owner Dashboard");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
