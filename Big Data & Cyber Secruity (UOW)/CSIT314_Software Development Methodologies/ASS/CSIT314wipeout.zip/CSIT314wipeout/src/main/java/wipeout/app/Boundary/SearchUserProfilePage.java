package wipeout.app.Boundary;

// UA-12 As a User Administrator, I want to search for user profiles so that I can manage users easily.
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import wipeout.app.Controller.SearchUserProfileController;
import wipeout.app.Entity.UserProfile;

import java.io.IOException;
import java.util.List;

public class SearchUserProfilePage {

    @FXML private TextField searchField;
    @FXML private Button searchButton;
    @FXML private TableView<UserProfile> profileTable;
    @FXML private TableColumn<UserProfile, Integer> idColumn;
    @FXML private TableColumn<UserProfile, String> nameColumn;
    @FXML private TableColumn<UserProfile, String> descColumn;
    @FXML private TableColumn<UserProfile, String> statusColumn;
    @FXML private TextField statusLabel;

    private final SearchUserProfileController ctrl = new SearchUserProfileController();

    @FXML
    public void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("profileId"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("profileName"));
        descColumn.setCellValueFactory(new PropertyValueFactory<>("profileDescription"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("profileStatus"));

        searchButton.setOnAction(e -> onSearch());
    }

    @FXML
    private void onSearch() {
        String keyword = searchField.getText();
        List<UserProfile> results = ctrl.searchProfiles(keyword);
        profileTable.setItems(FXCollections.observableArrayList(results));
        if (results.isEmpty()) {
            showError("No profiles found.");
        } else {
            showSuccess(results.size() + " profile(s) found.");
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/UserAdministratorPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
            showError("Failed to go back.");
        }
    }

    private void showError(String msg) {
        statusLabel.setText(msg);
        statusLabel.setStyle("-fx-text-fill: red;");
    }
    private void showSuccess(String msg) {
        statusLabel.setText(msg);
        statusLabel.setStyle("-fx-text-fill: green;");
    }
}
