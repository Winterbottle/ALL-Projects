package wipeout.app.Boundary;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import wipeout.app.Controller.SuspendUserAccountController;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class SuspendUserAccountPage {
    private VBox layout = new VBox(15);
    private TableView<String[]> table = new TableView<>();

    public static void displaySuspendUserAccountPage(Stage primaryStage) {
        ScrollPane scrollPane = new ScrollPane(new SuspendUserAccountPage(primaryStage).getView());
        scrollPane.setFitToWidth(true);
        scrollPane.setPadding(new Insets(10));

        Scene scene = new Scene(scrollPane, 800, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Suspend User Account");
        primaryStage.show();
    }

    public SuspendUserAccountPage(Stage primaryStage) {
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.TOP_LEFT);

        Label title = new Label("Suspend User Account");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        Label instruction = new Label("Double-click a user to change account status.");
        instruction.setStyle("-fx-font-size: 12px;");

        setupTable();
        populateTable(SuspendUserAccountController.getAllUsers());

        Button backBtn = new Button("Back");
        backBtn.setOnAction(this::handleBack);

        layout.getChildren().addAll(title, instruction, table, backBtn);
    }

    private void setupTable() {
        table.getColumns().clear();

        table.getColumns().addAll(
                createColumn("User ID", 0),
                createColumn("Profile ID", 1),
                createColumn("Username", 2),
                createColumn("Full Name", 3),
                createColumn("Password", 4),
                createColumn("Account Status", 5)
        );

        table.setRowFactory(tv -> {
            TableRow<String[]> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    showEditPopup(row.getItem());
                }
            });
            return row;
        });

        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    private TableColumn<String[], String> createColumn(String title, int index) {
        TableColumn<String[], String> col = new TableColumn<>(title);
        col.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue()[index]));
        return col;
    }

    private void populateTable(List<String[]> users) {
        ObservableList<String[]> data = FXCollections.observableArrayList(users);
        table.setItems(data);
    }

    private void showEditPopup(String[] user) {
        Stage popup = new Stage();
        popup.setTitle("Suspend User Account");

        Label infoLabel = new Label(
                "Username: " + user[2] + "\n" +
                        "User ID: " + user[0] + "\n" +
                        "Profile ID: " + user[1] + "\n" +
                        "Full Name: " + user[3]
        );

        ComboBox<String> statusComboBox = new ComboBox<>();
        statusComboBox.getItems().addAll(null, "Active", "Suspended");
        statusComboBox.setValue(user[5]);

        Label popupFeedback = new Label();
        popupFeedback.setStyle("-fx-text-fill: green;");

        Button updateBtn = new Button("Update Status");
        updateBtn.setOnAction(e -> {
            String newStatus = statusComboBox.getValue();
            if (newStatus == null) {
                displayErrorMsg("Please select a valid status.");
                return;
            }

            boolean updated = SuspendUserAccountController.updateAccountStatus(user[0], newStatus);
            if (updated) {
                popupFeedback.setText("User Suspended.");
                popupFeedback.setStyle("-fx-text-fill: green;");
                populateTable(SuspendUserAccountController.getAllUsers());
            } else {
                displayErrorMsg("Failed to update account status.");
            }
        });

        Button backBtn = new Button("Back");
        backBtn.setOnAction(e -> popup.close());

        VBox popupLayout = new VBox(10,
                infoLabel,
                new Label("Update Account Status:"), statusComboBox,
                updateBtn,
                popupFeedback,
                backBtn
        );
        popupLayout.setPadding(new Insets(20));
        popup.setScene(new Scene(popupLayout, 400, 300));
        popup.show();
    }

    private void displayErrorMsg(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Validation Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public VBox getView() {
        return layout;
    }

    public void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/UserAdministratorPage.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Admin Dashboard");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
