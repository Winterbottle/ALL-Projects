package wipeout.app.Boundary;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import wipeout.app.Controller.SuspendUserProfileController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SuspendUserProfilePage {
    private VBox layout = new VBox(15);
    private ComboBox<String> profileDropdown = new ComboBox<>();
    private TextField nameField = new TextField();
    private TextArea descriptionField = new TextArea();
    private ComboBox<String> statusComboBox = new ComboBox<>();
    private Label feedbackLabel = new Label();
    private final Map<String, Integer> labelToIdMap = new HashMap<>();

    public static void displaySuspendUserProfilePage(Stage primaryStage) {
        ScrollPane scrollPane = new ScrollPane(new SuspendUserProfilePage(primaryStage).getView());
        scrollPane.setFitToWidth(true);
        scrollPane.setPadding(new Insets(10));
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);

        Scene scene = new Scene(scrollPane, 600, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Suspend User Profile");
        primaryStage.show();
    }

    public SuspendUserProfilePage(Stage primaryStage) {
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.TOP_LEFT);

        Label title = new Label("Suspend User Profile");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        nameField.setEditable(false);
        descriptionField.setEditable(false);
        descriptionField.setPrefRowCount(2);
        statusComboBox.getItems().addAll("Active", "Suspended");
        feedbackLabel.setStyle("-fx-text-fill: green;");

        List<String[]> profiles = SuspendUserProfileController.getAllProfiles();
        for (String[] profile : profiles) {
            String label = profile[0] + " - " + profile[1];
            profileDropdown.getItems().add(label);
            labelToIdMap.put(label, Integer.parseInt(profile[0]));
        }

        profileDropdown.setOnAction(e -> {
            String selected = profileDropdown.getValue();
            if (selected != null && labelToIdMap.containsKey(selected)) {
                int id = labelToIdMap.get(selected);
                String[] profile = SuspendUserProfileController.getProfileById(id);
                if (profile != null) {
                    nameField.setText(profile[1]);
                    descriptionField.setText(profile[2]);
                    statusComboBox.setValue(profile[3]);
                    feedbackLabel.setText("");
                } else {
                    displayErrorMsg("Profile not found.");
                }
            }
        });

        Button suspendBtn = new Button("Update Status");
        suspendBtn.setOnAction(e -> {
            String selected = profileDropdown.getValue();
            String newStatus = statusComboBox.getValue();

            if (selected == null || !labelToIdMap.containsKey(selected)) {
                displayErrorMsg("Please select a valid profile.");
                return;
            }

            if (newStatus == null) {
                displayErrorMsg("Please choose a status.");
                return;
            }

            int id = labelToIdMap.get(selected);
            boolean updated = SuspendUserProfileController.suspendProfile(id, newStatus);
            if (updated) {
                feedbackLabel.setText("Status updated successfully.");
                feedbackLabel.setStyle("-fx-text-fill: green;");
            } else {
                displayErrorMsg("Failed to update status.");
            }
        });

        Button backBtn = new Button("Back");
        backBtn.setOnAction(this::handleBack);
        layout.getChildren().addAll(
                title,
                new Label("Select Profile:"), profileDropdown,
                new Label("Profile Name:"), nameField,
                new Label("Description:"), descriptionField,
                new Label("Status:"), statusComboBox,
                suspendBtn,
                feedbackLabel,
                backBtn
        );
    }

    private void displayErrorMsg(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Validation Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public VBox getView() {
        return layout;
    }

    public void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/UserAdministratorPage.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Admin Dashboard");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
