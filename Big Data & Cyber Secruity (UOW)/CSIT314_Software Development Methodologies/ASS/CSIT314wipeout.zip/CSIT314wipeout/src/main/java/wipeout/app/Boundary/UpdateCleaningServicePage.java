package wipeout.app.Boundary;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import wipeout.app.Controller.UpdateCleaningServiceController;
import wipeout.app.session.Session;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class UpdateCleaningServicePage {
    private VBox layout = new VBox(15);
    private TableView<String[]> table = new TableView<>();
    private int cleanerID;

    public static void displayUpdateCleaningServicePage(Stage primaryStage) {
        int cleanerID = Session.getUserId();
        UpdateCleaningServicePage view = new UpdateCleaningServicePage(primaryStage, cleanerID);
        ScrollPane scrollPane = new ScrollPane(view.getView());
        scrollPane.setFitToWidth(true);
        scrollPane.setPadding(new Insets(10));
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);

        Scene scene = new Scene(scrollPane, 800, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Update Cleaning Service");
        primaryStage.show();
    }

    public UpdateCleaningServicePage(Stage primaryStage, int cleanerID) {
        this.cleanerID = cleanerID;
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.TOP_LEFT);

        Label titleLabel = new Label("Update Cleaning Service");
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        setupTable();
        populateTable();

        Button backBtn = new Button("Back");
        backBtn.setOnAction(this::handleBack);
        layout.getChildren().addAll(titleLabel, table, backBtn);
    }

    private void setupTable() {
        table.getColumns().clear();

        table.getColumns().addAll(
                createColumn("Service ID", 0),
                createColumn("Title", 1),
                createColumn("Description", 2),
                createColumn("Price", 3)
        );

        table.setRowFactory(tv -> {
            TableRow<String[]> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    showEditPopup(row.getItem());
                }
            });
            return row;
        });

        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    private TableColumn<String[], String> createColumn(String title, int index) {
        TableColumn<String[], String> col = new TableColumn<>(title);
        col.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue()[index]));
        return col;
    }

    private void populateTable() {
        List<String[]> services = UpdateCleaningServiceController.getServicesByCleaner(cleanerID);
        ObservableList<String[]> data = FXCollections.observableArrayList(services);
        table.setItems(data);
    }

    private void showEditPopup(String[] service) {
        Stage popup = new Stage();
        popup.setTitle("Edit Cleaning Service");

        TextField titleField = new TextField(service[1]);
        TextArea descriptionField = new TextArea(service[2]);
        TextField priceField = new TextField(service[3]);

        Label feedback = new Label();
        feedback.setStyle("-fx-text-fill: green;");

        Button updateBtn = new Button("Update");
        updateBtn.setOnAction(e -> {
            String title = titleField.getText().trim();
            String description = descriptionField.getText().trim();
            String price = priceField.getText().trim();

            if (title.isEmpty() || description.isEmpty() || price.isEmpty()) {
                displayErrorMsg("All fields must be filled.");
            } else {
                try {
                    float parsedPrice = Float.parseFloat(price);
                    if (parsedPrice <= 0) {
                        displayErrorMsg("Your price must be higher than 0.");
                    } else {
                        boolean updated = UpdateCleaningServiceController.updateService(service[0], title, description, Float.parseFloat(price));
                        if (updated) {
                            feedback.setText("Service updated successfully.");
                            populateTable();
                        } else {
                            displayErrorMsg("Failed to update service.");
                        }
                    }
                }catch (NumberFormatException ex) {
                    displayErrorMsg("Price must be a valid number.");
                }
            }
        });

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setOnAction(e -> popup.close());

        VBox popupLayout = new VBox(10,
                new Label("Service ID: " + service[0]),
                new Label("Title:"), titleField,
                new Label("Description:"), descriptionField,
                new Label("Price:"), priceField,
                updateBtn,
                feedback,
                cancelBtn
        );

        popupLayout.setPadding(new Insets(20));
        popup.setScene(new Scene(popupLayout, 400, 400));
        popup.show();
    }

    private void displayErrorMsg(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Validation Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public VBox getView() {
        return layout;
    }

    public void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/CleanerPage.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Cleaner Dashboard");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
