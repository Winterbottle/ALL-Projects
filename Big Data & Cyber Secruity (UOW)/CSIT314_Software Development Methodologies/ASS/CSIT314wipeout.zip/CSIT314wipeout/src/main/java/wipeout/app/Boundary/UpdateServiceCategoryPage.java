package wipeout.app.Boundary;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import wipeout.app.Controller.UpdateServiceCategoryController;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class UpdateServiceCategoryPage {
    private VBox layout = new VBox(15);
    private TableView<String[]> table = new TableView<>();

    public static void displayUpdateServiceCategoryPage(Stage primaryStage) {
        ScrollPane scrollPane = new ScrollPane(new UpdateServiceCategoryPage(primaryStage).getView());
        scrollPane.setFitToWidth(true);
        scrollPane.setPadding(new Insets(10));
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);

        Scene scene = new Scene(scrollPane, 600, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Update Service Category");
        primaryStage.show();
    }

    public UpdateServiceCategoryPage(Stage primaryStage) {
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.TOP_LEFT);

        Label title = new Label("Update Service Categories");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        setupTable();
        populateTable();

        Button backBtn = new Button("Back");
        backBtn.setOnAction(this::handleBack);
        layout.getChildren().addAll(title, table, backBtn);
    }

    private void setupTable() {
        table.getColumns().clear();

        table.getColumns().addAll(
                createColumn("Category ID", 0),
                createColumn("Name", 1),
                createColumn("Category Description", 2)
        );

        table.setRowFactory(tv -> {
            TableRow<String[]> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    showEditPopup(row.getItem());
                }
            });
            return row;
        });

        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    private TableColumn<String[], String> createColumn(String title, int index) {
        TableColumn<String[], String> col = new TableColumn<>(title);
        col.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue()[index]));
        return col;
    }

    private void populateTable() {
        List<String[]> categories = UpdateServiceCategoryController.getAllCategories();
        ObservableList<String[]> data = FXCollections.observableArrayList(categories);
        table.setItems(data);
    }

    private void showEditPopup(String[] categoryData) {
        Stage popup = new Stage();
        popup.setTitle("Update Service Category");

        TextField nameField = new TextField(categoryData[1]);
        TextArea descArea = new TextArea(categoryData[2]);
        descArea.setPrefRowCount(3);

        Label feedback = new Label();
        feedback.setStyle("-fx-text-fill: green;");

        Button updateBtn = new Button("Update");
        updateBtn.setOnAction(e -> {
            String name = nameField.getText().trim();
            String desc = descArea.getText().trim();

            if (name.isEmpty() || desc.isEmpty()) {
                displayErrorMsg("Fields cannot be empty.");
                return;
            }

            boolean success = UpdateServiceCategoryController.updateCategory(categoryData[0], name, desc);
            if (success) {
                feedback.setText("Category updated successfully.");
                populateTable();
            } else {
                displayErrorMsg("Update failed.");
            }
        });

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setOnAction(e -> popup.close());

        VBox popupLayout = new VBox(10,
                new Label("Category ID: " + categoryData[0]),
                new Label("Name:"), nameField,
                new Label("Category Description:"), descArea,
                updateBtn, feedback, cancelBtn
        );
        popupLayout.setPadding(new Insets(20));
        popup.setScene(new Scene(popupLayout, 400, 400));
        popup.show();
    }

    private void displayErrorMsg(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Validation Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public VBox getView() {
        return layout;
    }

    public void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/PlatformManagerPage.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Platform Manager Dashboard");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
