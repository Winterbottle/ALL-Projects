//UA-05 UPDATE
//As a User Administrator, I want to update user account information
//so that user data is accurate and current
package wipeout.app.Boundary;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import wipeout.app.Controller.UpdateUserAccountController;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.IOException;

import java.util.List;
import java.util.Map;

public class UpdateUserAccountPage {
    private VBox layout = new VBox(15);
    private ComboBox<String> roleDropdown = new ComboBox<>();
    private TableView<String[]> table = new TableView<>();

    public static void displayUpdateUserAccountPage(Stage primaryStage) {
        ScrollPane scrollPane = new ScrollPane(new UpdateUserAccountPage(primaryStage).getView());
        scrollPane.setFitToWidth(true);
        scrollPane.setPadding(new Insets(10));
        Scene scene = new Scene(scrollPane, 800, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Update User Account");
        primaryStage.show();
    }

    public UpdateUserAccountPage(Stage primaryStage) {
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.TOP_LEFT);

        Label title = new Label("Update User Account");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        Label note = new Label("Double-click a row to open the editor.");
        note.setStyle("-fx-font-size: 12px;");

        setupDropdown();
        setupTable();
        populateTable(UpdateUserAccountController.getAllUsers());

        Button backBtn = new Button("Back");
        backBtn.setOnAction(this::handleBack);


        layout.getChildren().addAll(title, note, roleDropdown, table, backBtn);
    }

    private void setupDropdown() {
        roleDropdown.setPromptText("Filter by Role");
        Map<Integer, String> roles = UpdateUserAccountController.getProfileRoleMap();
        for (Map.Entry<Integer, String> entry : roles.entrySet()) {
            roleDropdown.getItems().add(entry.getKey() + " - " + entry.getValue());
        }

        roleDropdown.setOnAction(e -> {
            String selected = roleDropdown.getValue();
            if (selected != null) {
                int profileId = Integer.parseInt(selected.split(" - ")[0].trim());
                populateTable(UpdateUserAccountController.getUsersByProfile(profileId));
            }
        });
    }

    private void setupTable() {
        table.getColumns().clear();

        table.getColumns().addAll(
                createColumn("User ID", 0),
                createColumn("Profile ID", 1),
                createColumn("Username", 2),
                createColumn("Full Name", 3),
                createColumn("Password", 4),
                createColumn("Account Status", 5)
        );

        table.setRowFactory(tv -> {
            TableRow<String[]> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    showEditPopup(row.getItem());
                }
            });
            return row;
        });

        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    private TableColumn<String[], String> createColumn(String title, int index) {
        TableColumn<String[], String> col = new TableColumn<>(title);
        col.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue()[index]));
        return col;
    }

    private void populateTable(List<String[]> accounts) {
        ObservableList<String[]> data = FXCollections.observableArrayList(accounts);
        table.setItems(data);
    }

    private void showEditPopup(String[] userData) {
        Stage popup = new Stage();
        popup.setTitle("Update User Account");
        Label popupFeedback = new Label();

        Label detailLabel = new Label(
                "Username: " + userData[2] + "\n" +
                        "User ID: " + userData[0] + "\n" +
                        "Profile ID: " + userData[1] + "\n" +
                        "Account Status: " + userData[5]
        );

        TextField fullnameField = new TextField(userData[3]);
        TextField passwordField = new TextField(userData[4]);

        Button updateBtn = new Button("Update");
        updateBtn.setOnAction(e -> {
            String fullname = fullnameField.getText().trim();
            String password = passwordField.getText().trim();

            if (fullname.isEmpty() || password.isEmpty()) {
                displayErrorMsg("Full Name or Password cannot be empty.");
                return;
            }

            boolean updated = UpdateUserAccountController.updateUser(userData[0], password, fullname);
            if (updated) {
                popupFeedback.setText("User updated successfully.");
                popupFeedback.setStyle("-fx-text-fill: green;");
                populateTable(UpdateUserAccountController.getAllUsers());
            } else {
                displayErrorMsg("Failed to update user.");
            }
        });

        Button backBtn = new Button("Cancel");
        backBtn.setOnAction(e -> popup.close());

        VBox popupLayout = new VBox(10,
                detailLabel,
                new Label("Full Name:"), fullnameField,
                new Label("Password:"), passwordField,
                updateBtn,
                popupFeedback,
                backBtn
        );
        popupLayout.setPadding(new Insets(20));
        popup.setScene(new Scene(popupLayout, 400, 300));
        popup.show();
    }

    private void displayErrorMsg(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Validation Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public VBox getView() {
        return layout;
    }

    public void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/UserAdministratorPage.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Admin Dashboard");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
