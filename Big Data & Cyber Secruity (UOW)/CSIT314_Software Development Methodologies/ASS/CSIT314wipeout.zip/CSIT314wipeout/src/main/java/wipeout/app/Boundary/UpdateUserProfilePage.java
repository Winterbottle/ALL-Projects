package wipeout.app.Boundary;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import wipeout.app.Controller.UpdateUserProfileController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UpdateUserProfilePage {
    private VBox layout = new VBox(15);
    private ComboBox<String> profileIdComboBox = new ComboBox<>();
    private TextField profileNameField = new TextField();
    private TextArea descriptionField = new TextArea();
    private Label statusLabel = new Label();
    private Label feedbackLabel = new Label();

    private final Map<String, Integer> comboLabelToIdMap = new HashMap<>();

    public static void displayUpdateUserProfilePage(Stage primaryStage) {
        UpdateUserProfilePage page = new UpdateUserProfilePage(primaryStage);
        ScrollPane scrollPane = new ScrollPane(page.getView());
        scrollPane.setFitToWidth(true);
        scrollPane.setPadding(new Insets(10));

        Scene scene = new Scene(scrollPane, 600, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Update User Profile");
        primaryStage.show();
    }

    public UpdateUserProfilePage(Stage primaryStage) {
        layout.setPadding(new Insets(30));
        layout.setAlignment(Pos.TOP_LEFT);
        statusLabel.setStyle("-fx-text-fill: blue;");

        Label titleLabel = new Label("Update User Profile");
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        List<String[]> profiles = UpdateUserProfileController.getAllProfiles();
        for (String[] profile : profiles) {
            String label = profile[0] + " - " + profile[1]; // ID - Name
            profileIdComboBox.getItems().add(label);
            comboLabelToIdMap.put(label, Integer.parseInt(profile[0]));
        }

        profileIdComboBox.setOnAction(e -> {
            String selected = profileIdComboBox.getValue();
            if (selected != null && comboLabelToIdMap.containsKey(selected)) {
                int id = comboLabelToIdMap.get(selected);
                String[] profile = UpdateUserProfileController.getProfileById(id);
                if (profile != null) {
                    profileNameField.setText(profile[1]);
                    descriptionField.setText(profile[2]);
                    statusLabel.setText(profile[3]);
                    feedbackLabel.setText("");
                } else {
                    displayErrorMsg("Profile not found.");
                }
            }
        });

        Button updateBtn = new Button("Update Profile");
        updateBtn.setOnAction(e -> {
            String selected = profileIdComboBox.getValue();
            if (selected == null || !comboLabelToIdMap.containsKey(selected)) {
                displayErrorMsg("Please select a profile.");
                return;
            }

            int id = comboLabelToIdMap.get(selected);
            String name = profileNameField.getText().trim();
            String desc = descriptionField.getText().trim();
            String status = statusLabel.getText();

            if (name.isEmpty() || desc.isEmpty()) {
                displayErrorMsg("Fields cannot be empty.");
                return;
            }

            boolean updated = UpdateUserProfileController.updateProfile(id, name, desc, status);
            if (updated) {
                feedbackLabel.setText("Profile updated successfully.");
                feedbackLabel.setStyle("-fx-text-fill: green;");
            } else {
                displayErrorMsg("Update failed.");
            }
        });

        Button backBtn = new Button("Back");
        backBtn.setOnAction(this::handleBack);

        HBox statusRow = new HBox(5, new Label("Status:"), statusLabel);
        statusRow.setAlignment(Pos.CENTER_LEFT);

        VBox form = new VBox(10,
                new Label("Select Profile:"), profileIdComboBox,
                new Label("Profile Name:"), profileNameField,
                new Label("Description:"), descriptionField,
                statusRow,
                updateBtn,
                feedbackLabel,
                backBtn
        );

        layout.getChildren().addAll(titleLabel, form);
    }

    private void displayErrorMsg(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Validation Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public VBox getView() {
        return layout;
    }

    public void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/UserAdministratorPage.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Admin Dashboard");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
