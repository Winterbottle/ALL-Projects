// AdminHomePage.java
package wipeout.app.Boundary;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

import wipeout.app.session.Session;

/**
 * Boundary for Admin Dashboard; loads via FXML and handles navigation directly.
 */
public class UserAdministratorPage {
    public void show(Stage stage) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/UserAdministratorPage.fxml"));
            stage.setTitle("Admin Dashboard");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML public void handleViewAllUserAccounts(ActionEvent e) {
        changeScene(e, "/fxml/ViewUserAccountPage.fxml", "View All User Accounts");
    }
    @FXML public void handleViewAllUserProfiles(ActionEvent e) {
        changeScene(e, "/fxml/ViewUserProfilePage.fxml", "View All User Profiles");
    }
    @FXML public void handleCreateUserAccount(ActionEvent e) {
        changeScene(e, "/fxml/CreateUserAccountPage.fxml", "Create User Account");
    }
    @FXML   //For calling directly the boundary.java
    public void handleUpdateUserAccount(ActionEvent e) {
        Stage currentStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        UpdateUserAccountPage.displayUpdateUserAccountPage(currentStage);
    }

    @FXML public void handleSuspendUserAccount(ActionEvent e) {
        Stage currentStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        SuspendUserAccountPage.displaySuspendUserAccountPage(currentStage);
    }////
    @FXML public void handleSearchUserAccount(ActionEvent e) {
        changeScene(e, "/fxml/SearchUserAccountPage.fxml", "Search User Account");
    }////
    @FXML public void handleCreateUserProfile(ActionEvent e) {
        changeScene(e, "/fxml/CreateUserProfilePage.fxml", "Create User Profile");
    }
    @FXML public void handleUpdateUserProfile(ActionEvent e) {
        Stage currentStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        UpdateUserProfilePage.displayUpdateUserProfilePage(currentStage);
    }////
    @FXML public void handleSuspendUserProfile(ActionEvent e) {
        Stage currentStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        SuspendUserProfilePage.displaySuspendUserProfilePage(currentStage);
    }////
    @FXML public void handleSearchUserProfile(ActionEvent e) {
        changeScene(e, "/fxml/SearchUserProfilePage.fxml", "Search User Profile");
    }////

    @FXML
    private void handleLogout(ActionEvent e) {
        Session.clear();
        Stage currentStage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        LoginPage loginPage = new LoginPage();
        loginPage.start(currentStage);
    }


    private void changeScene(ActionEvent e, String fxmlPath, String title) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
            Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
