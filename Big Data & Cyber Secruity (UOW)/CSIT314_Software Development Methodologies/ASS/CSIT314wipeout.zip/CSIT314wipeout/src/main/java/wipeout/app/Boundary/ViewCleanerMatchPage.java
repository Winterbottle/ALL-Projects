//CL-10
// As a Cleaner, I want to view my confirmed match history filtered by services and date period so that I can review my completed jobs.
package wipeout.app.Boundary;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import wipeout.app.Controller.ViewCleanerMatchController;
import wipeout.app.Entity.BookingHistory;
import wipeout.app.session.Session;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Boundary for CL-10: View Completed Match History.
 */
public class ViewCleanerMatchPage implements Initializable {

    @FXML private ComboBox<String> comboService;
    @FXML private DatePicker dateFrom;
    @FXML private DatePicker dateTo;
    @FXML private Label errorLabel;

    @FXML private TableView<BookingHistory> tblMatches;
    @FXML private TableColumn<BookingHistory, LocalDate> colDate;
    @FXML private TableColumn<BookingHistory, String> colService;
    @FXML private TableColumn<BookingHistory, String> colClient;
    @FXML private TableColumn<BookingHistory, Double> colPrice;
    @FXML private TableColumn<BookingHistory, String> colStatus;

    // Controller handles the logic and DB connection
    private final ViewCleanerMatchController controller = new ViewCleanerMatchController();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        errorLabel.setVisible(false);

        colDate.setCellValueFactory(data -> new ReadOnlyObjectWrapper<>(data.getValue().getServiceDate()));
        colService.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getServiceTitle()));
        colClient.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getClientUsername()));
        colPrice.setCellValueFactory(data -> new ReadOnlyObjectWrapper<>(data.getValue().getPrice()));
        colStatus.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getStatus()));

        try {
            // Retrieve currently logged-in cleaner ID
            int cleanerId = Session.getUserId();

            // Fetch profile view count
            List<String> services = controller.fetchCompletedServiceTitles(cleanerId);
            displayServiceDropdown(services);

        } catch (Exception e) {
            displayErrorMsg("Unable to retrieve services.");
            e.printStackTrace();
        }
    }

    @FXML
    private void handleViewMatchHistory(ActionEvent event) {
        errorLabel.setVisible(false);
        try {
            // Retrieve currently logged-in cleaner ID
            int cleanerId = Session.getUserId();
            String service = comboService.getSelectionModel().getSelectedItem();
            LocalDate from = dateFrom.getValue();
            LocalDate to = dateTo.getValue();

            List<BookingHistory> matches = controller.fetchMatchHistory(cleanerId, service, from, to);

            if (matches.isEmpty()) {
               // 4a. No Confirmed Matches:
                displayErrorMsg("You have no confirmed matches yet.");
            }else {
                displayMatches(matches);
            }
        } catch (Exception e) {
            // 4a. No Confirmed Matches:
            displayErrorMsg("You have no confirmed matches yet.");
            e.printStackTrace();
        }
    }

    //Sets the errorLabel to the provided message and makes it visible.
    private void displayErrorMsg(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
        tblMatches.setItems(FXCollections.observableArrayList());
    }
    private void displayMatches(List<BookingHistory> matches) {
        ObservableList<BookingHistory> observableList = FXCollections.observableArrayList(matches);
        tblMatches.setItems(observableList);
    }

    private void displayServiceDropdown(List<String> services) {
        ObservableList<String> observable = FXCollections.observableArrayList(services);
        observable.add(0, "All Services");
        comboService.setItems(observable);
        comboService.getSelectionModel().selectFirst();
    }




    //Navigates back to the Cleaner dashboard.
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/CleanerPage.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Cleaner Dashboard");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
