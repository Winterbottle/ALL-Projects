//CL-08
//As a Cleaner, I want to view how many times my profile was viewed so that I can track service visibility.
package wipeout.app.Boundary;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import wipeout.app.Controller.ViewCleanerProfileViewsController;
import wipeout.app.Entity.CleaningService;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Boundary for CL-08: View how many times cleaner profile was viewed.
 */
public class ViewCleanerProfileViewsPage implements Initializable {

    @FXML private Label profileViewsLabel;
    @FXML private Label errorLabel;

    // Controller handles the logic and DB connection
    private final ViewCleanerProfileViewsController controller = new ViewCleanerProfileViewsController();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        errorLabel.setVisible(false);

        try {
            // Retrieve currently logged-in cleaner ID
            int cleanerId = wipeout.app.session.Session.getUserId();

            // Fetch profile view count
            List<CleaningService> result = controller.fetchProfileViews(cleanerId);

            // Display view count if present
            if (!result.isEmpty()) {
                displayProfileViews(result);
            }
            else {
                // 4a. Insufficient Data:
                displayErrorMsg("Unable to retrieve profile views.");
            }

        } catch (Exception e) {
            // 4a. Insufficient Data:
            displayErrorMsg("Unable to retrieve profile views.");
            e.printStackTrace();
        }
    }

    //Sets the errorLabel to the provided message and makes it visible.
    private void displayErrorMsg(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }

    private void displayProfileViews(List<CleaningService> views) {
        int count = views.get(0).getViewCount();
        profileViewsLabel.setText("Your profile has been viewed " + count + " times.");
    }

    //Navigates back to the Cleaner dashboard.
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/CleanerPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Cleaner Dashboard");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
