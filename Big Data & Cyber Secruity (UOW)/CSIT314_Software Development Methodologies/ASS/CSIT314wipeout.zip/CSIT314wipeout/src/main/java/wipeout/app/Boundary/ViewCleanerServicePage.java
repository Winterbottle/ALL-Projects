//CL-04
//As a Cleaner, I want to view my cleaning services so that I can monitor what I offer.
package wipeout.app.Boundary;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import wipeout.app.Controller.ViewCleanerServiceController;
import wipeout.app.Entity.CleaningService;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Boundary for CL‑04: View My Cleaning Services.
 */
public class ViewCleanerServicePage implements Initializable {

    @FXML private TableView<CleaningService> servicesTable;
    @FXML private TableColumn<CleaningService, String> titleColumn;
    @FXML private TableColumn<CleaningService, String> descriptionColumn;
    @FXML private TableColumn<CleaningService, Double> priceColumn;
    @FXML private Label errorLabel;

    // Controller handles the logic and DB connection
    private final ViewCleanerServiceController controller = new ViewCleanerServiceController();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        errorLabel.setVisible(false);

        titleColumn.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getServiceTitle()));
        descriptionColumn.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getServiceDescription()));
        priceColumn.setCellValueFactory(data -> new ReadOnlyObjectWrapper<>(data.getValue().getPrice()));

        // Get logged-in cleaner ID and fetch services
        try {
            int cleanerId = wipeout.app.session.Session.getUserId();
            System.out.println("Logged-in cleanerId = " + cleanerId);

            List<CleaningService> list = controller.fetchAllServices(cleanerId);

            if (list.isEmpty()) {
                //4b. No Services Available:
                displayErrorMsg("You have no cleaning services listed.");
                return;
            }

            displayCleanerServices(list);
        } catch (Exception e) {
            //4a. Retrieval Error:
            displayErrorMsg("Unable to retrieve services.");
            e.printStackTrace();
        }
    }

    //Sets the errorLabel to the provided message and makes it visible.
    private void displayErrorMsg(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
        servicesTable.setItems(FXCollections.observableArrayList());
    }

    private void displayCleanerServices(List<CleaningService> services) {
        ObservableList<CleaningService> observableList = FXCollections.observableArrayList(services);
        servicesTable.setItems(observableList);
    }

    //Navigates back to the Cleaner dashboard.
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/CleanerPage.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Cleaner Dashboard");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
