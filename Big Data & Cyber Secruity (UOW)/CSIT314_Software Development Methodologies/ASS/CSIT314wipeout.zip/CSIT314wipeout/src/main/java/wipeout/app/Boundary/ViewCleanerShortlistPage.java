//CL-09
//As a Cleaner, I want to view how many times I was shortlisted so that I can gauge my service popularity.
package wipeout.app.Boundary;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import wipeout.app.Controller.ViewCleanerShortlistController;
import wipeout.app.Entity.Shortlist;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Boundary for CL-09: View how many times cleaner was shortlisted.
 */
public class ViewCleanerShortlistPage implements Initializable {

    @FXML private Label errorLabel;
    @FXML private Label shortlistLabel;


    // Controller handles the logic and DB connection
    private final ViewCleanerShortlistController controller = new ViewCleanerShortlistController();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        errorLabel.setVisible(false);

        try {
            // Retrieve currently logged-in cleaner ID
            int cleanerId = wipeout.app.session.Session.getUserId();

            // Fetch Shortlist count
            List<Shortlist> result = controller.fetchShortlistCount(cleanerId);

            // Display view count if present
            if (!result.isEmpty()) {
                displayShortlist(result);
            } else {
                displayErrorMsg("Unable to retrieve shortlist data.");
            }

        } catch (Exception e) {
            //4a.Insufficient Data
            displayErrorMsg("Unable to retrieve shortlist data.");
            e.printStackTrace();
        }
    }

    //Sets the errorLabel to the provided message and makes it visible.
    private void displayErrorMsg(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }


    private void displayShortlist(List<Shortlist> shortlist) {
        int count = shortlist.get(0).getShortlistCount();
        shortlistLabel.setText("You have been shortlisted " + count + " times.");
    }

    //Navigates back to the Cleaner dashboard.
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/CleanerPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Cleaner Dashboard");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
