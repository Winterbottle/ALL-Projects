package wipeout.app.Boundary;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.collections.*;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.stage.Stage;
import wipeout.app.Controller.ViewCleaningServiceController;
import wipeout.app.Entity.CleaningService;
import wipeout.app.session.Session;
import wipeout.app.Controller.AddShortlistController;

public class ViewCleaningServicePage {
    private int homeownerID = Session.getUserId();
    @FXML private TableView<CleaningService> servicesTable;
    @FXML private TableColumn<CleaningService, String> titleColumn;
    @FXML private TableColumn<CleaningService, String> descriptionColumn;
    @FXML private TableColumn<CleaningService, Double> priceColumn;
    @FXML private TableColumn<CleaningService, Void> actionCol;


    @FXML
    public void initialize() {
        titleColumn.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getServiceTitle()));
        descriptionColumn.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getServiceDescription()));
        priceColumn.setCellValueFactory(data -> new ReadOnlyObjectWrapper<>(data.getValue().getPrice()));

        ViewCleaningServiceController controller = new ViewCleaningServiceController();
        ObservableList<CleaningService> list = FXCollections.observableArrayList(controller.fetchAllServices());
        servicesTable.setItems(list);
        addShortlistButtonToTable(homeownerID);
    }

    private void addShortlistButtonToTable(int homeOwnerID) {
        actionCol.setCellFactory(param -> new TableCell<>() {
            private final Button btn = new Button("Add to Shortlist");

            {
                btn.setOnAction(event -> {
                    CleaningService service = getTableView().getItems().get(getIndex());
                    int serviceID = service.getServiceId();

                    AddShortlistController shortlistController = new AddShortlistController();
                    boolean success = shortlistController.addToShortlist(homeOwnerID, serviceID);

                    Alert alert = new Alert(success ? Alert.AlertType.INFORMATION : Alert.AlertType.ERROR);
                    alert.setTitle(success ? "Success" : "Failed");
                    alert.setHeaderText(null);
                    alert.setContentText(success ? "Service added to shortlist." : "Already shortlisted or failed.");
                    alert.showAndWait();
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : btn);
            }
        });
    }
    //Navigates back to the Cleaner dashboard.
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/HomeOwnerPage.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("HomeOwner Dashboard");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
