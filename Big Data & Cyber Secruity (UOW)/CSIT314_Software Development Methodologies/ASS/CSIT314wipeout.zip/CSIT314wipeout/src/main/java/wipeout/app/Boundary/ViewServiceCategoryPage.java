//PM-04
//As a Platform Manager, I want to view cleaning services categories so that I can monitor existing categories.
package wipeout.app.Boundary;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import wipeout.app.Controller.ViewServiceCategoryController;
import wipeout.app.Entity.ServiceCategory;
import wipeout.app.session.Session;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Boundary for PM-04: View Cleaning Service Categories.
 */
public class ViewServiceCategoryPage implements Initializable {

    @FXML private TableView<ServiceCategory> categoryTable;
    @FXML private TableColumn<ServiceCategory, Integer> colId;
    @FXML private TableColumn<ServiceCategory, String> colName;
    @FXML private TableColumn<ServiceCategory, String> colDescription;
    @FXML private TableColumn<ServiceCategory, String> colService;
    @FXML private TableColumn<ServiceCategory, String> colCleaner;
    @FXML private Label errorLabel;

    // Controller handles the logic and DB connection
    private final ViewServiceCategoryController controller = new ViewServiceCategoryController();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        errorLabel.setVisible(false);

        if (!"Platform Manager".equals(Session.getProfileName())) {
            //4a. Insufficient Privileges:
            displayErrorMsg("You do not have the required privileges to view cleaning service categories");
            return;
        }

        // Link table columns
        colId.setCellValueFactory(data -> new javafx.beans.property.ReadOnlyObjectWrapper<>(data.getValue().getCategoryId()));
        colName.setCellValueFactory(data -> new javafx.beans.property.ReadOnlyStringWrapper(data.getValue().getCategoryName()));
        colDescription.setCellValueFactory(data -> new javafx.beans.property.ReadOnlyStringWrapper(data.getValue().getCategoryDescription()));
        colService.setCellValueFactory(data -> new javafx.beans.property.ReadOnlyStringWrapper(data.getValue().getServiceTitle()));
        colCleaner.setCellValueFactory(data -> new javafx.beans.property.ReadOnlyStringWrapper(data.getValue().getCleanerUsername()));

        try {
            List<ServiceCategory> categories = controller.fetchAllCategories();
            for (ServiceCategory cat : categories) {
                System.out.println("ID: " + cat.getCategoryId());
            }
            if (categories.isEmpty()) {
                displayErrorMsg("No cleaning service categories found.");
            } else {
                displayCategories(categories);
            }
        } catch (Exception e) {
            displayErrorMsg("Failed to load category data.");
            e.printStackTrace();
        }
    }

    //Sets the errorLabel to the provided message and makes it visible.
    private void displayErrorMsg(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }


    private void displayCategories(List<ServiceCategory> categories) {
        ObservableList<ServiceCategory> observableList = FXCollections.observableArrayList(categories);
        categoryTable.setItems(observableList);
    }

    //Navigates back to the Home Owner dashboard.
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/PlatformManagerPage.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Platform Manager Dashboard");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
