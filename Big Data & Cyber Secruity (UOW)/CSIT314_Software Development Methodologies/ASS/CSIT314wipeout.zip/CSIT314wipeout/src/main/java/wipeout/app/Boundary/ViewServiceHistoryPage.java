package wipeout.app.Boundary;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import wipeout.app.Controller.ViewServiceHistoryController;
import wipeout.app.Entity.BookingHistory;

import java.time.LocalDate;
import java.util.List;

public class ViewServiceHistoryPage {

    @FXML private TextField serviceSearchField;
    @FXML private DatePicker dateFrom;
    @FXML private DatePicker dateTo;
    @FXML private TableView<BookingHistory> tblHistory;
    @FXML private TableColumn<BookingHistory, String> colService;
    @FXML private TableColumn<BookingHistory, String> colCleaner;
    @FXML private TableColumn<BookingHistory, LocalDate> colDate;
    @FXML private TableColumn<BookingHistory, Double> colPrice;
    @FXML private TableColumn<BookingHistory, String> colStatus;
    @FXML private Label errorLabel;

    private final ViewServiceHistoryController controller = new ViewServiceHistoryController();

    @FXML
    public void initialize() {
        // Table setup
        colService.setCellValueFactory(cell -> new ReadOnlyStringWrapper(cell.getValue().getServiceTitle()));
        colCleaner.setCellValueFactory(cell -> new ReadOnlyStringWrapper(cell.getValue().getClientUsername()));
        colDate.setCellValueFactory(cell -> new ReadOnlyObjectWrapper<>(cell.getValue().getServiceDate()));
        colPrice.setCellValueFactory(cell -> new ReadOnlyObjectWrapper<>(cell.getValue().getPrice()));
        colStatus.setCellValueFactory(cell -> new ReadOnlyStringWrapper(cell.getValue().getStatus()));

        // Populate service dropdown
        List<String> titles = controller.getServiceTitles();
        ObservableList<String> items = FXCollections.observableArrayList(titles);
        items.add(0, "All Services");

        // Load all history by default (no filters)
        List<BookingHistory> history = controller.getFilteredHistory("All Services", null, null);
        if (history.isEmpty()) {
            errorLabel.setText("You have no service history yet.");
            errorLabel.setVisible(true);
        } else {
            errorLabel.setVisible(false);
            tblHistory.setItems(FXCollections.observableArrayList(history));
        }
    }

    @FXML
    private void handleFilterHistory() {
        String searchKeyword = serviceSearchField.getText();
        LocalDate from = dateFrom.getValue();
        LocalDate to = dateTo.getValue();

        List<BookingHistory> history = controller.getFilteredHistory(searchKeyword, from, to);

        if (history.isEmpty()) {
            errorLabel.setText("No service history found.");
            errorLabel.setVisible(true);
            tblHistory.setItems(FXCollections.observableArrayList());
        } else {
            errorLabel.setVisible(false);
            tblHistory.setItems(FXCollections.observableArrayList(history));
        }
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/HomeOwnerPage.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Home Owner Dashboard");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
