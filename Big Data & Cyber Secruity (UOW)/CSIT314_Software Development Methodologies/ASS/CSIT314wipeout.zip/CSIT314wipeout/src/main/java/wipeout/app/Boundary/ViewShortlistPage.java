package wipeout.app.Boundary;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import wipeout.app.Controller.ViewShortlistController;
import wipeout.app.Entity.CleaningService;

import java.io.IOException;
import java.util.List;

public class ViewShortlistPage {
    @FXML private TableView<CleaningService> shortlistTable;
    @FXML private TableColumn<CleaningService, Integer> serviceIDColumn;
    @FXML private TableColumn<CleaningService, Integer> cleanerIDColumn;
    @FXML private TableColumn<CleaningService, String> titleColumn;
    @FXML private TableColumn<CleaningService, String> descriptionColumn;
    @FXML private TableColumn<CleaningService, Float> priceColumn;
    @FXML private TableColumn<CleaningService, Integer> viewCountColumn;
    @FXML private TableColumn<CleaningService, Integer> shortlistCountColumn;
    @FXML private TableColumn<CleaningService, java.sql.Date> dateCreatedColumn;
    @FXML private Button backButton;

    private ViewShortlistController controller;

    @FXML
    public void initialize() {
        controller = new ViewShortlistController();

        serviceIDColumn.setCellValueFactory(new PropertyValueFactory<>("serviceId"));
        cleanerIDColumn.setCellValueFactory(new PropertyValueFactory<>("cleanerId"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("serviceTitle"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("serviceDescription"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        viewCountColumn.setCellValueFactory(new PropertyValueFactory<>("viewCount"));
        shortlistCountColumn.setCellValueFactory(new PropertyValueFactory<>("shortlistCount"));
        dateCreatedColumn.setCellValueFactory(new PropertyValueFactory<>("dateCreated"));

        List<CleaningService> services = controller.getShortlistedServices();
        shortlistTable.getItems().setAll(services);
    }

    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/HomeOwnerPage.fxml"));
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Home Owner Dashboard");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
