//UA-04
// As a User Administrator, I want to view all user accounts so that I can monitor the users.
package wipeout.app.Boundary;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import wipeout.app.Controller.ViewUserAccountController;
import wipeout.app.Entity.UserAccount;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

/**
 * Boundary for UA-04: View All User Accounts.
 */
public class ViewUserAccountPage implements Initializable {

    @FXML private TableView<UserAccount> table;
    @FXML private TableColumn<UserAccount, Integer> colUserId;
    @FXML private TableColumn<UserAccount, String> colUsername;
    @FXML private TableColumn<UserAccount, String> colRole;
    @FXML private TableColumn<UserAccount, String> colFullname;
    @FXML private TableColumn<UserAccount, String> colStatus;
    @FXML private Label errorLabel;

    // Controller handles the logic and DB connection
    private final ViewUserAccountController controller = new ViewUserAccountController();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        errorLabel.setVisible(false);

        colUserId.setCellValueFactory(cell -> new javafx.beans.property.ReadOnlyObjectWrapper<>(cell.getValue().getUserId()));
        colUsername.setCellValueFactory(cell -> new javafx.beans.property.ReadOnlyStringWrapper(cell.getValue().getUsername()));
        colRole.setCellValueFactory(cell -> new javafx.beans.property.ReadOnlyStringWrapper(cell.getValue().getProfileName()));
        colFullname.setCellValueFactory(cell -> new javafx.beans.property.ReadOnlyStringWrapper(cell.getValue().getFullname()));
        colStatus.setCellValueFactory(cell -> new javafx.beans.property.ReadOnlyStringWrapper(cell.getValue().getAccountStatus()));

        try {
            List<UserAccount> accounts = controller.fetchUserAccounts();
            if (accounts.isEmpty()) {
                //4a. No User Accounts Available:
                displayErrorMsg("No users available to display.");
            } else {
                displayUserAccounts(accounts);
            }
        } catch (Exception e) {
            //4b. Insufficient Privileges
            displayErrorMsg("You do not have the required privileges.");
            e.printStackTrace();
        }
    }

    // Sets the errorLabel to the provided message and makes it visible.
    private void displayErrorMsg(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }

    private void displayUserAccounts(List<UserAccount> accounts) {
        ObservableList<UserAccount> observableList = FXCollections.observableArrayList(accounts);
        table.setItems(observableList);
    }

    //Navigates back to the User Admin dashboard.
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/UserAdministratorPage.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
