package wipeout.app.Controller;

import wipeout.app.Entity.Shortlist;

public class AddShortlistController {

    public boolean addToShortlist(int homeOwnerID, int serviceID) {

        if (Shortlist.isServiceAlreadyShortlisted(homeOwnerID, serviceID)) {
            return false; // Already in shortlist
        }

        return Shortlist.saveToDatabase(homeOwnerID, serviceID);
    }
}
