package wipeout.app.Controller;

import wipeout.app.Entity.CleaningService;

import java.util.List;

public class CreateCleaningServiceController {
    public int createCleaningService(int cleanerID, String title, String description, double price, List<Integer> categoryIds) {
        CleaningService service = new CleaningService(cleanerID, title, description, price);
        service.setCategoryIds(categoryIds);
        return service.saveToDatabase();
    }
}
