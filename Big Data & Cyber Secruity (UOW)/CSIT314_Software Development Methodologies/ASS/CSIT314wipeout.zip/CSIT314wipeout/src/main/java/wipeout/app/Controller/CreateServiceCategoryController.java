package wipeout.app.Controller;

import wipeout.app.Entity.ServiceCategory;

public class CreateServiceCategoryController {

    public int createCategory(String name, String description) {
        ServiceCategory category = new ServiceCategory(name, description);
        return category.saveToDatabase();
    }
}




