package wipeout.app.Controller;
import wipeout.app.Entity.UserAccount;

public class CreateUserAccountController {

    public int createUserAccount(String username, String password, String fullName, String accountStatus, int profileID) {
        UserAccount account = new UserAccount(profileID, username, password, fullName, accountStatus);
        return account.saveToDatabase();
    }
}





