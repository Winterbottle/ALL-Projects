package wipeout.app.Controller;

import wipeout.app.Entity.UserProfile;

public class CreateUserProfileController {

    public int createUserProfile(String profileName, String profileDescription, String profileStatus) {
        UserProfile profile = new UserProfile(profileName, profileDescription, profileStatus);
        return profile.saveToDatabase();
    }
}




