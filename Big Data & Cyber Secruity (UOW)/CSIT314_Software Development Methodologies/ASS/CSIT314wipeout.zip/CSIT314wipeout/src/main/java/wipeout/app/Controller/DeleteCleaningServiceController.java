package wipeout.app.Controller;

import wipeout.app.Entity.CleaningService;
import wipeout.app.Database.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

public class DeleteCleaningServiceController {

    public static List<String[]> getServicesByCleaner(int cleanerId) {
        return CleaningService.getServicesByCleanerAsArray(cleanerId);
    }

    public static boolean deleteService(String serviceIdStr) {
        try (Connection conn = DBConnection.getConnection()) {
            int serviceId = Integer.parseInt(serviceIdStr);

            try (PreparedStatement stmt1 = conn.prepareStatement("DELETE FROM servicecategorymap WHERE serviceID = ?")) {
                stmt1.setInt(1, serviceId);
                stmt1.executeUpdate();
            }

            try (PreparedStatement stmt2 = conn.prepareStatement("DELETE FROM serviceavailability WHERE serviceID = ?")) {
                stmt2.setInt(1, serviceId);
                stmt2.executeUpdate();
            }

            return CleaningService.deleteService(conn, serviceId);
        } catch (Exception ignored) {
            return false;
        }
    }
}
