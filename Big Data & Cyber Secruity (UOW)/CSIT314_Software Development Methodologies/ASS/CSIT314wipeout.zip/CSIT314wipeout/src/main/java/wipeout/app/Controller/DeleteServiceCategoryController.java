package wipeout.app.Controller;

import wipeout.app.Entity.ServiceCategory;
import java.util.ArrayList;
import java.util.List;

public class DeleteServiceCategoryController {

    public static List<String> getAllCategoryLabels() {
        List<String> labels = new ArrayList<>();
        for (String[] cat : ServiceCategory.getAllAsArray()) {
            labels.add(cat[0] + " - " + cat[1]);
        }
        return labels;
    }

    public static String[] getCategoryById(int id) {
        return ServiceCategory.getByIdAsArray(id);
    }

    public static boolean deleteCategory(int id) {
        return ServiceCategory.deleteCategory(id);
    }
}
