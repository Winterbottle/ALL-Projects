package wipeout.app.Controller;
//PM-08 As a Platform Manager, I want to generate daily reports so that I can monitor short-term activity.
import wipeout.app.Entity.AdminReport;

import java.sql.Date;
import java.util.List;

public class GenerateDailyReportController {

    public List<AdminReport> fetchDailyReport(Date selectedDate, int platformManagerId) {
        return AdminReport.generateDailyReport(selectedDate, platformManagerId);
    }
}
