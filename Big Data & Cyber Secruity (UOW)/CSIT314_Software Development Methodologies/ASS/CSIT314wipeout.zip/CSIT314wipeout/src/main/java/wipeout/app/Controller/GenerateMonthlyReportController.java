package wipeout.app.Controller;
//PM-10 As a Platform Manager, I want to generate monthly reports so that I can analyze long-term performance.
import wipeout.app.Entity.AdminReport;

import java.sql.Date;
import java.util.List;

public class GenerateMonthlyReportController {

    public List<AdminReport> fetchMonthlyReport(Date selectedDate, int managerId) {
        return AdminReport.generateMonthlyReport(selectedDate, managerId);
    }
}
