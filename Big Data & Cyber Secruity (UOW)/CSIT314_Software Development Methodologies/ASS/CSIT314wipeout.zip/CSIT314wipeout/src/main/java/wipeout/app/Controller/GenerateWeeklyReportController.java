package wipeout.app.Controller;
//PM-09 As a Platform Manager, I want to generate weekly reports so that I can track performance over the week.
import wipeout.app.Entity.AdminReport;

import java.sql.Date;
import java.util.Calendar;
import java.util.List;

public class GenerateWeeklyReportController {
    public List<AdminReport> fetchWeeklyReport(Date selectedDate, int managerId) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(selectedDate);
        cal.add(Calendar.DAY_OF_MONTH, -6);
        Date startDate = new Date(cal.getTimeInMillis());
        return AdminReport.generateWeeklyReport(startDate, selectedDate, managerId);
    }
}
