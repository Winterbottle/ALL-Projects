package wipeout.app.Controller;

import wipeout.app.Entity.UserAccount;
import wipeout.app.session.Session;
// For User Stories: UA-01, HO-01, CL-01, PM-01
// === Controller class for handling user login requests ===
//  Acts as the middle layer between Boundary and the Entity
//  It handles login requests by delegating authentication checks.
public class LoginController {
//    public int login(String username, String password, String userprofile) {
//        UserAccount user = new UserAccount(); // Create a UserAccount instance
//        return user.verifyLogin(username, password, userprofile); // Delegate verification to UserAccount
//    }
    public int login(String username, String password, String userprofile) {
        UserAccount user = new UserAccount();
        int id = user.verifyLogin(username, password, userprofile);

        if (id > 0) {
            UserAccount userSession = user.getUserAccountById(id);
            if (userSession != null) {
                Session.start(userSession.getUserId(), userSession.getUsername(), userSession.getProfileName());
            }
        }

        return id;
    }

}