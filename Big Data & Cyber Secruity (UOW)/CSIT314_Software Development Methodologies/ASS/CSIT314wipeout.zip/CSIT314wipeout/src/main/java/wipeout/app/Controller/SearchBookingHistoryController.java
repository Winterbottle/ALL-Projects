package wipeout.app.Controller;

import wipeout.app.Entity.BookingHistory;

import java.time.LocalDate;
import java.util.List;

public class SearchBookingHistoryController {
    public List<BookingHistory> search(int homeownerId, String serviceTitle, LocalDate fromDate, LocalDate toDate) {
        return BookingHistory.fetchHistoryForHomeOwner(homeownerId, serviceTitle, fromDate, toDate);
    }

    public List<String> getServiceTitles(int homeownerId) {
        return BookingHistory.fetchServiceTitlesForHomeOwner(homeownerId);
    }
}
