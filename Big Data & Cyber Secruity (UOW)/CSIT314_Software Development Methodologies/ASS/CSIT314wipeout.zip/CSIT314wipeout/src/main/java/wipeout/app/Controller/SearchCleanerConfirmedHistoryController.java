package wipeout.app.Controller;

import wipeout.app.Entity.BookingHistory;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class SearchCleanerConfirmedHistoryController {

    public static List<BookingHistory> getMatchHistory(int cleanerId, String title, LocalDate from, LocalDate to) throws SQLException {
        return BookingHistory.fetchMatchHistory(cleanerId, title, from, to);
    }

    public static List<String> getCompletedServiceTitles(int cleanerId) throws SQLException {
        return BookingHistory.fetchCompletedServiceTitles(cleanerId);
    }
}
