package wipeout.app.Controller;

import wipeout.app.Entity.CleaningService;
import java.sql.SQLException;
import java.util.List;

public class SearchCleanerServicesController {

    public List<CleaningService> getAllServicesByCleaner(int cleanerId) throws SQLException {
        return CleaningService.fetchAllByCleaner(cleanerId);
    }

    public List<CleaningService> searchCleanerServicesByKeyword(int cleanerId, String keyword) throws SQLException {
        return CleaningService.searchCleanerServiceByOwner(cleanerId, keyword);
    }
}
