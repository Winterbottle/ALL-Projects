package wipeout.app.Controller;

//HO-04 As a Home Owner, I want to search for cleaning services so that I can find services that meet my needs.
import wipeout.app.Entity.CleaningService;
import java.util.List;
public class SearchCleaningServiceController {

    /**
     * Searches for cleaning services based on keyword.
     * @param keyword search term
     * @return matching CleaningService list
     */
    public List<CleaningService> searchServices(String keyword) {
        return CleaningService.search(keyword);
    }
}
