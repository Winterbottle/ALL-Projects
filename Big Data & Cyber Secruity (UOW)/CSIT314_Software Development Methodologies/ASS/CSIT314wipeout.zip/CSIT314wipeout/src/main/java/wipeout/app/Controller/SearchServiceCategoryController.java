package wipeout.app.Controller;
//PM-07 As a Platform Manager, I want to search cleaning services categories so that I can find specific categories quickly.
import wipeout.app.Entity.ServiceCategory;
import java.util.List;

/**
 * Controller for PM-07: Search Cleaning Service Categories
 */
public class SearchServiceCategoryController {

    /**
     * Delegate to the entity’s static search.
     */
    public List<ServiceCategory> searchCategories(String keyword) {
        return ServiceCategory.searchCategories(keyword);
    }
}

