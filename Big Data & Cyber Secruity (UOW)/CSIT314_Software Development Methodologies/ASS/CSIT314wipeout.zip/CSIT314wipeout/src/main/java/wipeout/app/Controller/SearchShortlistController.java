package wipeout.app.Controller;

// HO-07: As a Home Owner, I want to search my favourite list so that I can find the shortlisted cleaners easily.
import wipeout.app.Entity.Shortlist;
import java.util.List;

/**
 * Controller for HO-07: Search Favourite List (Shortlist)
 */
public class SearchShortlistController {

    /**
     * Delegates search to the Shortlist entity.
     */
    public List<Shortlist> searchShortlist(String keyword, int homeownerId) {
        return Shortlist.searchShortlist(keyword, homeownerId);
    }
}
