package wipeout.app.Controller;

//UA-07 As a User Administrator, I want to search for user accounts so that I can quickly find specific users.
import wipeout.app.Entity.UserAccount;
import java.util.List;

public class SearchUserAccountController {

    /**
     * Searches for user accounts matching the given keyword.
     * @param keyword search term (ID, username, fullname, etc.)
     * @return list of matching UserAccount objects
     */
    public List<UserAccount> searchUsers(String keyword) {
        return UserAccount.search(keyword);
    }
}
