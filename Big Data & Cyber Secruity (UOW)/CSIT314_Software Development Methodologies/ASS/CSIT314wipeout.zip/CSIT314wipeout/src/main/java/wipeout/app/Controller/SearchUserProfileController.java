package wipeout.app.Controller;

//UA-12 As a User Administrator, I want to search for user profiles so that I can manage users easily.
import wipeout.app.Entity.UserProfile;
import java.util.List;

public class SearchUserProfileController {

    /**
     * Delegate to UserProfile.search(keyword).
     */
    public List<UserProfile> searchProfiles(String keyword) {
        return UserProfile.search(keyword);
    }
}
