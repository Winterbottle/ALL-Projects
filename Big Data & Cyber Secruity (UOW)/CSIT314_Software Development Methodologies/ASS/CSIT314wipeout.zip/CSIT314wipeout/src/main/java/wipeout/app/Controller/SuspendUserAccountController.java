package wipeout.app.Controller;

import wipeout.app.Entity.UserAccount;
import java.util.List;

public class SuspendUserAccountController {

    public static List<String[]> getAllUsers() {
        return UserAccount.getAllAsArray();
    }

    public static boolean updateAccountStatus(String userIdStr, String newStatus) {
        try {
            int userId = Integer.parseInt(userIdStr);
            return UserAccount.suspendUser(userId, newStatus);
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
