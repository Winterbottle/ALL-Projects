package wipeout.app.Controller;

import wipeout.app.Entity.UserProfile;
import java.util.List;

public class SuspendUserProfileController {

    public static List<String[]> getAllProfiles() {
        return UserProfile.getAllAsArray();
    }

    public static String[] getProfileById(int profileId) {
        return UserProfile.getByIdAsArray(profileId);
    }

    public static boolean suspendProfile(int profileId, String newStatus) {
        return UserProfile.suspendProfile(profileId, newStatus);
    }
}
