package wipeout.app.Controller;

import wipeout.app.Entity.CleaningService;
import java.util.List;

public class UpdateCleaningServiceController {

    public static List<String[]> getServicesByCleaner(int cleanerID) {
        return CleaningService.findByCleanerAsArray(cleanerID);
    }

    public static boolean updateService(String serviceId, String title, String description, double price) {
        try {
            return CleaningService.updateService(
                    Integer.parseInt(serviceId),
                    title,
                    description,
                    price);
        } catch (NumberFormatException e) {
            return false;
        }
    }
}