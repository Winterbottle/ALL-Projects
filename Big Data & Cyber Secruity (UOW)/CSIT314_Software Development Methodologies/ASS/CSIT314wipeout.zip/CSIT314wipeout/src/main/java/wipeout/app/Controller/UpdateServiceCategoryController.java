package wipeout.app.Controller;

import wipeout.app.Entity.ServiceCategory;
import java.util.List;

public class UpdateServiceCategoryController {

    public static List<String[]> getAllCategories() {
        List<String[]> result = ServiceCategory.getAllAsArray();
        return result;
    }

    public static boolean updateCategory(String categoryIdStr, String name, String description) {
        try {
            int id = Integer.parseInt(categoryIdStr);
            return ServiceCategory.updateCategory(id, name, description);
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
