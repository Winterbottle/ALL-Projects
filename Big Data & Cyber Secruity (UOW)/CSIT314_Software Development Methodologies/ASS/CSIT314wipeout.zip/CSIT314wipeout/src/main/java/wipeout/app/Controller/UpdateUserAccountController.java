//UA-05 UPDATE
//As a User Administrator, I want to update user account information
//so that user data is accurate and current
package wipeout.app.Controller;

import wipeout.app.Entity.UserAccount;
import wipeout.app.Entity.UserProfile;
import java.util.List;
import java.util.Map;

public class UpdateUserAccountController {

    public static List<String[]> getAllUsers() {
        return UserAccount.getAllAsArray();
    }

    public static List<String[]> getUsersByProfile(int profileId) {
        return UserAccount.getByProfileAsArray(profileId);
    }

    public static boolean updateUser(String userIdStr, String newPassword, String newFullname) {
        try {
            int userId = Integer.parseInt(userIdStr);
            return UserAccount.updateUser(userId, newPassword, newFullname);
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static Map<Integer, String> getProfileRoleMap() {
        return UserProfile.getRoleIdToName();
    }
}
