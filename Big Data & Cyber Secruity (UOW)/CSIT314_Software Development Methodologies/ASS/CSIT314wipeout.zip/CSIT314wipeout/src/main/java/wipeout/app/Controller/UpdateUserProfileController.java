//UA-10 UPDATE
//As a User Administrator, I want to update user profiles
//so that I can reflect changes in user roles.
package wipeout.app.Controller;

import wipeout.app.Entity.UserProfile;
import java.util.List;

public class UpdateUserProfileController {

    public static List<String[]> getAllProfiles() {
        return UserProfile.getAllAsArray();
    }

    public static String[] getProfileById(int profileId) {
        return UserProfile.getByIdAsArray(profileId);
    }

    public static boolean updateProfile(int id, String name, String desc, String status) {
        return UserProfile.updateProfile(id, name, desc, status);
    }
}
