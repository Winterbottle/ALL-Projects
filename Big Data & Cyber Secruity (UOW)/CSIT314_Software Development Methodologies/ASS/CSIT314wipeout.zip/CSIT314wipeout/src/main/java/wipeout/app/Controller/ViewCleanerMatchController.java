//CL-10
// As a Cleaner, I want to view my confirmed match history filtered by services and date period so that I can review my completed jobs.
package wipeout.app.Controller;

import wipeout.app.Entity.BookingHistory;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

/**
 * Controller for fetching confirmed match history.
 */
public class ViewCleanerMatchController {

    /** Fetches confirmed match history for the given cleaner. */
    public List<BookingHistory> fetchMatchHistory(int cleanerId, String serviceTitle, LocalDate from, LocalDate to)
            throws SQLException {
        return BookingHistory.fetchMatchHistory(cleanerId, serviceTitle, from, to);
    }


    /** Fetches unique service titles with confirmed bookings for dropdown. */
    public List<String> fetchCompletedServiceTitles(int cleanerId) throws SQLException {
        return BookingHistory.fetchCompletedServiceTitles(cleanerId);
    }
}
