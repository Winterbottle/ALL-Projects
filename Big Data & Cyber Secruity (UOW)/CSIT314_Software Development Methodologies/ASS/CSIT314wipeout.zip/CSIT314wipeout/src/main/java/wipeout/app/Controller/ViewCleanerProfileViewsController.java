//CL-08
//As a Cleaner, I want to view how many times my profile was viewed so that I can track service visibility.
package wipeout.app.Controller;

import wipeout.app.Entity.CleaningService;

import java.util.ArrayList;
import java.util.List;

public class ViewCleanerProfileViewsController {

    /**
     * Fetches the total profile view count for the given cleaner,
     * wrapped inside a List<CleaningService> for compatibility with boundary display logic.
     */
    public List<CleaningService> fetchProfileViews(int cleanerId) throws Exception {
        int count = CleaningService.fetchTotalProfileViews(cleanerId);

        // Wrap count into a single CleaningService object
        List<CleaningService> result = new ArrayList<>();
        result.add(new CleaningService(0, "", "", null, 0.0, count)); // dummy object for viewCount only
        return result;
    }
}
