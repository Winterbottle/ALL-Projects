//CL-04
//As a Cleaner, I want to view my cleaning services so that I can monitor what I offer.
package wipeout.app.Controller;

import wipeout.app.Entity.CleaningService;

import java.sql.SQLException;
import java.util.List;

public class ViewCleanerServiceController {

    /**
     * Fetches all cleaning services created by the given cleaner.
     */
    public List<CleaningService> fetchAllServices(int cleanerId) throws SQLException {
        return CleaningService.fetchAllByCleaner(cleanerId); // ✅ match method name
    }
}
