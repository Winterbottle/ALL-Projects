//CL-09
//As a Cleaner, I want to view how many times I was shortlisted so that I can gauge my service popularity.
package wipeout.app.Controller;

import wipeout.app.Entity.Shortlist;

import java.sql.SQLException;
import java.util.List;

public class ViewCleanerShortlistController {

    /**
     * Fetches how many times the given cleaner has been shortlisted.
     */
    public List<Shortlist> fetchShortlistCount(int cleanerId) {
        try {
            return Shortlist.fetchShortlistCount(cleanerId);
        } catch (SQLException e) {
            e.printStackTrace();
            return java.util.Collections.emptyList();
        }
    }
}
