package wipeout.app.Controller;

import wipeout.app.Entity.CleaningService;
import java.util.List;

public class ViewCleaningServiceController {

    public List<CleaningService> fetchAllServices() {
        return CleaningService.fetchAll();
    }
}

