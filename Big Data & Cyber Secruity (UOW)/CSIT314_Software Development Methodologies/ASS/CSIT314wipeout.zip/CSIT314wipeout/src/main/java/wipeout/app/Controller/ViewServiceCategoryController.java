//PM-04
//As a Platform Manager, I want to view cleaning services categories so that I can monitor existing categories.
package wipeout.app.Controller;

import wipeout.app.Entity.ServiceCategory;

import java.util.List;

public class ViewServiceCategoryController {

    /**
     * Fetches all service categories, including related services and cleaner usernames.
     */
    public List<ServiceCategory> fetchAllCategories() {
        return ServiceCategory.fetchCategories();
    }
}
