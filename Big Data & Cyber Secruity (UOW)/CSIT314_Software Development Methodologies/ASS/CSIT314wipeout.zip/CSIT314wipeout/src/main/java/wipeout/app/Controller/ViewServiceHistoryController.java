package wipeout.app.Controller;

import wipeout.app.Entity.BookingHistory;
import wipeout.app.session.Session;

import java.time.LocalDate;
import java.util.List;

public class ViewServiceHistoryController {

    public List<String> getServiceTitles() {
        int homeOwnerId = Session.getUserId();
        return BookingHistory.fetchServiceTitlesForHomeOwner(homeOwnerId);
    }

    public List<BookingHistory> getFilteredHistory(String serviceTitle, LocalDate from, LocalDate to) {
        int homeOwnerId = Session.getUserId();
        return BookingHistory.fetchHistoryForHomeOwner(homeOwnerId, serviceTitle, from, to);
    }
}
