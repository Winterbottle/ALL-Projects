package wipeout.app.Controller;

import wipeout.app.Entity.CleaningService;
import wipeout.app.Entity.Shortlist;
import wipeout.app.session.Session;

import java.util.List;

public class ViewShortlistController {

    public List<CleaningService> getShortlistedServices() {
        int homeownerID = Session.getUserId();
        return Shortlist.fetchShortlistedServicesByHomeowner(homeownerID);
    }
}
