//UA-04
// As a User Administrator, I want to view all user accounts so that I can monitor the users.
package wipeout.app.Controller;

import wipeout.app.Entity.UserAccount;

import java.util.List;

public class ViewUserAccountController {
    /**
     * Fetches all user accounts in the system.
     */
    public List<UserAccount> fetchUserAccounts() {
        return UserAccount.fetchUserAccounts();
    }
}