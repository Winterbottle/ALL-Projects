//UA-09
//As a User Administrator, I want to view all user profiles so that I can understand roles and permissions.
package wipeout.app.Controller;

import wipeout.app.Entity.UserProfile;

import java.util.List;


public class ViewUserProfileController {
    /**
     * Fetches all user profiles (roles) in the system.
     */
    public List<UserProfile> fetchUserProfiles() {
        return UserProfile.fetchUserProfiles();
    }
}