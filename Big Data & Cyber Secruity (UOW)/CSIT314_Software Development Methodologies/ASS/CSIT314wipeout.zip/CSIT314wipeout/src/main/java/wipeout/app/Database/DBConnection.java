package wipeout.app.Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/wipeout?serverTimezone=UTC";
    private static final String USER = "root"; // change if different
    private static final String PASS = "Water05"; // set yours inside mysql workbench

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}

