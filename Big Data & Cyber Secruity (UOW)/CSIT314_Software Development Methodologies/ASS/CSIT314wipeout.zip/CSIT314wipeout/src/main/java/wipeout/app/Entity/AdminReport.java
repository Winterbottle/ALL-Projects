package wipeout.app.Entity;

import wipeout.app.Database.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

public class AdminReport {
    private int reportId;
    private Date reportPeriodStartDate;
    private Date reportPeriodEndDate;
    private int totalBookings;
    private float estimatedRevenue;
    private Date generatedDate;
    private int generatedBy;

    public AdminReport(int reportId, Date reportPeriodStartDate, Date reportPeriodEndDate,
                       int totalBookings, float estimatedRevenue, Date generatedDate, int generatedBy) {
        this.reportId = reportId;
        this.reportPeriodStartDate = reportPeriodStartDate;
        this.reportPeriodEndDate = reportPeriodEndDate;
        this.totalBookings = totalBookings;
        this.estimatedRevenue = estimatedRevenue;
        this.generatedDate = generatedDate;
        this.generatedBy = generatedBy;
    }

    // Getters
    public int getReportId() { return reportId; }
    public Date getReportPeriodStartDate() { return reportPeriodStartDate; }
    public Date getReportPeriodEndDate() { return reportPeriodEndDate; }
    public int getTotalBookings() { return totalBookings; }
    public float getEstimatedRevenue() { return estimatedRevenue; }
    public Date getGeneratedDate() { return generatedDate; }
    public int getGeneratedBy() { return generatedBy; }

    // PM-08 As a Platform Manager, I want to generate daily reports so that I can monitor short-term activity.
    public static List<AdminReport> generateDailyReport(Date selectedDate, int managerId) {
        List<AdminReport> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = new DBConnection().getConnection();

            // 1. Calculate values from bookinghistory
            String sql = "SELECT COUNT(*) AS totalBookings, " +
                    "SUM(price) AS estimatedRevenue " +
                    "FROM bookinghistory " +
                    "WHERE serviceDate = ? AND bookingStatus = 'Confirmed'";
            ps = conn.prepareStatement(sql);
            ps.setDate(1, selectedDate);
            rs = ps.executeQuery();

            if (rs.next()) {
                int totalBookings = rs.getInt("totalBookings");
                float estimatedRevenue = rs.getFloat("estimatedRevenue");

                // 2. Delete existing report (avoid duplicates)
                String deleteSql = "DELETE FROM adminreport WHERE generatedDate = ? AND generatedBy = ?";
                PreparedStatement deleteStmt = conn.prepareStatement(deleteSql);
                deleteStmt.setDate(1, selectedDate);
                deleteStmt.setInt(2, managerId);
                deleteStmt.executeUpdate();

                // 3. Insert new report
                String insertSql = "INSERT INTO adminreport (reportPeriodStartDate, reportPeriodEndDate, totalBookings, estimatedRevenue, generatedDate, generatedBy) " +
                        "VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement insertStmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS);
                insertStmt.setDate(1, selectedDate);
                insertStmt.setDate(2, selectedDate);
                insertStmt.setInt(3, totalBookings);
                insertStmt.setFloat(4, estimatedRevenue);
                insertStmt.setDate(5, selectedDate);
                insertStmt.setInt(6, managerId);
                insertStmt.executeUpdate();

                // 4. Get generated reportID
                ResultSet generatedKeys = insertStmt.getGeneratedKeys();
                int reportID = -1;
                if (generatedKeys.next()) {
                    reportID = generatedKeys.getInt(1);
                }

                // 5. Return result for UI display
                AdminReport report = new AdminReport(reportID, selectedDate, selectedDate, totalBookings, estimatedRevenue, selectedDate, managerId);
                list.add(report);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (ps != null) ps.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }

        return list;
    }


    // PM-09 As a Platform Manager, I want to generate weekly reports so that I can track performance over the week.
    public static List<AdminReport> generateWeeklyReport(Date startDate, Date endDate, int managerId) {
        List<AdminReport> list = new ArrayList<>();
        try (Connection conn = new DBConnection().getConnection()) {
            // 1. Compute data for range
            String sql = "SELECT COUNT(*) AS totalBookings,\n" +
                    "       SUM(price) AS estimatedRevenue\n" +
                    "FROM bookinghistory\n" +
                    "WHERE serviceDate BETWEEN ? AND ?\n" +
                    "  AND bookingStatus = 'Confirmed'";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, startDate);
            ps.setDate(2, endDate);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int totalBookings = rs.getInt("totalBookings");
                float estimatedRevenue = rs.getFloat("estimatedRevenue");

                // 2. Delete existing
                String del = "DELETE FROM adminreport WHERE reportPeriodStartDate = ? AND reportPeriodEndDate = ? AND generatedBy = ?";
                PreparedStatement delStmt = conn.prepareStatement(del);
                delStmt.setDate(1, startDate);
                delStmt.setDate(2, endDate);
                delStmt.setInt(3, managerId);
                delStmt.executeUpdate();

                // 3. Insert
                String insert = "INSERT INTO adminreport (reportPeriodStartDate, reportPeriodEndDate, totalBookings, estimatedRevenue, generatedDate, generatedBy) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement inStmt = conn.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
                Date generatedDate = new Date(System.currentTimeMillis());
                inStmt.setDate(1, startDate);
                inStmt.setDate(2, endDate);
                inStmt.setInt(3, totalBookings);
                inStmt.setFloat(4, estimatedRevenue);
                inStmt.setDate(5, generatedDate);
                inStmt.setInt(6, managerId);
                inStmt.executeUpdate();

                ResultSet keys = inStmt.getGeneratedKeys();
                int reportID = keys.next() ? keys.getInt(1) : -1;
                list.add(new AdminReport(reportID, startDate, endDate, totalBookings, estimatedRevenue, generatedDate, managerId));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // PM-10 As a Platform Manager, I want to generate monthly reports so that I can analyze long-term performance.
    public static List<AdminReport> generateMonthlyReport(Date selectedDate, int managerId) {
        List<AdminReport> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        LocalDate start = selectedDate.toLocalDate().withDayOfMonth(1);
        LocalDate end = start.plusMonths(1).minusDays(1);

        try {
            conn = new DBConnection().getConnection();

            String sql = "SELECT COUNT(*) AS totalBookings, " +
                    "SUM(price) AS estimatedRevenue " +
                    "FROM bookinghistory " +
                    "WHERE serviceDate BETWEEN ? AND ? AND bookingStatus = 'Confirmed'";
            ps = conn.prepareStatement(sql);
            ps.setDate(1, Date.valueOf(start));
            ps.setDate(2, Date.valueOf(end));
            rs = ps.executeQuery();

            if (rs.next()) {
                int totalBookings = rs.getInt("totalBookings");
                float estimatedRevenue = rs.getFloat("estimatedRevenue");

                String deleteSql = "DELETE FROM adminreport WHERE reportPeriodStartDate = ? AND reportPeriodEndDate = ? AND generatedBy = ?";
                PreparedStatement deleteStmt = conn.prepareStatement(deleteSql);
                deleteStmt.setDate(1, Date.valueOf(start));
                deleteStmt.setDate(2, Date.valueOf(end));
                deleteStmt.setInt(3, managerId);
                deleteStmt.executeUpdate();

                String insertSql = "INSERT INTO adminreport (reportPeriodStartDate, reportPeriodEndDate, totalBookings, estimatedRevenue, generatedDate, generatedBy) " +
                        "VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement insertStmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS);
                insertStmt.setDate(1, Date.valueOf(start));
                insertStmt.setDate(2, Date.valueOf(end));
                insertStmt.setInt(3, totalBookings);
                insertStmt.setFloat(4, estimatedRevenue);
                insertStmt.setDate(5, Date.valueOf(LocalDate.now()));
                insertStmt.setInt(6, managerId);
                insertStmt.executeUpdate();

                ResultSet generatedKeys = insertStmt.getGeneratedKeys();
                int reportID = -1;
                if (generatedKeys.next()) {
                    reportID = generatedKeys.getInt(1);
                }

                AdminReport report = new AdminReport(reportID, Date.valueOf(start), Date.valueOf(end),
                        totalBookings, estimatedRevenue, Date.valueOf(LocalDate.now()), managerId);
                list.add(report);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (ps != null) ps.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }

        return list;
    }



}
