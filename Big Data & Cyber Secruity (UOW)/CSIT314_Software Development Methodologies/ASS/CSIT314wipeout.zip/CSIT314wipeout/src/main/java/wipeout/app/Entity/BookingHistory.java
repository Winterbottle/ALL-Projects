package wipeout.app.Entity;

import wipeout.app.Database.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Entity for a confirmed match (completed job).
 */
public class BookingHistory {
    private int bookingId;
    private String serviceTitle;
    private String clientUsername;
    private LocalDate serviceDate;
    private double price;
    private String status;

    public BookingHistory(int bookingId,
                          String serviceTitle,
                          String clientUsername,
                          LocalDate serviceDate,
                          double price,
                          String status) {
        this.bookingId = bookingId;
        this.serviceTitle = serviceTitle;
        this.clientUsername = clientUsername;
        this.serviceDate = serviceDate;
        this.price = price;
        this.status = status;
    }

    public int getBookingId() {
        return bookingId;
    }

    public String getServiceTitle() {
        return serviceTitle;
    }

    public String getClientUsername() {
        return clientUsername;
    }

    public LocalDate getServiceDate() {
        return serviceDate;
    }

    public double getPrice() {
        return price;
    }

    public String getStatus() {
        return status;
    }

    // ----------------- EXISTING: For Cleaners -----------------

    public static List<BookingHistory> fetchMatchHistory(int cleanerId, String title, LocalDate from, LocalDate to) throws SQLException {
        StringBuilder sql = new StringBuilder("""
                SELECT bh.bookingID, cs.serviceTitle, bh.serviceDate, bh.bookingStatus,
                       ho.username AS clientUsername, cs.price
                FROM cleaningservices cs
                JOIN bookinghistory bh ON cs.serviceID = bh.serviceID
                JOIN useraccount ho ON bh.homeownerID = ho.userID
                WHERE cs.cleanerID = ?
                  AND (bh.bookingStatus = 'Confirmed')
            """);

        List<Object> params = new ArrayList<>();
        params.add(cleanerId);

        if (title != null && !"All Services".equals(title)) {
            sql.append(" AND cs.serviceTitle = ?");
            params.add(title);
        }
        if (from != null) {
            sql.append(" AND bh.serviceDate >= ?");
            params.add(Date.valueOf(from));
        }
        if (to != null) {
            sql.append(" AND bh.serviceDate <= ?");
            params.add(Date.valueOf(to));
        }

        sql.append(" ORDER BY bh.serviceDate DESC");

        List<BookingHistory> matches = new ArrayList<>();
        try (Connection conn = new DBConnection().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                matches.add(new BookingHistory(
                        rs.getInt("bookingID"),
                        rs.getString("serviceTitle"),
                        rs.getString("clientUsername"),
                        rs.getDate("serviceDate").toLocalDate(),
                        rs.getDouble("price"),
                        rs.getString("bookingStatus")
                ));
            }
        }

        return matches;
    }

    /**
     * Fetches service titles for which this cleaner has Confirmed bookings.
     */
    public static List<String> fetchCompletedServiceTitles(int cleanerId) {
        List<String> titles = new ArrayList<>();
        try {
            Connection conn = new DBConnection().getConnection();
            String sql = """
                        SELECT DISTINCT cs.serviceTitle
                        FROM cleaningservices cs
                        JOIN bookinghistory bh ON cs.serviceID = bh.serviceID
                        WHERE cs.cleanerID = ?
                          AND (bh.bookingStatus = 'Confirmed')
                    """;

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, cleanerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                titles.add(rs.getString("serviceTitle"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return titles;
    }

    // ----------------- NEW: For Home Owners -----------------

    public static List<BookingHistory> fetchHistoryForHomeOwner(int homeOwnerId, String title, LocalDate from, LocalDate to) {
        List<BookingHistory> history = new ArrayList<>();

        StringBuilder sql = new StringBuilder("""
            SELECT bh.bookingID, cs.serviceTitle, ua.username AS clientUsername,
                   bh.serviceDate, cs.price, bh.bookingStatus
            FROM cleaningservices cs
            JOIN bookinghistory bh ON cs.serviceID = bh.serviceID
            JOIN useraccount ua ON cs.cleanerID = ua.userID
            WHERE bh.homeownerID = ?
        """);

        List<Object> params = new ArrayList<>();
        params.add(homeOwnerId);

        if (title != null && !title.trim().isEmpty() && !"All Services".equals(title)) {
            sql.append(" AND LOWER(cs.serviceTitle) = ?");
            params.add(title.toLowerCase().trim());
        }

        if (from != null) {
            sql.append(" AND bh.serviceDate >= ?");
            params.add(Date.valueOf(from));
        }
        if (to != null) {
            sql.append(" AND bh.serviceDate <= ?");
            params.add(Date.valueOf(to));
        }

        sql.append(" ORDER BY bh.serviceDate DESC");

        try (Connection conn = new DBConnection().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                history.add(new BookingHistory(
                        rs.getInt("bookingID"),
                        rs.getString("serviceTitle"),
                        rs.getString("clientUsername"),
                        rs.getDate("serviceDate").toLocalDate(),
                        rs.getDouble("price"),
                        rs.getString("bookingStatus")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return history;
    }

    public static List<String> fetchServiceTitlesForHomeOwner(int homeOwnerId) {
        List<String> titles = new ArrayList<>();
        String sql = """
            SELECT DISTINCT cs.serviceTitle
            FROM cleaningservices cs
            JOIN bookinghistory bh ON cs.serviceID = bh.serviceID
            WHERE bh.homeownerID = ?
        """;

        try (Connection conn = new DBConnection().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, homeOwnerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                titles.add(rs.getString("serviceTitle"));
                System.out.println("Homeowner ID = " + homeOwnerId);
                System.out.println("Fetched title: " + rs.getString("serviceTitle"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        return titles;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private int serviceId;
    private int cleanerId;
    private int homeownerId;
    private LocalDate bookingDate;
    private String serviceTimeSlot;

    public BookingHistory() {}

    public BookingHistory(int bookingId, int serviceId, int cleanerId,
                          int homeownerId, double price,
                          LocalDate bookingDate, LocalDate serviceDate,
                          String serviceTimeSlot, String status) {
        this.bookingId = bookingId;
        this.serviceId = serviceId;
        this.cleanerId = cleanerId;
        this.homeownerId = homeownerId;
        this.price = price;
        this.bookingDate = bookingDate;
        this.serviceDate = serviceDate;
        this.serviceTimeSlot = serviceTimeSlot;
        this.status = status;
    }

}
