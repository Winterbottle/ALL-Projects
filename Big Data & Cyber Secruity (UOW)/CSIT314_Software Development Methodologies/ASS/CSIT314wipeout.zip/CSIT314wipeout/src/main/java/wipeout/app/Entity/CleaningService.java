package wipeout.app.Entity;

import wipeout.app.Database.DBConnection;

import java.sql.*;
import java.util.List;
import java.util.ArrayList;

import java.time.LocalDate;

public class CleaningService {
    private int serviceId;
    private int cleanerId;
    private String serviceTitle;
    private String serviceDescription;
    private double price;
    private int viewCount = 0;
    private int shortlistCount = 0;
    private LocalDate dateCreated;
    private List<Integer> categoryIds = new ArrayList<>();

    public void setCategoryIds(List<Integer> categoryIds) {
        this.categoryIds = categoryIds;
    }

    //Constructor for viewing shortlist (loading cleaning services)
    public CleaningService(int serviceId, int cleanerId, String serviceTitle, String serviceDescription,
                           double price, int viewCount, int shortlistCount, LocalDate dateCreated) {
        this.serviceId = serviceId;
        this.cleanerId = cleanerId;
        this.serviceTitle = serviceTitle;
        this.serviceDescription = serviceDescription;
        this.price = price;
        this.viewCount = viewCount;
        this.shortlistCount = shortlistCount;
        this.dateCreated = dateCreated; //use as-is
    }

    //Constructor for creating new cleaning services (date is autoset to localdate)
    public CleaningService(int cleanerId, String serviceTitle, String serviceDescription, double price) {
        this.cleanerId = cleanerId;
        this.serviceTitle = serviceTitle;
        this.serviceDescription = serviceDescription;
        this.price = price;
        this.viewCount = 0;
        this.shortlistCount = 0;
        this.dateCreated = LocalDate.now();
    }

    public int saveToDatabase() {
        if (serviceTitle.length() > 20) return 2;
        if (price < 0) return 3;

        String insertServiceSQL = "INSERT INTO cleaningservices (cleanerID, serviceTitle, serviceDescription, price, viewCount, shortlistCount, dateCreated) VALUES (?, ?, ?, ?, ?, ?, ?)";
        String insertCategoryMapSQL = "INSERT INTO servicecategorymap (serviceID, categoryID) VALUES (?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement serviceStmt = conn.prepareStatement(insertServiceSQL, Statement.RETURN_GENERATED_KEYS)) {

            serviceStmt.setInt(1, cleanerId);
            serviceStmt.setString(2, serviceTitle);
            serviceStmt.setString(3, serviceDescription);
            serviceStmt.setDouble(4, price);
            serviceStmt.setInt(5, viewCount);
            serviceStmt.setInt(6, shortlistCount);
            serviceStmt.setDate(7, new java.sql.Date(System.currentTimeMillis()));

            int affectedRows = serviceStmt.executeUpdate();
            if (affectedRows == 0) return 1;

            int serviceID;
            try (ResultSet generatedKeys = serviceStmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    serviceID = generatedKeys.getInt(1);
                } else {
                    return 1;
                }
            }

            try (PreparedStatement categoryStmt = conn.prepareStatement(insertCategoryMapSQL)) {
                for (Integer categoryId : categoryIds) {
                    categoryStmt.setInt(1, serviceID);
                    categoryStmt.setInt(2, categoryId);
                    categoryStmt.addBatch();
                }
                categoryStmt.executeBatch();
            }

            return 0; // success
        } catch (SQLException e) {
            e.printStackTrace();
            return 1;
        }
    }

    public static List<CleaningService> fetchAll() {
        List<CleaningService> list = new ArrayList<>();
        String sql = "SELECT * FROM cleaningservices";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                CleaningService cs = new CleaningService(
                        rs.getInt("cleanerID"),
                        rs.getString("serviceTitle"),
                        rs.getString("serviceDescription"),
                        rs.getFloat("price")
                );

                cs.serviceId = rs.getInt("serviceID");
                list.add(cs);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////
    public CleaningService(int serviceId, String serviceTitle, String serviceDescription,
                           LocalDate dateCreated, double price) {
        this(serviceId, serviceTitle, serviceDescription, dateCreated, price, 0);
    }

    public CleaningService(int serviceId, String serviceTitle, String serviceDescription,
                           LocalDate dateCreated, double price, int viewCount) {
        this.serviceId = serviceId;
        this.serviceTitle = serviceTitle;
        this.serviceDescription = serviceDescription;
        this.dateCreated = dateCreated;
        this.price = price;
        this.viewCount = viewCount;
    }

    //CL-04
    //As a Cleaner, I want to view my cleaning services so that I can monitor what I offer.
    /**
     * Fetches all services created by a given cleaner.
     */
    public static List<CleaningService> fetchAllByCleaner(int cleanerId) throws SQLException {
        String sql = """
            SELECT serviceID, serviceTitle, serviceDescription, dateCreated, price
            FROM cleaningservices
            WHERE cleanerID = ?
            ORDER BY serviceID
        """;

        try (Connection conn = new DBConnection().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, cleanerId);
            ResultSet rs = ps.executeQuery();

            List<CleaningService> list = new ArrayList<>();
            while (rs.next()) {
                list.add(new CleaningService(
                        rs.getInt("serviceID"),
                        rs.getString("serviceTitle"),
                        rs.getString("serviceDescription"),
                        rs.getDate("dateCreated").toLocalDate(),
                        rs.getDouble("price")
                ));
            }
            return list;
        }
    }


    //----------------------------------------------------------------
    //CL-08
    //As a Cleaner, I want to view how many times my profile was viewed so that I can track service visibility.
    /**
     * Fetches total profile view count for all services created by a cleaner.
     */
    public static int fetchTotalProfileViews(int cleanerId) throws SQLException {
        String sql = """
            SELECT SUM(viewCount) AS totalViews
            FROM cleaningservices
            WHERE cleanerID = ?
        """;

        try (Connection conn = new DBConnection().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, cleanerId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("totalViews");
            }
        }
        return 0;
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public static List<String[]> findByCleanerAsArray(int cleanerId) {
    List<String[]> result = new ArrayList<>();
    String sql = "SELECT serviceID, serviceTitle, serviceDescription, price FROM cleaningservices WHERE cleanerID = ?";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, cleanerId);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            result.add(new String[]{
                    String.valueOf(rs.getInt("serviceID")),
                    rs.getString("serviceTitle"),
                    rs.getString("serviceDescription"),
                    String.valueOf(rs.getDouble("price"))
            });
        }
    } catch (Exception ignored) {}
    return result;
}

    public static boolean updateService(int serviceId, String title, String desc, double price) {
        String sql = "UPDATE cleaningservices SET serviceTitle = ?, serviceDescription = ?, price = ? WHERE serviceID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, title);
            stmt.setString(2, desc);
            stmt.setDouble(3, price);
            stmt.setInt(4, serviceId);
            return stmt.executeUpdate() > 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static List<String[]> getServicesByCleanerAsArray(int cleanerId) {
        List<String[]> result = new ArrayList<>();
        String sql = "SELECT serviceID, serviceTitle, price FROM cleaningservices WHERE cleanerID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, cleanerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                result.add(new String[]{
                        String.valueOf(rs.getInt("serviceID")),
                        rs.getString("serviceTitle"),
                        String.valueOf(rs.getDouble("price"))
                });
            }
        } catch (Exception ignored) {}
        return result;
    }

    public static boolean deleteService(Connection conn, int serviceId) {
        String sql = "DELETE FROM cleaningservices WHERE serviceID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, serviceId);
            return stmt.executeUpdate() > 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // HO-04 As a Home Owner, I want to search for cleaning services so that I can find services that meet my needs.
    public static List<CleaningService> search(String keyword) {
        List<CleaningService> list = new ArrayList<>();
        String sql = "SELECT serviceID, cleanerID, serviceTitle, serviceDescription, price"
                + " FROM cleaningservices"
                + " WHERE serviceTitle = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, keyword);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    CleaningService cs = new CleaningService(
                            rs.getInt("cleanerID"),
                            rs.getString("serviceTitle"),
                            rs.getString("serviceDescription"),
                            rs.getDouble("price")
                    );
                    cs.serviceId = rs.getInt("serviceID");
                    list.add(cs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //CL-07
    public static List<CleaningService> searchCleanerServiceByOwner(int cleanerId, String keyword) {
        List<CleaningService> list = new ArrayList<>();
        String sql = """
        SELECT serviceID, serviceTitle, serviceDescription, dateCreated, price
        FROM cleaningservices
        WHERE cleanerID = ? AND serviceTitle LIKE ?
    """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, cleanerId);
            stmt.setString(2, "%" + keyword + "%");

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(new CleaningService(
                        rs.getInt("serviceID"),
                        rs.getString("serviceTitle"),
                        rs.getString("serviceDescription"),
                        rs.getDate("dateCreated").toLocalDate(),
                        rs.getDouble("price")
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }

    // Getters
    public int getServiceId() { return serviceId; }
    public int getCleanerId() { return cleanerId; }
    public String getServiceTitle() { return serviceTitle; }
    public String getServiceDescription() { return serviceDescription; }
    public double getPrice() { return price; }
    public int getViewCount() { return viewCount; }
    public int getShortlistCount() { return shortlistCount; }
    public LocalDate getDateCreated() { return dateCreated; }
}


