package wipeout.app.Entity;

import wipeout.app.Database.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServiceCategory {
    private int categoryId;
    private String categoryName;
    private String categoryDescription;

    public ServiceCategory(int categoryId, String categoryName, String categoryDescription) {
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.categoryDescription = categoryDescription;
    }
    public ServiceCategory(String categoryName, String categoryDescription) {
        this.categoryName = categoryName;
        this.categoryDescription = categoryDescription;
    }

    public int saveToDatabase() {
        if (categoryName.length() > 50) {
            return 2; // Category name too long
        }

        try (Connection conn = DBConnection.getConnection()) {
            // Check for duplicate category name
            String checkSql = "SELECT COUNT(*) FROM servicecategory WHERE categoryName = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, categoryName);
                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        return 1; // Duplicate category
                    }
                }
            }

            String sql = "INSERT INTO servicecategory (categoryName, categoryDescription) VALUES (?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, categoryName);
                stmt.setString(2, categoryDescription);
                stmt.executeUpdate();
                return 0; // Success
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 3; // DB error
        }
    }

    public static List<ServiceCategory> getAllCategories() {
        List<ServiceCategory> list = new ArrayList<>();
        String sql = "SELECT * FROM servicecategory";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("categoryID");
                String name = rs.getString("categoryName");
                String desc = rs.getString("categoryDescription");
                list.add(new ServiceCategory(id, name, desc));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    private String serviceTitle;
    private String cleanerUsername;

    public ServiceCategory(int id, String name, String description, String serviceTitle, String cleanerUsername) {
        this.categoryId = id;
        this.categoryName = name;
        this.categoryDescription = description;
        this.serviceTitle = serviceTitle;
        this.cleanerUsername = cleanerUsername;
    }

    //PM-04
    //As a Platform Manager, I want to view cleaning services categories so that I can monitor existing categories.
    /**
     * Fetches all categories along with their linked services and cleaner usernames.
     */
    public static List<ServiceCategory> fetchCategories() {
        List<ServiceCategory> list = new ArrayList<>();

        String sql = """
        SELECT sc.categoryID,
               sc.categoryName,
               sc.categoryDescription,
               cs.serviceTitle,
               ua.username AS cleanerUsername
        FROM servicecategory sc
        LEFT JOIN servicecategorymap scm ON sc.categoryID = scm.categoryID
        LEFT JOIN cleaningservices cs ON scm.serviceID = cs.serviceID
        LEFT JOIN useraccount ua ON cs.cleanerID = ua.userID
        ORDER BY sc.categoryID ASC
        """;

        try (Connection conn = new DBConnection().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(new ServiceCategory(
                        rs.getInt("categoryID"),
                        rs.getString("categoryName"),
                        rs.getString("categoryDescription"),
                        rs.getString("serviceTitle"),
                        rs.getString("cleanerUsername")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }


    public static List<ServiceCategory> searchCategories(String keyword) {
        List<ServiceCategory> list = new ArrayList<>();
        String sql =
                "SELECT "
                        + "  sc.categoryID, "
                        + "  sc.categoryName, "
                        + "  sc.categoryDescription, "
                        + "  ( "
                        + "    SELECT cs.serviceTitle "
                        + "    FROM servicecategorymap scm2 "
                        + "      JOIN cleaningservices cs ON cs.serviceID = scm2.serviceID "
                        + "    WHERE scm2.categoryID = sc.categoryID "
                        + "    LIMIT 1 "
                        + "  ) AS serviceTitle, "
                        + "  ( "
                        + "    SELECT ua.username "
                        + "    FROM servicecategorymap scm3 "
                        + "      JOIN cleaningservices cs2 ON cs2.serviceID = scm3.serviceID "
                        + "      JOIN useraccount ua      ON ua.userID    = cs2.cleanerID "
                        + "    WHERE scm3.categoryID = sc.categoryID "
                        + "    LIMIT 1 "
                        + "  ) AS cleanerUsername "
                        + "FROM servicecategory sc "
                        + "WHERE LOWER(sc.categoryName) = ?";

        try (Connection conn = new DBConnection().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, keyword == null ? "" : keyword.trim().toLowerCase());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new ServiceCategory(
                            rs.getInt("categoryID"),
                            rs.getString("categoryName"),
                            rs.getString("categoryDescription"),
                            rs.getString("serviceTitle"),
                            rs.getString("cleanerUsername")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Load all categories as entity objects
    public static List<ServiceCategory> findAll() {
        List<ServiceCategory> list = new ArrayList<>();
        String sql = "SELECT * FROM servicecategory";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(new ServiceCategory(
                        rs.getInt("categoryID"),
                        rs.getString("categoryName"),
                        rs.getString("categoryDescription")
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }

    // Load all categories as String[]
    public static List<String[]> getAllAsArray() {
        List<String[]> result = new ArrayList<>();
        for (ServiceCategory c : findAll()) {
            result.add(new String[]{
                    String.valueOf(c.getCategoryId()),
                    c.getCategoryName(),
                    c.getCategoryDescription()
            });
        }
        return result;
    }

    // Find one by ID as entity
    public static ServiceCategory findById(int id) {
        String sql = "SELECT * FROM servicecategory WHERE categoryID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new ServiceCategory(
                        rs.getInt("categoryID"),
                        rs.getString("categoryName"),
                        rs.getString("categoryDescription")
                );
            }
        } catch (Exception ignored) {}
        return null;
    }

    // Find one by ID as String[]
    public static String[] getByIdAsArray(int id) {
        ServiceCategory cat = findById(id);
        if (cat != null) {
            return new String[]{
                    String.valueOf(cat.getCategoryId()),
                    cat.getCategoryName(),
                    cat.getCategoryDescription()
            };
        }
        return null;
    }

    // Update category
    public static boolean updateCategory(int categoryID, String name, String description) {
        String sql = "UPDATE servicecategory SET categoryName = ?, categoryDescription = ? WHERE categoryID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.setInt(3, categoryID);
            return stmt.executeUpdate() > 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    // Delete category
    public static boolean deleteCategory(int categoryID) {
        String sql = "DELETE FROM servicecategory WHERE categoryID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, categoryID);
            return stmt.executeUpdate() > 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    public int getCategoryId() { return categoryId; }
    public String getCategoryName() { return categoryName; }
    public String getCategoryDescription() { return categoryDescription; }
    public String getServiceTitle() { return serviceTitle; }
    public String getCleanerUsername() { return cleanerUsername; }
}


