package wipeout.app.Entity;

import wipeout.app.Database.DBConnection;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Shortlist {
    private int homeOwnerID;
    private int serviceID;
    private int shortlistCount;

    public Shortlist(int homeOwnerID, int serviceID) {
        this.homeOwnerID = homeOwnerID;
        this.serviceID = serviceID;
    }

    public int getHomeOwnerID() {
        return homeOwnerID;
    }
    public int getServiceID() {
        return serviceID;
    }

    public static boolean saveToDatabase(int homeOwnerID, int serviceID) {
        String sql = "INSERT INTO shortlist (homeOwnerID, serviceID) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, homeOwnerID);
            stmt.setInt(2, serviceID);

            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean isServiceAlreadyShortlisted(int homeOwnerID, int serviceID) {
        String sql = "SELECT * FROM shortlist WHERE homeOwnerID = ? AND serviceID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, homeOwnerID);
            stmt.setInt(2, serviceID);
            ResultSet rs = stmt.executeQuery();

            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<CleaningService> fetchShortlistedServicesByHomeowner(int homeownerID) {
        List<CleaningService> services = new ArrayList<>();

        String query = "SELECT cs.* FROM cleaningservices cs " +
                "JOIN shortlist s ON cs.serviceID = s.serviceID " +
                "WHERE s.homeownerID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, homeownerID);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                CleaningService service = new CleaningService(
                        rs.getInt("serviceID"),
                        rs.getInt("cleanerID"),
                        rs.getString("serviceTitle"),
                        rs.getString("serviceDescription"),
                        rs.getFloat("price"),
                        rs.getInt("viewCount"),
                        rs.getInt("shortlistCount"),
                        rs.getDate("dateCreated").toLocalDate()
                );
                services.add(service);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return services;
    }
    /////////////////////////////////////////////////////////////////////////////////////////


    public Shortlist(int shortlistCount) {
        this.shortlistCount = shortlistCount;
    }
    public int getShortlistCount() { return shortlistCount; }


    //----------------------------------
    //CL-09
    //As a Cleaner, I want to view how many times I was shortlisted so that I can gauge my service popularity.
    /**
     * Fetches the total shortlist count for services posted by the specified cleaner.
     */
    public static List<Shortlist> fetchShortlistCount(int cleanerId) throws SQLException {
        String sql = """
            SELECT cleanerID,
                   SUM(shortlistCount) AS totalShortlisted
              FROM cleaningservices
             WHERE cleanerID = ?
             GROUP BY cleanerID
        """;
        try ( var conn = new DBConnection().getConnection();
              var ps   = conn.prepareStatement(sql) ) {
            ps.setInt(1, cleanerId);
            try ( var rs = ps.executeQuery() ) {
                if (rs.next()) {
                    return List.of(new Shortlist(
                            rs.getInt("totalShortlisted")
                    ));
                }
            }
        }
        return java.util.Collections.emptyList();
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private SimpleStringProperty serviceTitle;
    private SimpleStringProperty cleanerUsername;
    public SimpleStringProperty serviceTitleProperty() {
        return serviceTitle;
    }

    public SimpleStringProperty cleanerUsernameProperty() {
        return cleanerUsername;
    }
    // Constructor for HO-07 shortlist search result
    public Shortlist(String serviceTitle, String cleanerUsername) {
        this.serviceTitle = new SimpleStringProperty(serviceTitle);
        this.cleanerUsername = new SimpleStringProperty(cleanerUsername);
    }
    //----------------------------------
    //HO-07
    //As a Home Owner, I want to search my favourite list so that I can find the shortlisted cleaners easily.
    public static List<Shortlist> searchShortlist(String keyword, int homeownerId) {
        List<Shortlist> list = new ArrayList<>();

        String sql = """
        SELECT cs.serviceTitle, ua.username
        FROM shortlist sl
        JOIN cleaningservices cs ON sl.serviceID = cs.serviceID
        JOIN useraccount ua ON cs.cleanerID = ua.userID
        WHERE sl.homeownerID = ?
          AND LOWER(cs.serviceTitle) = ?
    """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String filter = keyword == null ? "" : keyword.trim().toLowerCase();

            ps.setInt(1, homeownerId);
            ps.setString(2, filter);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Shortlist(
                        rs.getString("serviceTitle"),
                        rs.getString("username")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

}
