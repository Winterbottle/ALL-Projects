package wipeout.app.Entity;

import wipeout.app.Database.DBConnection;

import java.sql.*;
import java.util.List;
import java.util.ArrayList;

public class UserAccount {
    private int userId;
    private int profileId;
    private String username;
    private String password;
    private String fullname;
    private String accountStatus;

    public UserAccount() {}
    public UserAccount(int profileId, String username, String password, String fullname, String accountStatus) {
        this.profileId = profileId;
        this.username = username;
        this.password = password;
        this.fullname = fullname;
        this.accountStatus = accountStatus;
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public int verifyLogin(String username, String password, String profileName) {
        int resultCode = 0; // Will store the result of the login attempt

        // === SQL to check if the username, password, and profile match ===
        String sql = "SELECT ua.userID, ua.accountStatus AS accountStatus, up.profileStatus AS profileStatus " +
                "FROM useraccount ua " +
                "JOIN userprofile up ON ua.profileID = up.profileID " +
                "WHERE ua.username = ? AND ua.password = ? AND up.profileName = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            // Set query parameters to prevent SQL injection
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, profileName);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // Retrieve account and profile status
                String accountStatus = rs.getString("accountStatus");
                String profileStatus = rs.getString("profileStatus");

                // Check if both account and profile are active
                if (accountStatus.equalsIgnoreCase("Active") && profileStatus.equalsIgnoreCase("Active")) {
                    resultCode = rs.getInt("userID"); // Successful login, return user ID
                }

                // If account/profile is suspended, return -1
                else if (accountStatus.equalsIgnoreCase("Suspended") || profileStatus.equalsIgnoreCase("Suspended")) {
                    resultCode = -1;
                }
            } else {
                // No matching user found: invalid credentials
                resultCode = -2;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return resultCode; // Return the login result code
    }

    public String getFullname(int userID) {
        String name = ""; // Default to empty string if not found

        // === SQL to fetch the user's full name based on userID ===
        String sql = "SELECT fullname FROM useraccount WHERE userID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userID); // Set the userID parameter
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                name = rs.getString("fullname"); // Retrieve the fullname if found
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return name; // Return the user's full name
    }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public int saveToDatabase() {
        if (username.length() > 20) {
            return 2; // Username too long
        }

        try (Connection conn = DBConnection.getConnection()) {
            // Check for duplicate username
            String checkSql = "SELECT COUNT(*) FROM useraccount WHERE username = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, username);
                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        return 1; // Duplicate username
                    }
                }
            }

            // Insert new account
            String sql = "INSERT INTO useraccount (profileID, username, password, fullName, accountStatus) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, profileId);
                stmt.setString(2, username);
                stmt.setString(3, password);
                stmt.setString(4, fullname);
                stmt.setString(5, accountStatus);
                stmt.executeUpdate();
                return 0; // Success
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 4; // DB error
        }
    }

    public UserAccount getUserAccountById(int userId) {
        UserAccount user = null;

        String sql = "SELECT ua.userID, ua.username, up.profileName FROM useraccount ua " +
                "JOIN userprofile up ON ua.profileID = up.profileID " +
                "WHERE ua.userID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                user = new UserAccount();
                user.setUserId(rs.getInt("userID"));
                user.setUsername(rs.getString("username"));
                user.setProfileName(rs.getString("profileName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public UserAccount(int userId, String username, String password, String fullname, String accountStatus, int profileId) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.fullname = fullname;
        this.accountStatus = accountStatus;
        this.profileId = profileId;
    }

    public static List<UserAccount> findAll() {
        List<UserAccount> list = new ArrayList<>();
        String sql = "SELECT * FROM useraccount";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(new UserAccount(
                        rs.getInt("userID"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("fullname"),
                        rs.getString("accountStatus"),
                        rs.getInt("profileID")
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }

    public static List<UserAccount> findByProfileId(int profileId) {
        List<UserAccount> list = new ArrayList<>();
        String sql = "SELECT * FROM useraccount WHERE profileID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, profileId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(new UserAccount(
                        rs.getInt("userID"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("fullname"),
                        rs.getString("accountStatus"),
                        rs.getInt("profileID")
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }

    public static List<String[]> getAllAsArray() {
        List<String[]> rows = new ArrayList<>();
        for (UserAccount u : findAll()) {
            rows.add(new String[]{
                    String.valueOf(u.getUserId()),
                    String.valueOf(u.getProfileId()),
                    u.getUsername(),
                    u.getFullname(),
                    u.getPassword(),
                    u.getAccountStatus()
            });
        }
        return rows;
    }

    public static List<String[]> getByProfileAsArray(int profileId) {
        List<String[]> rows = new ArrayList<>();
        for (UserAccount u : findByProfileId(profileId)) {
            rows.add(new String[]{
                    String.valueOf(u.getUserId()),
                    String.valueOf(u.getProfileId()),
                    u.getUsername(),
                    u.getFullname(),
                    u.getPassword(),
                    u.getAccountStatus()
            });
        }
        return rows;
    }

    public static boolean updateUser(int userId, String password, String fullname) {
        String sql = "UPDATE useraccount SET password = ?, fullname = ? WHERE userID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, password);
            stmt.setString(2, fullname);
            stmt.setInt(3, userId);
            return stmt.executeUpdate() > 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean suspendUser(int userId, String status) {
        String sql = "UPDATE useraccount SET accountStatus = ? WHERE userID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, status);
            stmt.setInt(2, userId);
            return stmt.executeUpdate() > 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static UserAccount findByCredentials(String username, String password) {
        String sql = "SELECT * FROM useraccount WHERE username = ? AND password = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new UserAccount(
                        rs.getInt("userID"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("fullname"),
                        rs.getString("accountStatus"),
                        rs.getInt("profileID")
                );
            }
        } catch (Exception ignored) {}
        return null;
    }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private String profileName;
    private static int loggedInUserId = -1;
    private static String loggedInRole = "";

    public String getProfileName() { return profileName; }
    public void setProfileName(String r) { this.profileName = r; }
    /**
     * Fetch all user accounts from the database.
     */
    public static List<UserAccount> fetchUserAccounts() {
        List<UserAccount> list = new ArrayList<>();
        try (Connection conn = new DBConnection().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT ua.userID, ua.username, up.profileName, ua.fullname, ua.accountStatus\n" + "FROM useraccount ua\n" + "JOIN userprofile up ON ua.profileID = up.profileID")) {

            while (rs.next()) {
                UserAccount ua = new UserAccount();
                ua.setUserId(rs.getInt("userID"));
                ua.setUsername(rs.getString("username"));
                ua.setProfileName(rs.getString("profileName"));
                ua.setFullname(rs.getString("fullName"));
                ua.setAccountStatus(rs.getString("accountStatus"));

                list.add(ua);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }


    //UA-04
    // As a User Administrator, I want to view all user accounts so that I can monitor the users.
    /**
     * Verifies user credentials based on user ID instead of username.
     * Also ensures the account and profile are active.
     */

    public static boolean verifyInfoById(int userId, String password, String profileName) {
        String sql = """
        SELECT *
        FROM useraccount ua
        JOIN userprofile up ON ua.profileID = up.profileID
        WHERE ua.userID = ? AND ua.password = ? AND up.profileName = ?
          AND ua.accountStatus = 'Active' AND up.profileStatus = 'Active'
    """;

        try (Connection conn = new DBConnection().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setString(2, password);
            stmt.setString(3, profileName);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /** UA-07 As a User Administrator, I want to search for user accounts so that I can quickly find specific users.
     * Search for user accounts by username or full name.
     * @param keyword the search keyword
     * @return list of matching user accounts
     */
    public static List<UserAccount> search(String keyword) {
        List<UserAccount> list = new ArrayList<>();
        // only return rows whose username or fullname exactly equals the keyword
        String sql = """
        SELECT userID, username, password, fullname, accountStatus, profileID
          FROM useraccount
         WHERE LOWER(username) = ? OR LOWER(fullname) = ?
        """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String cleanedKeyword = keyword.trim().toLowerCase();

            stmt.setString(1, cleanedKeyword);
            stmt.setString(2, cleanedKeyword);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new UserAccount(
                            rs.getInt("userID"),
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("fullname"),
                            rs.getString("accountStatus"),
                            rs.getInt("profileID")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public int getUserId() { return userId; }
    public int getProfileId() { return profileId; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getFullname() { return fullname; }
    public String getAccountStatus() { return accountStatus; }

    public void setUserId(int userId) { this.userId = userId; }
    public void setProfileId(int profileId) { this.profileId = profileId; }
    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }
    public void setFullname(String fullname) { this.fullname = fullname; }
    public void setAccountStatus(String accountStatus) { this.accountStatus = accountStatus; }
}
