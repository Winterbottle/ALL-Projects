package wipeout.app.Entity;

import wipeout.app.Database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserProfile {
    private int profileId;
    private String profileName;
    private String profileDescription;
    private String profileStatus;
    public UserProfile(int profileId, String profileName, String profileDescription, String profileStatus) {
        this.profileId = profileId;
        this.profileName = profileName;
        this.profileDescription = profileDescription;
        this.profileStatus = profileStatus;
    }
    public UserProfile(String profileName, String profileDescription, String profileStatus) {
        this.profileName = profileName;
        this.profileDescription = profileDescription;
        this.profileStatus = profileStatus;
    }

    public int saveToDatabase() {
        try (Connection conn = DBConnection.getConnection()) {
            // Check for duplicate profile name
            String checkSql = "SELECT COUNT(*) FROM userprofile WHERE profileName = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, profileName);
                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        return 1; // Duplicate profile name
                    }
                }
            }
            // Proceed with insert
            String sql = "INSERT INTO userprofile (profileName, profileDescription, profileStatus) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, profileName);
                stmt.setString(2, profileDescription);
                stmt.setString(3, profileStatus);
                stmt.executeUpdate();
                return 0; // Success
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 4; // DB error
        }
    }

    public static List<UserProfile> findAllProfiles() {
        List<UserProfile> list = new ArrayList<>();
        String sql = "SELECT * FROM userprofile";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(new UserProfile(
                        rs.getInt("profileID"),
                        rs.getString("profileName"),
                        rs.getString("profileDescription"),
                        rs.getString("profileStatus")
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }

    public static UserProfile findByProfileId(int profileId) {
        String sql = "SELECT * FROM userprofile WHERE profileID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, profileId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new UserProfile(
                        rs.getInt("profileID"),
                        rs.getString("profileName"),
                        rs.getString("profileDescription"),
                        rs.getString("profileStatus")
                );
            }
        } catch (Exception ignored) {}
        return null;
    }

    public static List<String[]> getAllAsArray() {
        List<String[]> result = new ArrayList<>();
        for (UserProfile p : findAllProfiles()) {
            result.add(new String[]{
                    String.valueOf(p.getProfileId()),
                    p.getProfileName(),
                    p.getProfileDescription(),
                    p.getProfileStatus()
            });
        }
        return result;
    }

    public static String[] getByIdAsArray(int profileId) {
        UserProfile p = findByProfileId(profileId);
        if (p != null) {
            return new String[]{
                    String.valueOf(p.getProfileId()),
                    p.getProfileName(),
                    p.getProfileDescription(),
                    p.getProfileStatus()
            };
        }
        return null;
    }

    public static java.util.Map<Integer, String> getRoleIdToName() {
        java.util.Map<Integer, String> map = new java.util.HashMap<>();
        String sql = "SELECT profileID, profileName FROM userprofile WHERE profileStatus = 'Active'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                map.put(rs.getInt("profileID"), rs.getString("profileName"));
            }
        } catch (Exception ignored) {}
        return map;
    }

    public static boolean updateProfile(int id, String name, String desc, String status) {
        String sql = "UPDATE userprofile SET profileName = ?, profileDescription = ?, profileStatus = ? WHERE profileID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, desc);
            stmt.setString(3, status);
            stmt.setInt(4, id);
            return stmt.executeUpdate() > 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean suspendProfile(int id, String status) {
        String sql = "UPDATE userprofile SET profileStatus = ? WHERE profileID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, id);
            return stmt.executeUpdate() > 0;
        } catch (Exception ignored) {
            return false;
        }
    }
    ////////////////////////////////////////////////////////////////////////////////
    //UA-09
    //As a User Administrator, I want to view all user profiles so that I can understand roles and permissions.
    /**
     * Fetches all user profiles from the database.
     * Each profile represents a role (Cleaner, Admin, etc.) and includes status.
     */
    public static List<UserProfile> fetchUserProfiles() {
        List<UserProfile> list = new ArrayList<>();
        String sql = "SELECT profileID, profileName, profileDescription, profileStatus FROM userprofile";

        try (Connection conn = new wipeout.app.Database.DBConnection().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                UserProfile profile = new UserProfile(
                        rs.getInt("profileID"),
                        rs.getString("profileName"),
                        rs.getString("profileDescription"),
                        rs.getString("profileStatus")
                );
                list.add(profile);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //UA-12 As a User Administrator, I want to search for user profiles so that I can manage users easily.
    public static List<UserProfile> search(String keyword) {
        List<UserProfile> list = new ArrayList<>();
        String sql = "SELECT profileID, profileName, profileDescription, profileStatus"
                + " FROM userprofile"
                + " WHERE profileName LIKE ? OR profileDescription LIKE ? OR profileStatus LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String kw = "%" + keyword + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ps.setString(3, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new UserProfile(
                            rs.getInt("profileID"),
                            rs.getString("profileName"),
                            rs.getString("profileDescription"),
                            rs.getString("profileStatus")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    public int getProfileId() { return profileId; }
    public String getProfileName() { return profileName; }
    public String getProfileDescription() { return profileDescription; }
    public String getProfileStatus() { return profileStatus; }
}
