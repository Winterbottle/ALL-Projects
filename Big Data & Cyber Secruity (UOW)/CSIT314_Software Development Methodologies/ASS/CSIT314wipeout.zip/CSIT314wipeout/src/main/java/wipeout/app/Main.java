package wipeout.app;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import wipeout.app.Boundary.LoginPage;

public class Main extends Application {

//    @Override
//    public void start(Stage primaryStage) {
//        try {
//             Choose one of the following lines to load either feature:
//             Load CreateUserAccountPage
//            Parent root = FXMLLoader.load(getClass().getResource("/fxml/CreateUserAccountPage.fxml"));
//             Load CreateCleaningServicePage
//            Parent root = FXMLLoader.load(getClass().getResource("/fxml/CreateCleaningServicePage.fxml"));
//             Load CreateServiceCategoryPage
//            Parent root = FXMLLoader.load(getClass().getResource("/fxml/CreateServiceCategoryPage.fxml"));
//             Load CreateUserProfilePage
//            Parent root = FXMLLoader.load(getClass().getResource("/fxml/CreateUserProfilePage.fxml"));
//             Load ViewCleaningServicePage
//            Parent root = FXMLLoader.load(getClass().getResource("/fxml/ViewCleaningServicePage.fxml"));
//             View shortlist page
//            Parent root = FXMLLoader.load(getClass().getResource("/fxml/ViewShortlistPage.fxml"));
//             View servicehistory page (as home owner)
//            Parent root = FXMLLoader.load(getClass().getResource("/fxml/ViewServiceHistoryPage.fxml"));
//
//            primaryStage.setTitle("Test UI");
//            primaryStage.setScene(new Scene(root));
//            primaryStage.show();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    @Override
    public void start(Stage primaryStage) {
        // Create and show your LoginPage directly
        LoginPage loginPage = new LoginPage();
        loginPage.start(primaryStage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
