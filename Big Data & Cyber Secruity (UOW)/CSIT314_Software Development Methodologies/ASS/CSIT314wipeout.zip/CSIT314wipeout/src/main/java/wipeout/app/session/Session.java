//package wipeout.app.session;
//
//public class Session {
//    private static int userId = 46; // I set dummy value = 7 for now. Dont need to set to 7 after login ok alr.
//
//    public static void setUserId(int id) {
//        userId = id;
//    }
//
//    public static int getUserId() {
//        return userId;
//    }
//}

package wipeout.app.session;

public class Session {
    private static int userId;
    private static String username;
    private static String profileName;

    /**
     * Call this ONCE after successful login to store user session info.
     */
    public static void start(int id, String uname, String role) {
        userId = id;
        username = uname;
        profileName = role;
    }

    public static int getUserId() {
        return userId;
    }

    public static String getUsername() {
        return username;
    }

    public static String getProfileName() {
        return profileName;
    }

    /**
     * Optional: Call this on logout to clear session.
     */
    public static void clear() {
        userId = 0;
        username = null;
        profileName = null;
    }
}
