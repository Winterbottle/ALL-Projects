CREATE DATABASE  IF NOT EXISTS `wipeout` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `wipeout`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: wipeout
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adminreport`
--

DROP TABLE IF EXISTS `adminreport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adminreport` (
  `reportID` int NOT NULL AUTO_INCREMENT,
  `reportPeriodStartDate` date NOT NULL,
  `reportPeriodEndDate` date NOT NULL,
  `totalBookings` int NOT NULL,
  `estimatedRevenue` float NOT NULL,
  `generatedDate` date NOT NULL,
  `generatedBy` int NOT NULL,
  PRIMARY KEY (`reportID`),
  KEY `fk_adminreport_generatedBy_idx` (`generatedBy`),
  CONSTRAINT `fk_adminreport_generatedBy` FOREIGN KEY (`generatedBy`) REFERENCES `useraccount` (`userID`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminreport`
--

LOCK TABLES `adminreport` WRITE;
/*!40000 ALTER TABLE `adminreport` DISABLE KEYS */;
INSERT INTO `adminreport` VALUES (1,'2025-01-16','2025-01-16',0,0,'2025-01-19',3),(2,'2025-03-15','2025-04-13',5,486,'2025-04-14',4),(3,'2025-03-19','2025-03-19',0,0,'2025-03-22',4),(4,'2024-03-22','2024-03-28',6,515,'2024-03-31',3),(5,'2025-09-05','2025-10-04',0,0,'2025-10-07',5),(6,'2024-11-06','2024-11-06',0,0,'2024-11-09',4),(7,'2024-03-16','2024-04-14',6,515,'2024-04-16',3),(8,'2026-05-22','2026-06-20',0,0,'2026-06-21',5),(9,'2026-08-24','2026-08-24',0,0,'2026-08-27',4),(10,'2025-08-10','2025-08-16',0,0,'2025-08-17',4),(11,'2024-08-24','2024-08-24',0,0,'2024-08-26',5),(12,'2024-03-25','2024-04-23',6,515,'2024-04-26',3),(13,'2026-02-24','2026-03-02',5,337,'2026-03-05',4),(14,'2024-04-16','2024-05-15',3,220,'2024-05-16',4),(15,'2025-10-01','2025-10-07',0,0,'2025-10-08',4),(16,'2026-05-20','2026-05-20',0,0,'2026-05-23',3),(17,'2026-01-21','2026-01-27',7,529,'2026-01-29',6),(18,'2024-12-29','2025-01-27',5,359,'2025-01-29',6),(19,'2024-10-13','2024-10-19',0,0,'2024-10-20',3),(20,'2026-01-31','2026-02-06',0,0,'2026-02-07',3),(21,'2025-01-03','2025-01-09',0,0,'2025-01-12',5),(22,'2024-12-14','2025-01-12',0,0,'2025-01-13',4),(23,'2024-07-15','2024-07-15',0,0,'2024-07-17',5),(24,'2024-06-04','2024-06-04',0,0,'2024-06-07',5),(25,'2024-09-04','2024-10-03',0,0,'2024-10-06',5),(26,'2024-04-12','2024-05-11',3,220,'2024-05-12',3),(27,'2024-07-02','2024-07-31',0,0,'2024-08-01',6),(28,'2024-10-22','2024-10-22',0,0,'2024-10-25',4),(29,'2024-04-21','2024-05-20',3,220,'2024-05-23',5),(30,'2026-05-30','2026-05-30',0,0,'2026-06-02',6),(31,'2026-09-25','2026-09-25',0,0,'2026-09-26',6),(32,'2024-05-16','2024-05-16',0,0,'2024-05-19',6),(33,'2026-10-20','2026-10-26',0,0,'2026-10-28',4),(34,'2026-03-31','2026-04-06',0,0,'2026-04-09',4),(35,'2025-03-26','2025-04-24',0,0,'2025-04-25',4),(36,'2024-11-11','2024-11-11',0,0,'2024-11-13',5),(37,'2024-02-29','2024-03-29',6,515,'2024-04-01',5),(38,'2026-08-23','2026-09-21',0,0,'2026-09-23',4),(39,'2025-10-05','2025-10-05',0,0,'2025-10-06',6),(40,'2024-08-06','2024-09-04',0,0,'2024-09-07',4),(41,'2026-08-11','2026-08-17',0,0,'2026-08-20',5),(42,'2026-10-07','2026-11-05',0,0,'2026-11-06',5),(43,'2025-12-17','2025-12-17',0,0,'2025-12-18',5),(44,'2025-04-02','2025-04-08',0,0,'2025-04-09',5),(45,'2025-04-24','2025-04-24',0,0,'2025-04-25',4),(46,'2026-01-27','2026-02-25',5,337,'2026-02-26',3),(47,'2025-08-14','2025-08-14',0,0,'2025-08-15',6),(48,'2024-11-10','2024-11-16',0,0,'2024-11-18',6),(49,'2025-09-06','2025-09-06',0,0,'2025-09-08',3),(50,'2026-01-25','2026-01-25',7,529,'2026-01-28',3),(51,'2024-04-25','2024-05-01',3,220,'2024-05-03',3),(52,'2024-05-06','2024-05-06',0,0,'2024-05-07',3),(53,'2024-03-01','2024-03-07',0,0,'2024-03-08',5),(54,'2026-06-20','2026-06-20',0,0,'2026-06-22',4),(55,'2026-07-23','2026-08-21',0,0,'2026-08-23',6),(56,'2025-12-14','2025-12-20',0,0,'2025-12-22',3),(57,'2025-12-01','2025-12-30',3,183,'2026-01-02',4),(58,'2025-04-02','2025-05-01',1,28,'2025-05-03',5),(59,'2025-08-06','2025-08-12',0,0,'2025-08-15',3),(60,'2026-07-16','2026-08-14',0,0,'2026-08-17',3),(61,'2024-08-31','2024-08-31',0,0,'2024-09-01',6),(62,'2026-11-13','2026-12-12',1,56,'2026-12-13',4),(63,'2024-12-25','2024-12-31',0,0,'2025-01-01',3),(64,'2025-11-16','2025-11-16',0,0,'2025-11-18',3),(65,'2025-04-05','2025-05-04',1,28,'2025-05-06',3),(66,'2025-08-05','2025-09-03',0,0,'2025-09-04',4),(67,'2025-08-02','2025-08-08',0,0,'2025-08-10',5),(68,'2026-08-30','2026-08-30',0,0,'2026-09-02',6),(69,'2025-06-10','2025-06-16',0,0,'2025-06-18',6),(70,'2026-08-05','2026-09-03',0,0,'2026-09-06',5),(71,'2025-04-18','2025-04-18',0,0,'2025-04-20',5),(72,'2024-07-14','2024-08-12',0,0,'2024-08-14',4),(73,'2025-10-01','2025-10-01',0,0,'2025-10-02',5),(74,'2026-10-12','2026-10-12',0,0,'2026-10-13',3),(75,'2024-02-07','2024-03-07',6,429,'2024-03-09',4),(76,'2026-09-09','2026-10-08',0,0,'2026-10-11',6),(77,'2026-04-22','2026-04-22',0,0,'2026-04-24',3),(78,'2025-12-13','2026-01-11',3,183,'2026-01-13',4),(79,'2026-11-18','2026-11-18',0,0,'2026-11-20',6),(80,'2024-02-06','2024-02-12',0,0,'2024-02-14',4),(81,'2024-06-11','2024-06-11',0,0,'2024-06-13',6),(82,'2025-08-06','2025-08-06',0,0,'2025-08-09',6),(83,'2026-09-30','2026-10-29',0,0,'2026-10-31',4),(84,'2024-10-08','2024-10-08',0,0,'2024-10-09',5),(85,'2024-10-01','2024-10-30',1,115,'2024-10-31',3),(86,'2025-01-02','2025-01-31',5,359,'2025-02-03',4),(87,'2025-04-01','2025-04-07',0,0,'2025-04-10',5),(88,'2025-04-24','2025-05-23',1,28,'2025-05-26',4),(89,'2025-01-13','2025-01-19',0,0,'2025-01-22',4),(90,'2026-09-18','2026-10-17',0,0,'2026-10-19',6),(91,'2026-06-27','2026-07-03',0,0,'2026-07-06',5),(92,'2025-04-25','2025-05-01',1,28,'2025-05-02',5),(93,'2025-06-21','2025-06-27',0,0,'2025-06-29',3),(94,'2025-12-10','2026-01-08',3,183,'2026-01-11',6),(95,'2024-03-02','2024-03-02',0,0,'2024-03-03',5),(96,'2026-01-10','2026-02-08',7,529,'2026-02-10',6),(97,'2025-09-17','2025-09-17',0,0,'2025-09-19',5),(98,'2026-01-13','2026-02-11',7,529,'2026-02-12',3),(99,'2025-06-04','2025-06-10',0,0,'2025-06-13',3),(100,'2026-07-21','2026-07-21',0,0,'2026-07-23',3),(103,'2025-02-17','2025-02-23',0,0,'2025-05-18',108),(107,'2025-05-01','2025-05-31',0,0,'2025-05-18',108),(108,'2025-05-12','2025-05-18',0,0,'2025-05-18',108);
/*!40000 ALTER TABLE `adminreport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookinghistory`
--

DROP TABLE IF EXISTS `bookinghistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookinghistory` (
  `bookingID` int NOT NULL AUTO_INCREMENT,
  `serviceID` int NOT NULL,
  `cleanerID` int NOT NULL,
  `homeownerID` int NOT NULL,
  `price` float NOT NULL,
  `bookingDate` date NOT NULL,
  `serviceDate` date NOT NULL,
  `serviceTimeSlot` varchar(45) NOT NULL,
  `bookingStatus` varchar(45) NOT NULL,
  PRIMARY KEY (`bookingID`),
  KEY `fk_bookinghistory_serviceID_idx` (`serviceID`),
  KEY `fk_bookinghistory_cleanerID_idx` (`cleanerID`),
  KEY `fk_bookinghistory_homeownerID_idx` (`homeownerID`),
  KEY `fk_bookinghistory_price_idx` (`price`),
  CONSTRAINT `fk_bookinghistory_cleanerID` FOREIGN KEY (`cleanerID`) REFERENCES `useraccount` (`userID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_bookinghistory_homeownerID` FOREIGN KEY (`homeownerID`) REFERENCES `useraccount` (`userID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_bookinghistory_serviceID` FOREIGN KEY (`serviceID`) REFERENCES `cleaningservices` (`serviceID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookinghistory`
--

LOCK TABLES `bookinghistory` WRITE;
/*!40000 ALTER TABLE `bookinghistory` DISABLE KEYS */;
INSERT INTO `bookinghistory` VALUES (1,82,7,92,82,'2016-02-25','2025-02-25','1200 - 1500','Confirmed'),(2,95,29,77,30,'2014-05-25','2025-01-26','1900 - 2200','Confirmed'),(3,4,22,60,102,'2014-05-25','2025-03-26','0830 - 1130','Confirmed'),(4,92,10,46,68,'2014-05-25','2025-02-26','1530 - 1830','Confirmed'),(5,98,39,56,75,'2014-05-25','2025-02-26','1530 - 1830','Confirmed'),(6,28,38,48,97,'2029-01-24','2025-03-24','0830 - 1130','Cancelled'),(7,45,12,76,41,'2014-05-25','2025-04-26','1900 - 2200','Confirmed'),(8,49,31,89,37,'2014-05-25','2025-03-26','1530 - 1830','Confirmed'),(9,91,23,67,99,'2017-01-24','2025-01-24','1530 - 1830','Confirmed'),(10,30,31,79,34,'2024-03-24','2025-03-24','1530 - 1830','Confirmed'),(11,48,14,79,131,'2014-05-25','2025-01-26','0830 - 1130','Confirmed'),(12,69,14,91,28,'2027-01-25','2025-02-25','1530 - 1830','Confirmed'),(13,88,20,80,109,'2019-02-25','2025-03-25','0830 - 1130','Cancelled'),(14,52,24,55,149,'2014-05-25','2025-03-26','1530 - 1830','Confirmed'),(15,84,17,90,51,'2024-01-24','2025-01-24','1200 - 1500','Cancelled'),(16,18,17,74,42,'2027-12-24','2025-01-25','1530 - 1830','Cancelled'),(18,97,9,69,77,'2014-05-25','2025-03-26','1200 - 1500','Cancelled'),(19,77,20,99,74,'2028-01-24','2025-02-24','1900 - 2200','Cancelled'),(20,71,20,69,72,'2024-03-25','2025-03-25','1530 - 1830','Cancelled'),(21,15,38,60,81,'2017-03-24','2025-03-24','0830 - 1130','Cancelled'),(22,65,14,96,77,'2028-01-24','2025-03-24','1530 - 1830','Confirmed'),(23,20,34,78,125,'2014-05-25','2025-03-26','0830 - 1130','Cancelled'),(24,63,39,68,93,'2024-02-25','2025-02-25','1530 - 1830','Confirmed'),(25,8,14,60,115,'2017-01-25','2025-01-25','0830 - 1130','Cancelled'),(26,9,15,77,25,'2015-01-24','2025-01-24','1200 - 1500','Cancelled'),(27,68,21,80,127,'2024-12-24','2025-01-25','1200 - 1500','Cancelled'),(28,52,24,44,149,'2017-12-24','2025-01-25','0830 - 1130','Confirmed'),(29,29,40,80,26,'2014-05-25','2025-04-26','1200 - 1500','Confirmed'),(30,1,18,88,76,'2024-01-24','2025-01-24','1200 - 1500','Confirmed'),(31,5,21,47,69,'2014-05-25','2025-01-26','1530 - 1830','Cancelled'),(32,28,38,89,97,'2015-01-24','2025-01-24','1900 - 2200','Confirmed'),(33,61,26,54,145,'2014-05-25','2025-03-26','1900 - 2200','Cancelled'),(34,55,17,81,145,'2014-05-25','2025-04-26','0830 - 1130','Confirmed'),(35,52,24,54,149,'2024-03-24','2025-03-24','1200 - 1500','Confirmed'),(36,69,14,57,28,'2015-01-24','2025-02-24','1530 - 1830','Cancelled'),(37,32,27,83,107,'2019-01-24','2025-01-24','0830 - 1130','Confirmed'),(38,12,19,46,58,'2020-01-24','2025-02-24','1900 - 2200','Confirmed'),(39,52,24,51,149,'2014-05-25','2025-02-26','1900 - 2200','Cancelled'),(40,59,9,56,130,'2013-01-25','2025-01-25','1900 - 2200','Completed'),(41,25,25,52,88,'2014-05-25','2025-03-26','0830 - 1130','Cancelled'),(42,8,14,76,115,'2018-01-25','2025-02-25','1200 - 1500','Confirmed'),(43,66,23,45,141,'2024-03-25','2025-03-25','0830 - 1130','Confirmed'),(44,52,24,51,149,'2014-05-25','2025-01-26','0830 - 1130','Confirmed'),(45,54,15,41,57,'2024-02-25','2025-02-25','1530 - 1830','Confirmed'),(46,34,13,67,47,'2012-07-24','2025-01-25','1530 - 1830','Cancelled'),(47,41,28,69,109,'2014-05-25','2025-02-26','0830 - 1130','Confirmed'),(48,69,14,85,28,'2014-05-25','2025-02-26','1530 - 1830','Confirmed'),(49,32,27,79,107,'0002-01-25','2025-03-25','1530 - 1830','Confirmed'),(50,86,32,71,79,'2012-06-24','2025-01-25','1200 - 1500','Cancelled'),(51,15,38,59,81,'2015-01-24','2025-01-24','1530 - 1830','Cancelled'),(52,78,7,43,30,'2014-05-25','2025-02-26','1530 - 1830','Cancelled'),(53,33,9,55,65,'2015-01-24','2025-01-24','1530 - 1830','Confirmed'),(54,1,18,59,76,'2024-03-25','2025-03-25','1530 - 1830','Confirmed'),(55,95,29,86,30,'2016-01-25','2025-01-25','0830 - 1130','Confirmed'),(56,10,24,59,28,'0003-02-25','2025-04-25','1530 - 1830','Confirmed'),(57,56,15,85,144,'2014-05-25','2025-02-26','0830 - 1130','Cancelled'),(58,27,12,96,45,'2023-02-24','2025-03-24','1900 - 2200','Confirmed'),(59,31,29,70,88,'2025-01-24','2025-03-24','1900 - 2200','Confirmed'),(60,23,20,45,97,'2014-05-25','2025-02-26','1200 - 1500','Cancelled'),(61,21,27,84,98,'2014-05-25','2025-04-26','1900 - 2200','Confirmed'),(62,26,28,55,29,'2014-05-25','2025-03-26','1200 - 1500','Confirmed'),(63,4,22,100,102,'2024-02-25','2025-02-25','0830 - 1130','Cancelled'),(64,45,12,57,41,'2012-11-24','2025-01-25','1530 - 1830','Confirmed'),(65,15,38,91,81,'2024-01-25','2025-01-25','0830 - 1130','Confirmed'),(66,77,20,91,74,'2024-02-24','2025-02-24','0830 - 1130','Cancelled'),(67,74,28,81,72,'2024-04-24','2025-04-24','1900 - 2200','Confirmed'),(68,67,24,78,112,'0002-01-24','2025-02-24','1530 - 1830','Cancelled'),(69,85,16,83,56,'2025-01-25','2025-02-25','1530 - 1830','Cancelled'),(70,42,21,92,53,'2024-02-24','2025-02-24','1200 - 1500','Confirmed'),(71,54,15,100,57,'2020-03-24','2025-03-24','1530 - 1830','Cancelled'),(72,71,20,53,72,'2022-01-24','2025-02-24','1900 - 2200','Cancelled'),(73,60,23,68,58,'2012-01-25','2025-01-26','1900 - 2200','Confirmed'),(74,85,16,48,56,'2024-02-25','2025-02-25','1530 - 1830','Confirmed'),(75,97,9,75,77,'2022-01-24','2025-02-24','1200 - 1500','Confirmed'),(76,4,22,55,102,'2024-02-24','2025-02-24','0830 - 1130','Cancelled'),(77,54,15,82,57,'2012-08-24','2025-01-25','1900 - 2200','Cancelled'),(78,32,27,50,107,'2014-05-25','2024-12-26','0830 - 1130','Cancelled'),(79,29,40,99,26,'2013-01-24','2025-01-24','1900 - 2200','Confirmed'),(80,72,25,58,27,'2029-02-24','2025-03-24','1200 - 1500','Cancelled'),(81,86,32,93,79,'2014-05-25','2025-01-26','1900 - 2200','Cancelled'),(82,71,20,50,72,'2014-02-25','2025-03-25','1900 - 2200','Cancelled'),(83,34,13,45,47,'2015-01-24','2025-01-24','1900 - 2200','Confirmed'),(84,36,19,44,77,'2024-02-24','2025-02-24','1530 - 1830','Cancelled'),(85,41,28,51,109,'2014-05-25','2025-03-26','1900 - 2200','Confirmed'),(86,91,23,91,99,'2021-01-25','2025-02-25','1530 - 1830','Cancelled'),(87,54,15,60,57,'2015-01-24','2025-02-24','0830 - 1130','Cancelled'),(88,62,22,79,115,'2014-05-25','2025-03-26','1900 - 2200','Cancelled'),(89,69,14,88,28,'2024-03-24','2025-03-24','1900 - 2200','Cancelled'),(90,4,22,93,102,'2014-05-25','2025-01-26','1900 - 2200','Confirmed'),(91,60,23,77,58,'2024-01-25','2025-01-25','1900 - 2200','Confirmed'),(92,11,16,99,91,'2015-01-24','2025-01-24','0830 - 1130','Cancelled'),(93,49,31,59,37,'2017-01-24','2025-02-24','1530 - 1830','Cancelled'),(94,36,19,69,77,'2014-05-25','2025-03-26','0830 - 1130','Confirmed'),(95,45,12,48,41,'2028-02-24','2025-04-24','0830 - 1130','Confirmed'),(96,32,27,70,107,'0003-01-24','2025-04-24','1200 - 1500','Confirmed'),(97,17,16,85,62,'2014-03-24','2025-03-24','1200 - 1500','Cancelled'),(98,90,39,60,47,'2023-01-24','2025-02-24','0830 - 1130','Confirmed'),(99,40,7,85,92,'2024-04-24','2025-04-24','1530 - 1830','Cancelled'),(100,51,25,66,40,'2015-01-24','2025-01-24','1200 - 1500','Confirmed'),(101,90,39,58,47,'2029-01-25','2025-02-25','1530 - 1830','Confirmed'),(102,85,16,73,56,'2014-05-25','2024-11-26','0830 - 1130','Confirmed'),(103,14,12,75,51,'2014-05-25','2024-11-25','1900 - 2200','Confirmed'),(104,67,24,72,112,'2014-05-25','2024-11-25','1900 - 2200','Confirmed'),(106,97,9,46,77,'2014-05-25','2024-12-25','0830 - 1130','Confirmed'),(107,24,28,79,48,'2011-01-25','2024-12-25','1530 - 1830','Confirmed'),(108,90,39,43,47,'2024-03-25','2025-03-25','0830 - 1130','Confirmed'),(109,53,32,97,32,'2014-05-25','2025-01-26','1900 - 2200','Confirmed'),(110,12,19,68,58,'2014-05-25','2024-12-25','1530 - 1830','Confirmed'),(111,48,14,88,131,'2014-05-25','2024-11-25','1900 - 2200','Confirmed'),(112,43,28,61,59,'2014-05-25','2024-11-25','1530 - 1830','Confirmed'),(113,16,29,79,57,'2014-05-25','2025-02-26','1200 - 1500','Confirmed'),(114,62,22,57,115,'2015-10-24','2024-10-24','0830 - 1130','Confirmed'),(115,30,31,42,34,'2014-05-25','2024-12-26','1200 - 1500','Confirmed'),(116,7,17,46,92,'2017-02-24','2025-02-24','0830 - 1130','Confirmed'),(117,37,9,55,136,'2014-05-25','2024-12-26','1200 - 1500','Confirmed'),(118,62,22,84,115,'2024-01-25','2025-03-25','1900 - 2200','Confirmed'),(119,81,17,94,102,'2015-01-24','2025-02-24','0830 - 1130','Confirmed'),(120,72,25,96,27,'2014-05-25','2025-01-26','1900 - 2200','Confirmed');
/*!40000 ALTER TABLE `bookinghistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cleaningservices`
--

DROP TABLE IF EXISTS `cleaningservices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cleaningservices` (
  `serviceID` int NOT NULL AUTO_INCREMENT,
  `cleanerID` int NOT NULL,
  `serviceTitle` varchar(255) NOT NULL,
  `serviceDescription` longtext NOT NULL,
  `price` float NOT NULL,
  `viewCount` int NOT NULL,
  `shortlistCount` int NOT NULL,
  `dateCreated` date NOT NULL,
  PRIMARY KEY (`serviceID`),
  KEY `fk_ cleaningservices_cleanerID_idx` (`cleanerID`),
  CONSTRAINT `fk_ cleaningservices_cleanerID` FOREIGN KEY (`cleanerID`) REFERENCES `useraccount` (`userID`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cleaningservices`
--

LOCK TABLES `cleaningservices` WRITE;
/*!40000 ALTER TABLE `cleaningservices` DISABLE KEYS */;
INSERT INTO `cleaningservices` VALUES (1,18,'service1','This service includes service1.',76,187,85,'2024-05-08'),(2,32,'service2','This service includes service2.',47,30,3,'2024-05-15'),(3,16,'service3','This service includes service3.',115,21,9,'2024-05-10'),(4,22,'service4','This service includes service4.',102,1,1,'2024-07-13'),(5,21,'service5','This service includes service5.',69,213,183,'2024-04-02'),(6,15,'service6','This service includes service6.',52,270,171,'2024-12-24'),(7,17,'service7','This service includes service7.',92,53,35,'2024-11-13'),(8,14,'service8','This service includes service8.',115,146,111,'2024-11-24'),(9,15,'service9','This service includes service9.',25,249,179,'2024-03-23'),(10,24,'service10','This service includes service10.',28,172,78,'2024-08-11'),(11,16,'service11','This service includes service11.',91,250,18,'2024-12-27'),(12,19,'service12','This service includes service12.',58,234,100,'2024-12-08'),(13,25,'service13','This service includes service13.',103,127,13,'2024-09-13'),(14,12,'service14','This service includes service14.',51,7,7,'2024-07-09'),(15,38,'service15','This service includes service15.',81,37,4,'2024-02-24'),(16,29,'service16','This service includes service16.',57,30,19,'2024-12-01'),(17,16,'service17','This service includes service17.',62,218,14,'2024-06-19'),(18,17,'service18','This service includes service18.',42,206,20,'2024-12-14'),(19,27,'service19','This service includes service19.',118,52,37,'2024-09-11'),(20,34,'service20','This service includes service20.',125,6,3,'2024-12-19'),(21,27,'service21','This service includes service21.',98,155,126,'2024-09-07'),(22,13,'service22','This service includes service22.',123,9,2,'2024-09-05'),(23,20,'service23','This service includes service23.',97,174,63,'2024-01-03'),(24,28,'service24','This service includes service24.',48,287,226,'2024-06-25'),(25,25,'service25','This service includes service25.',88,209,45,'2024-07-13'),(26,28,'service26','This service includes service26.',29,259,91,'2024-09-03'),(27,12,'service27','This service includes service27.',45,7,0,'2024-07-16'),(28,38,'service28','This service includes service28.',97,230,19,'2024-04-17'),(29,40,'service29','This service includes service29.',26,81,64,'2024-12-25'),(30,31,'service30','This service includes service30.',34,102,46,'2024-10-28'),(31,29,'service31','This service includes service31.',88,219,40,'2024-12-05'),(32,27,'service32','This service includes service32.',107,138,116,'2024-04-16'),(33,9,'service33','This service includes service33.',65,41,34,'2024-11-07'),(34,13,'service34','This service includes service34.',47,171,101,'2024-11-29'),(35,31,'service35','This service includes service35.',122,67,47,'2024-03-19'),(36,19,'service36','This service includes service36.',77,116,103,'2024-11-07'),(37,9,'service37','This service includes service37.',136,265,81,'2024-05-03'),(39,11,'service39','This service includes service39.',84,229,0,'2024-06-14'),(40,7,'service40','This service includes service40.',92,55,43,'2024-06-18'),(41,28,'service41','This service includes service41.',109,106,86,'2024-10-26'),(42,21,'service42','This service includes service42.',53,258,20,'2024-02-22'),(43,28,'service43','This service includes service43.',59,50,23,'2024-12-25'),(44,13,'service44','This service includes service44.',33,205,93,'2024-08-10'),(45,12,'service45','This service includes service45.',41,0,0,'2024-11-25'),(46,9,'service46','This service includes service46.',47,194,118,'2024-01-27'),(47,30,'service47','This service includes service47.',111,191,2,'2024-11-17'),(48,14,'service48','This service includes service48.',131,188,87,'2024-11-06'),(49,31,'service49','This service includes service49.',37,211,72,'2024-06-30'),(50,31,'service50','This service includes service50.',98,21,20,'2024-01-14'),(51,25,'service51','This service includes service51.',40,114,106,'2024-11-17'),(52,24,'service52','This service includes service52.',149,264,77,'2024-12-28'),(53,32,'service53','This service includes service53.',32,296,287,'2024-01-25'),(54,15,'service54','This service includes service54.',57,293,112,'2024-02-14'),(55,17,'service55','This service includes service55.',145,47,45,'2024-08-28'),(56,15,'service56','This service includes service56.',144,108,23,'2024-02-23'),(57,33,'service57','This service includes service57.',71,85,58,'2024-05-25'),(58,26,'service58','This service includes service58.',43,231,215,'2024-10-05'),(59,9,'service59','This service includes service59.',130,25,12,'2024-10-29'),(60,23,'service60','This service includes service60.',58,58,55,'2024-04-23'),(61,26,'service61','This service includes service61.',145,32,1,'2024-07-31'),(62,22,'service62','This service includes service62.',115,157,67,'2024-03-05'),(63,39,'service63','This service includes service63.',93,55,54,'2024-01-23'),(64,37,'service64','This service includes service64.',135,61,55,'2024-11-16'),(65,14,'service65','This service includes service65.',77,179,9,'2024-10-09'),(66,23,'service66','This service includes service66.',141,60,35,'2024-07-14'),(67,24,'service67','This service includes service67.',112,173,83,'2024-05-19'),(68,21,'service68','This service includes service68.',127,300,209,'2024-01-30'),(69,14,'service69','This service includes service69.',28,171,158,'2024-11-08'),(70,31,'service70','This service includes service70.',55,275,227,'2024-03-31'),(71,20,'service71','This service includes service71.',72,162,61,'2024-05-11'),(72,25,'service72','This service includes service72.',27,284,36,'2024-09-29'),(73,8,'service73','This service includes service73.',94,83,4,'2024-04-19'),(74,28,'service74','This service includes service74.',72,95,12,'2024-09-09'),(77,20,'service77','This service includes service77.',74,18,18,'2024-09-18'),(78,7,'service78','This service includes service78.',30,102,91,'2024-01-24'),(79,40,'service79','This service includes service79.',143,54,37,'2024-04-01'),(80,17,'service80','This service includes service80.',142,233,156,'2024-01-16'),(81,17,'service81','This service includes service81.',102,270,75,'2024-08-21'),(82,7,'service82','This service includes service82.',82,232,98,'2024-12-06'),(83,23,'service83','This service includes service83.',76,174,150,'2024-12-21'),(84,17,'service84','This service includes service84.',51,75,3,'2024-12-10'),(85,16,'service85','This service includes service85.',56,111,27,'2024-01-15'),(86,32,'service86','This service includes service86.',79,266,78,'2024-01-13'),(87,22,'service87','This service includes service87.',61,26,19,'2024-10-06'),(88,20,'service88','This service includes service88.',109,170,21,'2024-02-24'),(89,22,'service89','This service includes service89.',60,220,150,'2024-03-15'),(90,39,'service90','This service includes service90.',47,291,122,'2024-06-13'),(91,23,'service91','This service includes service91.',99,220,56,'2024-03-28'),(92,10,'service92','This service includes service92.',68,229,136,'2024-03-02'),(93,36,'service93','This service includes service93.',86,286,133,'2024-09-08'),(94,18,'service94','This service includes service94.',125,78,75,'2024-02-04'),(95,29,'service95','This service includes service95.',30,279,130,'2024-08-09'),(96,17,'service96','This service includes service96.',136,245,84,'2024-11-17'),(97,9,'service97','This service includes service97.',77,146,141,'2024-05-05'),(98,39,'service98','This service includes service98.',75,64,16,'2024-08-21'),(99,33,'service99','This service includes service99.',131,96,36,'2024-08-22'),(100,10,'service100','This service includes service100.',78,259,97,'2024-02-14');
/*!40000 ALTER TABLE `cleaningservices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serviceavailability`
--

DROP TABLE IF EXISTS `serviceavailability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `serviceavailability` (
  `availabilityID` int NOT NULL AUTO_INCREMENT,
  `serviceID` int NOT NULL,
  `availableDate` date NOT NULL,
  `availableTimeSlot` varchar(45) NOT NULL,
  PRIMARY KEY (`availabilityID`),
  KEY `fk_serviceavailability_serviceID_idx` (`serviceID`),
  CONSTRAINT `fk_serviceavailability_serviceID` FOREIGN KEY (`serviceID`) REFERENCES `cleaningservices` (`serviceID`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serviceavailability`
--

LOCK TABLES `serviceavailability` WRITE;
/*!40000 ALTER TABLE `serviceavailability` DISABLE KEYS */;
INSERT INTO `serviceavailability` VALUES (2,95,'2025-01-26','1900 - 2200'),(3,4,'2025-03-26','0830 - 1130'),(5,98,'2025-02-26','1530 - 1830'),(6,28,'2025-03-24','0830 - 1130'),(7,45,'2025-04-26','1900 - 2200'),(8,49,'2025-03-26','1530 - 1830'),(9,91,'2025-01-24','1530 - 1830'),(10,30,'2025-03-24','1530 - 1830'),(11,48,'2025-01-26','0830 - 1130'),(12,69,'2025-02-25','1530 - 1830'),(13,88,'2025-03-25','0830 - 1130'),(14,52,'2025-03-26','1530 - 1830'),(15,84,'2025-01-24','1200 - 1500'),(16,18,'2025-01-25','1530 - 1830'),(18,97,'2025-03-26','1200 - 1500'),(19,77,'2025-02-24','1900 - 2200'),(20,71,'2025-03-25','1530 - 1830'),(21,15,'2025-03-24','0830 - 1130'),(22,65,'2025-03-24','1530 - 1830'),(23,20,'2025-03-26','0830 - 1130'),(24,63,'2025-02-25','1530 - 1830'),(25,8,'2025-01-25','0830 - 1130'),(26,9,'2025-01-24','1200 - 1500'),(27,68,'2025-01-25','1200 - 1500'),(28,52,'2025-01-25','0830 - 1130'),(29,29,'2025-04-26','1200 - 1500'),(30,1,'2025-01-24','1200 - 1500'),(31,5,'2025-01-26','1530 - 1830'),(32,28,'2025-01-24','1900 - 2200'),(33,61,'2025-03-26','1900 - 2200'),(34,55,'2025-04-26','0830 - 1130'),(35,52,'2025-03-24','1200 - 1500'),(36,69,'2025-02-24','1530 - 1830'),(37,32,'2025-01-24','0830 - 1130'),(38,12,'2025-02-24','1900 - 2200'),(39,52,'2025-02-26','1900 - 2200'),(40,59,'2025-01-25','1900 - 2200'),(41,25,'2025-03-26','0830 - 1130'),(42,8,'2025-02-25','1200 - 1500'),(43,66,'2025-03-25','0830 - 1130'),(44,52,'2025-01-26','0830 - 1130'),(45,54,'2025-02-25','1530 - 1830'),(46,34,'2025-01-25','1530 - 1830'),(47,41,'2025-02-26','0830 - 1130'),(48,69,'2025-02-26','1530 - 1830'),(49,32,'2025-03-25','1530 - 1830'),(50,86,'2025-01-25','1200 - 1500'),(51,15,'2025-01-24','1530 - 1830'),(52,78,'2025-02-26','1530 - 1830'),(53,33,'2025-01-24','1530 - 1830'),(54,1,'2025-03-25','1530 - 1830'),(55,95,'2025-01-25','0830 - 1130'),(56,10,'2025-04-25','1530 - 1830'),(57,56,'2025-02-26','0830 - 1130'),(58,27,'2025-03-24','1900 - 2200'),(59,31,'2025-03-24','1900 - 2200'),(60,23,'2025-02-26','1200 - 1500'),(61,21,'2025-04-26','1900 - 2200'),(62,26,'2025-03-26','1200 - 1500'),(63,4,'2025-02-25','0830 - 1130'),(64,45,'2025-01-25','1530 - 1830'),(65,15,'2025-01-25','0830 - 1130'),(66,77,'2025-02-24','0830 - 1130'),(67,74,'2025-04-24','1900 - 2200'),(68,67,'2025-02-24','1530 - 1830'),(69,85,'2025-02-25','1530 - 1830'),(70,42,'2025-02-24','1200 - 1500'),(71,54,'2025-03-24','1530 - 1830'),(72,71,'2025-02-24','1900 - 2200'),(73,60,'2025-01-26','1900 - 2200'),(74,97,'2025-02-24','1200 - 1500'),(75,4,'2025-02-24','0830 - 1130'),(76,54,'2025-01-25','1900 - 2200'),(77,32,'2024-12-26','0830 - 1130'),(78,29,'2025-01-24','1900 - 2200'),(79,72,'2025-03-24','1200 - 1500'),(80,86,'2025-01-26','1900 - 2200'),(81,71,'2025-03-25','1900 - 2200'),(82,34,'2025-01-24','1900 - 2200'),(83,36,'2025-02-24','1530 - 1830'),(84,41,'2025-03-26','1900 - 2200'),(85,91,'2025-02-25','1530 - 1830'),(86,54,'2025-02-24','0830 - 1130'),(87,62,'2025-03-26','1900 - 2200'),(88,69,'2025-03-24','1900 - 2200'),(89,4,'2025-01-26','1900 - 2200'),(90,60,'2025-01-25','1900 - 2200'),(91,11,'2025-01-24','0830 - 1130'),(92,49,'2025-02-24','1530 - 1830'),(93,36,'2025-03-26','0830 - 1130'),(94,45,'2025-04-24','0830 - 1130'),(95,32,'2025-04-24','1200 - 1500'),(96,17,'2025-03-24','1200 - 1500'),(97,90,'2025-02-24','0830 - 1130'),(98,40,'2025-04-24','1530 - 1830'),(99,51,'2025-01-24','1200 - 1500'),(100,90,'2025-02-25','1530 - 1830'),(101,85,'2024-11-26','0830 - 1130'),(102,14,'2024-11-25','1900 - 2200'),(103,67,'2024-11-25','1900 - 2200'),(105,97,'2024-12-25','0830 - 1130'),(106,24,'2024-12-25','1530 - 1830'),(107,90,'2025-03-25','0830 - 1130'),(108,53,'2025-01-26','1900 - 2200'),(109,12,'2024-12-25','1530 - 1830'),(110,48,'2024-11-25','1900 - 2200'),(111,43,'2024-11-25','1530 - 1830'),(112,16,'2025-02-26','1200 - 1500'),(113,62,'2024-10-24','0830 - 1130'),(114,30,'2024-12-26','1200 - 1500'),(115,7,'2025-02-24','0830 - 1130'),(116,37,'2024-12-26','1200 - 1500'),(117,62,'2025-03-25','1900 - 2200'),(118,81,'2025-02-24','0830 - 1130'),(119,72,'2025-01-26','1900 - 2200');
/*!40000 ALTER TABLE `serviceavailability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicecategory`
--

DROP TABLE IF EXISTS `servicecategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicecategory` (
  `categoryID` int NOT NULL AUTO_INCREMENT,
  `categoryName` varchar(60) NOT NULL,
  `categoryDescription` longtext NOT NULL,
  PRIMARY KEY (`categoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicecategory`
--

LOCK TABLES `servicecategory` WRITE;
/*!40000 ALTER TABLE `servicecategory` DISABLE KEYS */;
INSERT INTO `servicecategory` VALUES (1,'category1','This category includes all services within category1.'),(2,'category2','This category includes all services within category2.'),(3,'category3','This category includes all services within category3.'),(4,'category4','This category includes all services within category4.'),(5,'category5','This category includes all services within category5.'),(6,'category6','This category includes all services within category6.'),(7,'category7','This category includes all services within category7.'),(8,'category8','This category includes all services within category8.'),(9,'category9','This category includes all services within category9.'),(10,'category10','This category includes all services within category10.'),(11,'category11','This category includes all services within category11.'),(12,'category12','This category includes all services within category12.'),(13,'category13','This category includes all services within category13.'),(14,'category14','This category includes all services within category14.'),(15,'category15','This category includes all services within category15.'),(16,'category16','This category includes all services within category16.'),(17,'category17','This category includes all services within category17.'),(18,'category18','This category includes all services within category18.'),(19,'category19','This category includes all services within category19.'),(20,'category20','This category includes all services within category20.'),(21,'category21','This category includes all services within category21.'),(22,'category22','This category includes all services within category22.'),(23,'category23','This category includes all services within category23.'),(24,'category24','This category includes all services within category24.'),(25,'category25','This category includes all services within category25.'),(26,'category26','This category includes all services within category26.'),(27,'category27','This category includes all services within category27.'),(28,'category28','This category includes all services within category28.'),(29,'category29','This category includes all services within category29.'),(30,'category30','This category includes all services within category30.'),(31,'category31','This category includes all services within category31.'),(32,'category32','This category includes all services within category32.'),(33,'category33','This category includes all services within category33.'),(34,'category34','This category includes all services within category34.'),(35,'category35','This category includes all services within category35.'),(36,'category36','This category includes all services within category36.'),(37,'category37','This category includes all services within category37.'),(38,'category38','This category includes all services within category38.'),(39,'category39','This category includes all services within category39.'),(40,'category40','This category includes all services within category40.'),(41,'category41','This category includes all services within category41.'),(42,'category42','This category includes all services within category42.'),(43,'category43','This category includes all services within category43.'),(44,'category44','This category includes all services within category44.'),(45,'category45','This category includes all services within category45.'),(46,'category46','This category includes all services within category46.'),(47,'category47','This category includes all services within category47.'),(48,'category48','This category includes all services within category48.'),(49,'category49','This category includes all services within category49.'),(50,'category50','This category includes all services within category50.'),(51,'category51','This category includes all services within category51.'),(52,'category52','This category includes all services within category52.'),(53,'category53','This category includes all services within category53.'),(54,'category54','This category includes all services within category54.'),(55,'category55','This category includes all services within category55.'),(56,'category56','This category includes all services within category56.'),(57,'category57','This category includes all services within category57.'),(58,'category58','This category includes all services within category58.'),(59,'category59','This category includes all services within category59.'),(60,'category60','This category includes all services within category60.'),(61,'category61','This category includes all services within category61.'),(62,'category62','This category includes all services within category62.'),(63,'category63','This category includes all services within category63.'),(64,'category64','This category includes all services within category64.'),(65,'category65','This category includes all services within category65.'),(66,'category66','This category includes all services within category66.'),(67,'category67','This category includes all services within category67.'),(68,'category68','This category includes all services within category68.'),(69,'category69','This category includes all services within category69.'),(70,'category70','This category includes all services within category70.'),(71,'category71','This category includes all services within category71.'),(72,'category72','This category includes all services within category72.'),(73,'category73','This category includes all services within category73.'),(74,'category74','This category includes all services within category74.'),(75,'category75','This category includes all services within category75.'),(76,'category76','This category includes all services within category76.'),(77,'category77','This category includes all services within category77.'),(78,'category78','This category includes all services within category78.'),(79,'category79','This category includes all services within category79.'),(80,'category80','This category includes all services within category80.'),(81,'category81','This category includes all services within category81.'),(82,'category82','This category includes all services within category82.'),(83,'category83','This category includes all services within category83.'),(84,'category84','This category includes all services within category84.'),(85,'category85','This category includes all services within category85.'),(86,'category86','This category includes all services within category86.'),(87,'category87','This category includes all services within category87.'),(88,'category88','This category includes all services within category88.'),(89,'category89','This category includes all services within category89.'),(90,'category90','This category includes all services within category90.'),(91,'category91','This category includes all services within category91.'),(92,'category92','This category includes all services within category92.'),(93,'category93','This category includes all services within category93.'),(94,'category94','This category includes all services within category94.'),(95,'category95','This category includes all services within category95.'),(96,'category96','This category includes all services within category96.'),(97,'category97','This category includes all services within category97.'),(98,'category98','This category includes all services within category98.'),(99,'category99','This category includes all services within category99.'),(100,'category100','This category includes all services within category100.');
/*!40000 ALTER TABLE `servicecategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicecategorymap`
--

DROP TABLE IF EXISTS `servicecategorymap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicecategorymap` (
  `serviceID` int NOT NULL,
  `categoryID` int NOT NULL,
  PRIMARY KEY (`serviceID`,`categoryID`),
  KEY `fk_servicecategorymap_categoryID_idx` (`categoryID`),
  CONSTRAINT `fk_servicecategorymap_categoryID` FOREIGN KEY (`categoryID`) REFERENCES `servicecategory` (`categoryID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_servicecategorymap_serviceID` FOREIGN KEY (`serviceID`) REFERENCES `cleaningservices` (`serviceID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicecategorymap`
--

LOCK TABLES `servicecategorymap` WRITE;
/*!40000 ALTER TABLE `servicecategorymap` DISABLE KEYS */;
INSERT INTO `servicecategorymap` VALUES (3,2),(19,2),(39,2),(65,2),(101,2),(102,2),(18,3),(27,3),(33,3),(40,3),(43,3),(45,3),(85,3),(90,3),(97,3),(101,3),(48,4),(101,4),(60,5),(101,5),(60,6),(9,7),(25,7),(44,7),(50,7),(83,7),(29,8),(31,8),(85,8),(11,9),(69,9),(80,10),(23,11),(54,11),(87,11),(66,12),(72,12),(91,12),(99,12),(28,13),(34,13),(69,13),(90,13),(6,14),(10,14),(33,14),(46,14),(72,14),(17,15),(19,16),(21,17),(15,18),(37,18),(34,19),(50,20),(1,21),(67,21),(78,21),(23,22),(93,22),(1,23),(9,23),(23,23),(43,23),(30,24),(85,25),(99,25),(3,26),(36,26),(42,26),(35,27),(53,27),(57,27),(69,27),(83,27),(93,27),(88,28),(4,30),(58,30),(10,31),(24,31),(63,31),(7,32),(23,32),(26,32),(62,32),(66,32),(55,33),(47,34),(63,34),(10,35),(13,35),(35,35),(83,35),(84,35),(88,35),(93,35),(96,35),(58,36),(15,37),(41,37),(6,38),(7,38),(18,38),(27,39),(35,39),(8,40),(90,40),(2,41),(5,41),(20,41),(55,41),(4,43),(3,44),(9,44),(20,44),(30,46),(53,46),(18,47),(25,47),(47,47),(12,48),(24,48),(25,48),(34,49),(40,49),(31,50),(62,50),(74,50),(1,51),(28,51),(51,51),(44,52),(58,52),(24,53),(43,53),(78,53),(11,54),(22,54),(18,55),(32,55),(60,55),(2,56),(39,56),(73,56),(85,56),(97,56),(11,57),(48,57),(55,57),(73,57),(27,58),(71,58),(16,59),(17,59),(91,59),(95,59),(77,60),(15,61),(26,61),(68,61),(94,61),(30,62),(36,62),(50,63),(42,64),(47,64),(52,64),(52,65),(56,65),(14,66),(28,66),(70,66),(71,66),(45,67),(57,67),(78,67),(22,68),(28,68),(68,68),(21,69),(63,69),(71,69),(95,69),(9,70),(40,70),(54,70),(90,70),(73,71),(79,71),(16,72),(32,72),(40,72),(42,72),(59,72),(77,73),(70,74),(25,75),(52,75),(58,75),(97,75),(11,77),(78,77),(73,79),(61,80),(68,80),(72,81),(31,82),(77,82),(5,83),(10,83),(88,83),(41,84),(47,84),(86,84),(91,84),(69,85),(36,86),(81,86),(16,87),(19,87),(39,87),(72,87),(84,87),(1,88),(33,88),(51,88),(56,88),(12,89),(68,89),(98,89),(62,91),(65,91),(26,92),(32,92),(49,93),(16,94),(39,95),(89,95),(4,96),(83,96),(5,97),(30,97),(34,97),(51,97),(41,98),(50,98),(51,98),(64,98),(65,98),(43,99),(70,99),(2,100),(6,100);
/*!40000 ALTER TABLE `servicecategorymap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shortlist`
--

DROP TABLE IF EXISTS `shortlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shortlist` (
  `homeownerID` int NOT NULL,
  `serviceID` int NOT NULL,
  PRIMARY KEY (`homeownerID`,`serviceID`),
  KEY `fk_shortlist_cleanerID_idx` (`homeownerID`),
  KEY `fk_shortlist_serviceID_idx` (`serviceID`),
  CONSTRAINT `fk_shortlist_homeownerID` FOREIGN KEY (`homeownerID`) REFERENCES `useraccount` (`userID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_shortlist_serviceID` FOREIGN KEY (`serviceID`) REFERENCES `cleaningservices` (`serviceID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shortlist`
--

LOCK TABLES `shortlist` WRITE;
/*!40000 ALTER TABLE `shortlist` DISABLE KEYS */;
INSERT INTO `shortlist` VALUES (41,63),(41,79),(41,89),(43,92),(44,16),(44,40),(44,72),(46,1),(46,2),(46,95),(47,49),(47,55),(48,65),(49,96),(50,33),(50,78),(52,11),(52,30),(53,5),(53,87),(54,94),(55,72),(55,97),(56,49),(56,93),(59,2),(59,21),(59,32),(59,79),(59,82),(61,15),(61,82),(61,88),(62,13),(64,6),(64,25),(64,52),(65,14),(65,84),(65,90),(66,53),(67,12),(68,41),(69,74),(70,5),(70,60),(71,3),(71,11),(72,6),(72,77),(72,82),(72,87),(73,22),(73,43),(74,36),(74,57),(75,2),(75,74),(76,15),(78,85),(79,62),(80,10),(80,24),(80,55),(81,96),(83,9),(83,40),(83,78),(84,25),(84,53),(84,55),(84,60),(85,8),(85,20),(86,17),(87,86),(87,95),(88,67),(88,89),(90,46),(90,91),(91,100),(92,9),(92,22),(92,33),(93,32),(93,62),(94,26),(94,97),(95,25),(95,70),(95,82),(95,100),(96,40),(96,87),(98,10),(99,62),(100,7),(100,40),(106,1),(106,2),(106,3);
/*!40000 ALTER TABLE `shortlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraccount`
--

DROP TABLE IF EXISTS `useraccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `useraccount` (
  `userID` int NOT NULL AUTO_INCREMENT,
  `profileID` int NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `fullname` varchar(60) NOT NULL,
  `accountStatus` varchar(45) NOT NULL,
  PRIMARY KEY (`userID`),
  KEY `fk_useraccount_profileID_idx` (`profileID`),
  CONSTRAINT `fk_useraccount_profileID` FOREIGN KEY (`profileID`) REFERENCES `userprofile` (`profileID`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useraccount`
--

LOCK TABLES `useraccount` WRITE;
/*!40000 ALTER TABLE `useraccount` DISABLE KEYS */;
INSERT INTO `useraccount` VALUES (1,1,'useradmin1','UA1_password','User 1','Active'),(2,1,'useradmin2','UA2_password','User 2','Suspended'),(3,4,'platformmanager1','PM1_password','User 3','Active'),(4,4,'platformmanager2','PM2_password','User 4','Suspended'),(5,4,'platformmanager3','PM3_password','User 5','Active'),(6,4,'platformmanager4','PM4_password','User 6','Active'),(7,3,'cleaner1','CL1_password','User 7','Active'),(8,3,'cleaner2','CL2_password','User 8','Suspended'),(9,3,'cleaner3','CL3_password','User 9','Active'),(10,3,'cleaner4','CL4_password','User 10','Active'),(11,3,'cleaner5','CL5_password','User 11','Active'),(12,3,'cleaner6','CL6_password','User 12','Active'),(13,3,'cleaner7','CL7_password','User 13','Active'),(14,3,'cleaner8','CL8_password','User 14','Active'),(15,3,'cleaner9','CL9_password','User 15','Active'),(16,3,'cleaner10','CL10_password','User 16','Active'),(17,3,'cleaner11','CL11_password','User 17','Active'),(18,3,'cleaner12','CL12_password','User 18','Active'),(19,3,'cleaner13','CL13_password','User 19','Active'),(20,3,'cleaner14','CL14_password','User 20','Active'),(21,3,'cleaner15','CL15_password','User 21','Active'),(22,3,'cleaner16','CL16_password','User 22','Active'),(23,3,'cleaner17','CL17_password','User 23','Active'),(24,3,'cleaner18','CL18_password','User 24','Active'),(25,3,'cleaner19','CL19_password','User 25','Active'),(26,3,'cleaner20','CL20_password','User 26','Active'),(27,3,'cleaner21','CL21_password','User 27','Active'),(28,3,'cleaner22','CL22_password','User 28','Active'),(29,3,'cleaner23','CL23_password','User 29','Active'),(30,3,'cleaner24','CL24_password','User 30','Active'),(31,3,'cleaner25','CL25_password','User 31','Active'),(32,3,'cleaner26','CL26_password','User 32','Active'),(33,3,'cleaner27','CL27_password','User 33','Active'),(34,3,'cleaner28','CL28_password','User 34','Active'),(35,3,'cleaner29','CL29_password','User 35','Active'),(36,3,'cleaner30','CL30_password','User 36','Active'),(37,3,'cleaner31','CL31_password','User 37','Active'),(38,3,'cleaner32','CL32_password','User 38','Active'),(39,3,'cleaner33','CL33_password','User 39','Active'),(40,3,'cleaner34','CL34_password','User 40','Active'),(41,2,'homeowner1','HO1_password','User 41','Active'),(42,2,'homeowner2','HO2_password','User 42','Suspended'),(43,2,'homeowner3','HO3_password','User 43','Active'),(44,2,'homeowner4','HO4_password','User 44','Active'),(45,2,'homeowner5','HO5_password','User 45','Active'),(46,2,'homeowner6','HO6_password','User 46','Active'),(47,2,'homeowner7','HO7_password','User 47','Active'),(48,2,'homeowner8','HO8_password','User 48','Active'),(49,2,'homeowner9','HO9_password','User 49','Active'),(50,2,'homeowner10','HO10_password','User 50','Active'),(51,2,'homeowner11','HO11_password','User 51','Active'),(52,2,'homeowner12','HO12_password','User 52','Active'),(53,2,'homeowner13','HO13_password','User 53','Active'),(54,2,'homeowner14','HO14_password','User 54','Active'),(55,2,'homeowner15','HO15_password','User 55','Active'),(56,2,'homeowner16','HO16_password','User 56','Active'),(57,2,'homeowner17','HO17_password','User 57','Active'),(58,2,'homeowner18','HO18_password','User 58','Active'),(59,2,'homeowner19','HO19_password','User 59','Active'),(60,2,'homeowner20','HO20_password','User 60','Active'),(61,2,'homeowner21','HO21_password','User 61','Active'),(62,2,'homeowner22','HO22_password','User 62','Active'),(63,2,'homeowner23','HO23_password','User 63','Active'),(64,2,'homeowner24','HO24_password','User 64','Active'),(65,2,'homeowner25','HO25_password','User 65','Active'),(66,2,'homeowner26','HO26_password','User 66','Active'),(67,2,'homeowner27','HO27_password','User 67','Active'),(68,2,'homeowner28','HO28_password','User 68','Active'),(69,2,'homeowner29','HO29_password','User 69','Active'),(70,2,'homeowner30','HO30_password','User 70','Active'),(71,2,'homeowner31','HO31_password','User 71','Active'),(72,2,'homeowner32','HO32_password','User 72','Active'),(73,2,'homeowner33','HO33_password','User 73','Active'),(74,2,'homeowner34','HO34_password','User 74','Active'),(75,2,'homeowner35','HO35_password','User 75','Active'),(76,2,'homeowner36','HO36_password','User 76','Active'),(77,2,'homeowner37','HO37_password','User 77','Active'),(78,2,'homeowner38','HO38_password','User 78','Active'),(79,2,'homeowner39','HO39_password','User 79','Active'),(80,2,'homeowner40','HO40_password','User 80','Active'),(81,2,'homeowner41','HO41_password','User 81','Active'),(82,2,'homeowner42','HO42_password','User 82','Active'),(83,2,'homeowner43','HO43_password','User 83','Active'),(84,2,'homeowner44','HO44_password','User 84','Active'),(85,2,'homeowner45','HO45_password','User 85','Active'),(86,2,'homeowner46','HO46_password','User 86','Active'),(87,2,'homeowner47','HO47_password','User 87','Active'),(88,2,'homeowner48','HO48_password','User 88','Active'),(89,2,'homeowner49','HO49_password','User 89','Active'),(90,2,'homeowner50','HO50_password','User 90','Active'),(91,2,'homeowner51','HO51_password','User 91','Active'),(92,2,'homeowner52','HO52_password','User 92','Active'),(93,2,'homeowner53','HO53_password','User 93','Active'),(94,2,'homeowner54','HO54_password','User 94','Active'),(95,2,'homeowner55','HO55_password','User 95','Active'),(96,2,'homeowner56','HO56_password','User 96','Active'),(97,2,'homeowner57','HO57_password','User 97','Active'),(98,2,'homeowner58','HO58_password','User 98','Active'),(99,2,'homeowner59','HO59_password','User 99','Active'),(100,2,'homeowner60','HO60_password','User 100','Active');
/*!40000 ALTER TABLE `useraccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userprofile`
--

DROP TABLE IF EXISTS `userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userprofile` (
  `profileID` int NOT NULL AUTO_INCREMENT,
  `profileName` varchar(45) NOT NULL,
  `profileDescription` longtext NOT NULL,
  `profileStatus` varchar(45) NOT NULL,
  PRIMARY KEY (`profileID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userprofile`
--

LOCK TABLES `userprofile` WRITE;
/*!40000 ALTER TABLE `userprofile` DISABLE KEYS */;
INSERT INTO `userprofile` VALUES (1,'User Administrator','User Administrator manages user access rights, accounts, and overall system maintenance.','Active'),(2,'Home Owner','Home Owner is the service requester who can search, view, book, and review cleaning services.','Active'),(3,'Cleaner','Cleaner provides cleaning services and can manage service listings, availability, and booking history.','Active'),(4,'Platform Manager','Platform Manager oversees system operations, manages service categories, and generates platform reports.','Active');
/*!40000 ALTER TABLE `userprofile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-19  2:07:05
